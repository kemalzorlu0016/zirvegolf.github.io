import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { CHARACTERS, GOLF_CLUBS } from '../game/catalog.ts';
import { golfAudio } from '../game/audio.ts';
import { getElevationAt, getHole, getHoleCupPos, getSurfaceAt } from '../game/courses.ts';
import { simulateShotTrajectory } from '../game/physics.ts';
import type {
  CameraMode,
  CharacterId,
  ClubId,
  GameScreenState,
  PlayerMatchState,
  ShotSimulationResult,
  Vec3,
} from '../game/types.ts';
import { createCourseVisuals, createGolferRig, type CourseVisuals, type GolferRig } from './models.ts';
import { createProceduralGolfTextures, type ProceduralGolfTextures } from './textures.ts';

// Pre-allocated scratch helpers (zero GC inside animation loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _mat4 = new THREE.Matrix4();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();

export interface SceneVisualState {
  screenState: GameScreenState;
  holeIndex: number;
  wind: { x: number; z: number };
  cameraMode: CameraMode;
  players: PlayerMatchState[];
  activePlayerId: string;
  localPlayerId: string;
  previewClubId: ClubId;
  previewAimYaw: number;
  previewPowerRatio: number;
  previewPowerActive: boolean;
  isCharging: boolean;
}

interface ActiveFlight {
  playerId: string;
  clubId: ClubId;
  powerActive: boolean;
  sim: ShotSimulationResult;
  elapsed: number;
  nextBounceIdx: number;
  nextObstacleIdx: number;
  splashTriggered: boolean;
  cupTriggered: boolean;
  onComplete: () => void;
}

interface ParticleItem {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
  color: THREE.Color;
}

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class GolfSceneManager {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private textures: ProceduralGolfTextures;
  private courseVisuals: CourseVisuals | null = null;
  private loadedHoleIndex = -1;

  // Player actors & balls keyed by playerId
  private golferRigs = new Map<string, GolferRig>();
  private ballMeshes = new Map<string, { mesh: THREE.Mesh; shadow: THREE.Mesh; ring: THREE.Mesh }>();

  // Trajectory preview line, dotted glowing beads & landing ring
  private aimLine: THREE.Line;
  private aimLineGeo: THREE.BufferGeometry;
  private aimDotCount = 26;
  private aimDotsInst: THREE.InstancedMesh;
  private landingRing: THREE.Mesh;
  private cloudsGroup: THREE.Group;
  private blimpGroup: THREE.Group;

  // Pooled particle ring buffer
  private particleCount = 120;
  private particleInst: THREE.InstancedMesh;
  private particles: ParticleItem[] = [];
  private particleCursor = 0;

  // Ball trail line during flight
  private trailLine: THREE.Line;
  private trailGeo: THREE.BufferGeometry;
  private trailPoints: Float32Array;
  private trailCount = 0;

  // Dynamic loop & state
  private frameId = 0;
  private destroyed = false;
  private lastTime = performance.now();
  private elapsedTotal = 0;
  private cameraShakeTrauma = 0;
  private camPos = new THREE.Vector3(0, 14, 82);
  private camLook = new THREE.Vector3(0, 2, 0);
  private swingAnimTimer = 0;
  private swingAnimPlayerId: string | null = null;
  private celebrationTimer = 0;
  private celebrationPlayerId: string | null = null;

  private state: SceneVisualState = {
    screenState: 'title',
    holeIndex: 0,
    wind: { x: 1.6, z: -0.6 },
    cameraMode: 'aim',
    players: [],
    activePlayerId: 'solo',
    localPlayerId: 'solo',
    previewClubId: 'driver',
    previewAimYaw: Math.PI,
    previewPowerRatio: 0.65,
    previewPowerActive: false,
    isCharging: false,
  };

  private activeFlight: ActiveFlight | null = null;
  private resizeObserver: ResizeObserver;
  private onAimDelta?: (deltaRad: number) => void;
  private snapCameraNextFrame = false;
  private isDraggingAim = false;
  private lastDragX = 0;

  constructor(container: HTMLElement, onAimDelta?: (deltaRad: number) => void) {
    this.container = container;
    this.onAimDelta = onAimDelta;
    this.isSoftwareGl = detectSoftwareWebGL();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.88;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.style.touchAction = 'none';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2('#b7e0fa', 0.0018);

    // Rich calibrated atmospheric Sky Dome (crisp Switch Sports daytime blue -> soft sunlit horizon)
    const sunDir = new THREE.Vector3();
    const phi = THREE.MathUtils.degToRad(56);
    const theta = THREE.MathUtils.degToRad(148);
    sunDir.setFromSphericalCoords(1, phi, theta);

    const skyGeo = new THREE.SphereGeometry(900, 24, 16);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        topColor: { value: new THREE.Color('#1b74d8') },
        midColor: { value: new THREE.Color('#62b3f2') },
        bottomColor: { value: new THREE.Color('#d7f2ff') },
        sunDirection: { value: sunDir.clone().normalize() },
      },
      vertexShader: `
        varying vec3 vWorldPos;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldPos = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 midColor;
        uniform vec3 bottomColor;
        uniform vec3 sunDirection;
        varying vec3 vWorldPos;
        void main() {
          vec3 dir = normalize(vWorldPos);
          float h = clamp(dir.y, 0.0, 1.0);
          vec3 skyCol = mix(bottomColor, midColor, smoothstep(0.0, 0.22, h));
          skyCol = mix(skyCol, topColor, smoothstep(0.18, 0.72, h));
          float sunDot = max(dot(dir, sunDirection), 0.0);
          skyCol += vec3(1.0, 0.92, 0.72) * (pow(sunDot, 24.0) * 0.32 + pow(sunDot, 220.0) * 0.85);
          gl_FragColor = vec4(skyCol, 1.0);
        }
      `,
    });
    const skyDome = new THREE.Mesh(skyGeo, skyMat);
    this.scene.add(skyDome);

    this.camera = new THREE.PerspectiveCamera(48, width / height, 0.25, 1200);
    this.camera.position.copy(this.camPos);

    // Studio PBR environment reflection
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3-Point Bright Daytime Outdoor Light Rig
    const hemi = new THREE.HemisphereLight(0xa5d8ff, 0x22441b, 0.65);
    this.scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xfff1d6, 2.55);
    sun.position.copy(sunDir).multiplyScalar(110);
    sun.castShadow = !this.isSoftwareGl;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.near = 10;
    sun.shadow.camera.far = 260;
    const d = 115;
    sun.shadow.camera.left = -d;
    sun.shadow.camera.right = d;
    sun.shadow.camera.top = d;
    sun.shadow.camera.bottom = -d;
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.02;
    this.scene.add(sun);

    const rim = new THREE.DirectionalLight(0x9bd4ff, 0.45);
    rim.position.set(-55, 34, -75);
    this.scene.add(rim);

    // Procedural Textures
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.textures = createProceduralGolfTextures(maxAniso);

    // Fluffy Cumulus Cloud Clusters drifting across the sky
    this.cloudsGroup = new THREE.Group();
    const cloudPuffGeo = new THREE.SphereGeometry(1, 12, 10);
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xdbeafe,
      emissiveIntensity: 0.45,
      roughness: 0.95,
      metalness: 0.0,
      envMapIntensity: 0.1,
    });
    for (let c = 0; c < 14; c++) {
      const ang = (c / 14) * Math.PI * 2 + 0.2;
      const dist = 235 + (c % 3) * 48;
      const cl = new THREE.Group();
      cl.position.set(Math.cos(ang) * dist, 72 + (c % 4) * 10, Math.sin(ang) * dist);
      cl.lookAt(0, cl.position.y, 0);
      const puffs = [
        { x: 0, y: 0, z: 0, sx: 16, sy: 6.5, sz: 8 },
        { x: -11, y: -1.4, z: 1.5, sx: 11, sy: 5.0, sz: 7 },
        { x: 11, y: -1.2, z: -1.0, sx: 12, sy: 5.4, sz: 7 },
        { x: 3, y: 3.5, z: 0.5, sx: 9, sy: 5.0, sz: 6 },
      ];
      puffs.forEach((pf) => {
        const m = new THREE.Mesh(cloudPuffGeo, cloudMat);
        m.position.set(pf.x, pf.y, pf.z);
        m.scale.set(pf.sx, pf.sy, pf.sz);
        cl.add(m);
      });
      this.cloudsGroup.add(cl);
    }
    this.scene.add(this.cloudsGroup);

    // Floating Resort Blimp / Airship in Upper-Left Sky (Switch Sports Resort hallmark)
    this.blimpGroup = new THREE.Group();
    const blimpHullMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      emissive: 0xe0f2fe,
      emissiveIntensity: 0.25,
      roughness: 0.42,
      metalness: 0.08,
    });
    const blimpStripeMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.4,
      metalness: 0.15,
    });
    const blimpGondolaMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.6,
      metalness: 0.3,
    });
    const hull = new THREE.Mesh(new THREE.CapsuleGeometry(3.8, 12.0, 10, 18), blimpHullMat);
    hull.rotation.z = Math.PI / 2;
    const stripe = new THREE.Mesh(new THREE.CylinderGeometry(3.88, 3.88, 2.6, 18, 1, true), blimpStripeMat);
    stripe.rotation.z = Math.PI / 2;
    const gondola = new THREE.Mesh(new THREE.BoxGeometry(5.2, 1.4, 1.8), blimpGondolaMat);
    gondola.position.set(0.4, -3.9, 0);
    const finGeo = new THREE.BoxGeometry(3.2, 2.6, 0.25);
    const finTop = new THREE.Mesh(finGeo, blimpStripeMat);
    finTop.position.set(-7.2, 2.6, 0);
    const finBottom = new THREE.Mesh(finGeo, blimpStripeMat);
    finBottom.position.set(-7.2, -2.6, 0);
    const finSide = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.25, 4.4), blimpStripeMat);
    finSide.position.set(-7.2, 0, 0);
    this.blimpGroup.add(hull, stripe, gondola, finTop, finBottom, finSide);
    this.blimpGroup.position.set(-48, 34, -140);
    this.blimpGroup.rotation.y = 0.24;
    this.scene.add(this.blimpGroup);

    // Trajectory Preview Arc + Glowing Dotted Beads (Switch Sports Golf style)
    this.aimLineGeo = new THREE.BufferGeometry();
    const maxPreviewPts = 90;
    this.aimLineGeo.setAttribute(
      'position',
      new THREE.BufferAttribute(new Float32Array(maxPreviewPts * 3), 3),
    );
    const aimLineMat = new THREE.LineBasicMaterial({
      color: 0x7dd3fc,
      transparent: true,
      opacity: 0.55,
    });
    this.aimLine = new THREE.Line(this.aimLineGeo, aimLineMat);
    this.aimLine.frustumCulled = false;
    this.scene.add(this.aimLine);

    const dotGeo = new THREE.SphereGeometry(0.068, 10, 8);
    const dotMat = new THREE.MeshBasicMaterial({ color: 0xe0f2fe });
    this.aimDotsInst = new THREE.InstancedMesh(dotGeo, dotMat, this.aimDotCount);
    this.aimDotsInst.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.aimDotsInst.frustumCulled = false;
    this.aimDotsInst.visible = false;
    this.scene.add(this.aimDotsInst);

    // Landing Target Ring
    const ringGeo = new THREE.RingGeometry(0.85, 1.35, 28);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.landingRing = new THREE.Mesh(ringGeo, ringMat);
    this.landingRing.visible = false;
    this.scene.add(this.landingRing);

    // Shot Flight Trail Line
    this.trailGeo = new THREE.BufferGeometry();
    this.trailPoints = new Float32Array(260 * 3);
    this.trailGeo.setAttribute('position', new THREE.BufferAttribute(this.trailPoints, 3));
    const trailMat = new THREE.LineBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.78,
    });
    this.trailLine = new THREE.Line(this.trailGeo, trailMat);
    this.trailLine.frustumCulled = false;
    this.trailLine.visible = false;
    this.scene.add(this.trailLine);

    // Pooled InstancedMesh Particle Ring Buffer
    const pGeo = new THREE.DodecahedronGeometry(0.14, 0);
    const pMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.particleInst = new THREE.InstancedMesh(pGeo, pMat, this.particleCount);
    this.particleInst.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.particleInst.frustumCulled = false;
    for (let i = 0; i < this.particleCount; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -50,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 1,
        size: 1,
        color: new THREE.Color(0xffffff),
      });
      _mat4.makeScale(0, 0, 0);
      this.particleInst.setMatrixAt(i, _mat4);
      this.particleInst.setColorAt(i, _color);
    }
    this.scene.add(this.particleInst);

    // Load Hole 0 immediately
    this.loadHole(0);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    // Direct canvas horizontal drag aiming for effortless shot alignment
    const dom = this.renderer.domElement;
    dom.addEventListener('pointerdown', this.handlePointerDown);
    window.addEventListener('pointermove', this.handlePointerMove);
    window.addEventListener('pointerup', this.handlePointerUp);
    window.addEventListener('pointercancel', this.handlePointerUp);

    this.lastTime = performance.now();
    this.tick();
  }

  private handlePointerDown = (e: PointerEvent): void => {
    if (
      this.state.screenState !== 'playing' ||
      this.activeFlight !== null ||
      this.state.activePlayerId !== this.state.localPlayerId
    ) {
      return;
    }
    this.isDraggingAim = true;
    this.lastDragX = e.clientX;
  };

  private handlePointerMove = (e: PointerEvent): void => {
    if (!this.isDraggingAim) return;
    const dx = e.clientX - this.lastDragX;
    this.lastDragX = e.clientX;
    if (Math.abs(dx) > 0 && this.onAimDelta) {
      this.onAimDelta(-dx * 0.0045);
    }
  };

  private handlePointerUp = (): void => {
    this.isDraggingAim = false;
  };

  public isPlayingFlight(): boolean {
    return this.activeFlight !== null;
  }

  public syncState(next: SceneVisualState): void {
    const holeChanged = next.holeIndex !== this.loadedHoleIndex;
    const enteredPlaying = this.state.screenState !== 'playing' && next.screenState === 'playing';
    this.state = next;
    if (holeChanged) {
      this.loadHole(next.holeIndex);
    }
    if (enteredPlaying || holeChanged) {
      this.snapCameraNextFrame = true;
    }
    this.syncPlayersAndBalls();
    this.updateAimPreview();
  }

  public playShotFlight(
    playerId: string,
    clubId: ClubId,
    powerActive: boolean,
    sim: ShotSimulationResult,
    onComplete: () => void,
  ): void {
    this.swingAnimPlayerId = playerId;
    this.swingAnimTimer = 0.48;
    this.trailCount = 0;
    this.trailLine.visible = true;
    (this.trailLine.material as THREE.LineBasicMaterial).color.set(
      powerActive ? '#fbbf24' : '#ffffff',
    );

    if (clubId === 'driver') {
      this.cameraShakeTrauma = powerActive ? 0.55 : 0.32;
    } else if (clubId === 'iron') {
      this.cameraShakeTrauma = 0.18;
    }

    // Launch turf/sand burst at start point
    if (sim.points.length > 0) {
      const start = sim.points[0];
      const hole = getHole(this.state.holeIndex);
      const surf = getSurfaceAt(hole, start.x, start.z);
      if (surf === 'bunker') {
        this.emitBurst(start.x, start.y, start.z, 16, 0xe8d49c, 5.5);
      } else if (clubId !== 'putter') {
        this.emitBurst(start.x, start.y, start.z, 10, 0x4ca052, 4.2);
      }
    }

    this.activeFlight = {
      playerId,
      clubId,
      powerActive,
      sim,
      elapsed: 0,
      nextBounceIdx: 0,
      nextObstacleIdx: 0,
      splashTriggered: false,
      cupTriggered: false,
      onComplete,
    };
    this.aimLine.visible = false;
    this.aimDotsInst.visible = false;
    this.landingRing.visible = false;
  }

  private loadHole(holeIndex: number): void {
    if (this.courseVisuals) {
      this.scene.remove(this.courseVisuals.group);
      this.courseVisuals.dispose();
      this.courseVisuals = null;
    }
    const hole = getHole(holeIndex);
    this.courseVisuals = createCourseVisuals(hole, this.textures, this.isSoftwareGl);
    this.scene.add(this.courseVisuals.group);
    this.loadedHoleIndex = holeIndex;

    // Reset camera smoothly near tee
    const teeY = getElevationAt(hole, hole.tee.x, hole.tee.z);
    this.camPos.set(hole.tee.x, teeY + 11, hole.tee.z + 20);
    this.camLook.set(hole.cup.x, teeY + 1, hole.cup.z * 0.2);
  }

  private syncPlayersAndBalls(): void {
    const activeIds = new Set(this.state.players.map((p) => p.id));

    // Remove departed players
    for (const [id, rig] of this.golferRigs.entries()) {
      if (!activeIds.has(id)) {
        this.scene.remove(rig.root);
        this.golferRigs.delete(id);
      }
    }
    for (const [id, ball] of this.ballMeshes.entries()) {
      if (!activeIds.has(id)) {
        this.scene.remove(ball.mesh, ball.shadow, ball.ring);
        this.ballMeshes.delete(id);
      }
    }

    for (const player of this.state.players) {
      const charSpec = CHARACTERS[player.characterId];
      let rig = this.golferRigs.get(player.id);
      if (!rig) {
        rig = createGolferRig(charSpec, player.selectedClub, this.textures);
        this.scene.add(rig.root);
        this.golferRigs.set(player.id, rig);
      } else {
        rig.updateCharacter(charSpec);
      }

      const isActiveTurn = player.id === this.state.activePlayerId;
      const clubToUse =
        isActiveTurn && player.id === this.state.localPlayerId
          ? this.state.previewClubId
          : player.selectedClub;
      const yawToUse =
        isActiveTurn && player.id === this.state.localPlayerId
          ? this.state.previewAimYaw
          : player.aimYaw;
      const powerAuraOn =
        isActiveTurn && player.id === this.state.localPlayerId
          ? this.state.previewPowerActive
          : player.activePower;

      rig.setClub(clubToUse);
      rig.setPowerAura(powerAuraOn, charSpec.accentColor);

      // Stand on left side of the golf ball facing right toward target (classic right-handed stance)
      const sideOffset = 0.72;
      const screenRightX = -Math.cos(yawToUse);
      const screenRightZ = Math.sin(yawToUse);
      const hole = getHole(this.state.holeIndex);
      const standX = player.ballPos.x - screenRightX * sideOffset;
      const standZ = player.ballPos.z - screenRightZ * sideOffset;
      const standY = getElevationAt(hole, standX, standZ);

      rig.root.visible = !player.holedOut && this.state.screenState !== 'title';
      rig.root.position.set(standX, standY, standZ);
      rig.root.rotation.y = yawToUse - Math.PI / 2;

      // Golf Ball + Contact Shadow + Colored Indicator Ring
      let ballEntry = this.ballMeshes.get(player.id);
      if (!ballEntry) {
        const bGeo = new THREE.SphereGeometry(0.11, 16, 14);
        const bMat = new THREE.MeshStandardMaterial({
          color: 0xffffff,
          bumpMap: this.textures.ballBump,
          bumpScale: 0.012,
          roughness: 0.22,
          metalness: 0.06,
        });
        const bMesh = new THREE.Mesh(bGeo, bMat);
        bMesh.castShadow = !this.isSoftwareGl;

        const shGeo = new THREE.CircleGeometry(0.24, 16);
        shGeo.rotateX(-Math.PI / 2);
        const shMat = new THREE.MeshBasicMaterial({
          map: this.textures.contactShadowMap,
          transparent: true,
          opacity: 0.65,
          depthWrite: false,
        });
        const shMesh = new THREE.Mesh(shGeo, shMat);

        const rGeo = new THREE.RingGeometry(0.22, 0.3, 20);
        rGeo.rotateX(-Math.PI / 2);
        const rMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color(player.color),
          transparent: true,
          opacity: 0.85,
          side: THREE.DoubleSide,
          depthWrite: false,
        });
        const rMesh = new THREE.Mesh(rGeo, rMat);

        this.scene.add(bMesh, shMesh, rMesh);
        ballEntry = { mesh: bMesh, shadow: shMesh, ring: rMesh };
        this.ballMeshes.set(player.id, ballEntry);
      }

      if (!this.activeFlight || this.activeFlight.playerId !== player.id) {
        const showBall = !player.holedOut && this.state.screenState !== 'title';
        const onTee = getSurfaceAt(hole, player.ballPos.x, player.ballPos.z) === 'tee';
        ballEntry.mesh.visible = showBall;
        ballEntry.shadow.visible = showBall;
        ballEntry.ring.visible = showBall && isActiveTurn && !onTee;
        ballEntry.mesh.position.set(player.ballPos.x, player.ballPos.y + 0.065, player.ballPos.z);
        const gY = getElevationAt(hole, player.ballPos.x, player.ballPos.z);
        ballEntry.shadow.position.set(player.ballPos.x, gY + 0.02, player.ballPos.z);
        ballEntry.ring.position.set(player.ballPos.x, gY + 0.03, player.ballPos.z);
      }
    }
  }

  private updateAimPreview(): void {
    const canPreview =
      this.state.screenState === 'playing' &&
      !this.activeFlight &&
      this.state.activePlayerId === this.state.localPlayerId;

    if (!canPreview) {
      this.aimLine.visible = false;
      this.aimDotsInst.visible = false;
      this.landingRing.visible = false;
      return;
    }

    const activePlayer = this.state.players.find((p) => p.id === this.state.activePlayerId);
    if (!activePlayer || activePlayer.holedOut) {
      this.aimLine.visible = false;
      this.aimDotsInst.visible = false;
      this.landingRing.visible = false;
      return;
    }

    const char = CHARACTERS[activePlayer.characterId];
    const isLaserActive =
      this.state.previewPowerActive && char.specialPowerId === 'laser_aim';

    const previewSim = simulateShotTrajectory({
      holeIndex: this.state.holeIndex,
      startPos: activePlayer.ballPos,
      clubId: this.state.previewClubId,
      characterId: activePlayer.characterId,
      powerRatio: this.state.previewPowerRatio,
      aimYaw: this.state.previewAimYaw,
      wind: this.state.wind,
      powerActive: this.state.previewPowerActive,
    });

    const pts = previewSim.points;
    // Easy-play extended trajectory arc (92% by default, 100% + green highlight for Defne's Laser Aim)
    const limitIdx = isLaserActive ? pts.length : Math.max(4, Math.floor(pts.length * 0.92));
    const maxBufferPts = 90;
    const step = Math.max(1, Math.ceil(limitIdx / maxBufferPts));

    const attr = this.aimLineGeo.attributes.position as THREE.BufferAttribute;
    let count = 0;
    for (let i = 0; i < limitIdx && count < maxBufferPts; i += step) {
      const p = pts[i];
      attr.setXYZ(count, p.x, p.y + 0.08, p.z);
      count++;
    }
    if (isLaserActive && count < maxBufferPts && pts.length > 0) {
      const last = pts[pts.length - 1];
      attr.setXYZ(count, last.x, last.y + 0.08, last.z);
      count++;
    }
    attr.needsUpdate = true;
    this.aimLineGeo.setDrawRange(0, count);
    this.aimLine.visible = count >= 2;

    const clubColor = GOLF_CLUBS[this.state.previewClubId].accentColor;
    const lineHex = isLaserActive ? '#34d399' : this.state.previewClubId === 'putter' ? '#ffffff' : '#7dd3fc';
    (this.aimLine.material as THREE.LineBasicMaterial).color.set(lineHex);

    // Populate evenly spaced glowing trajectory beads along the arc
    const usableCount = Math.min(limitIdx, pts.length);
    const dotSizeBase = this.state.previewClubId === 'putter' ? 0.52 : 1.05;
    _quat.identity();
    for (let d = 0; d < this.aimDotCount; d++) {
      const pIdx = Math.min(
        usableCount - 1,
        Math.floor(((d + 1) / this.aimDotCount) * Math.max(1, usableCount - 1)),
      );
      if (usableCount >= 2 && pIdx >= 0) {
        const pt = pts[pIdx];
        _v1.set(pt.x, pt.y + 0.14, pt.z);
        const s = dotSizeBase * (1 - (d / this.aimDotCount) * 0.25);
        _scale.set(s, s, s);
      } else {
        _v1.set(0, -50, 0);
        _scale.set(0, 0, 0);
      }
      _mat4.compose(_v1, _quat, _scale);
      this.aimDotsInst.setMatrixAt(d, _mat4);
    }
    this.aimDotsInst.instanceMatrix.needsUpdate = true;
    (this.aimDotsInst.material as THREE.MeshBasicMaterial).color.set(
      isLaserActive ? '#6ee7b7' : '#e0f2fe',
    );
    this.aimDotsInst.visible = count >= 2;

    if (pts.length > 0) {
      const targetPt = isLaserActive ? previewSim.finalPos : pts[Math.min(pts.length - 1, limitIdx)];
      const hole = getHole(this.state.holeIndex);
      const gy = getElevationAt(hole, targetPt.x, targetPt.z);
      this.landingRing.position.set(targetPt.x, gy + 0.06, targetPt.z);
      this.landingRing.visible = true;
      (this.landingRing.material as THREE.MeshBasicMaterial).color.set(
        isLaserActive ? '#34d399' : clubColor,
      );
    }
  }

  private emitBurst(
    x: number,
    y: number,
    z: number,
    count: number,
    colorHex: number,
    speed: number,
  ): void {
    for (let i = 0; i < count; i++) {
      const p = this.particles[this.particleCursor];
      this.particleCursor = (this.particleCursor + 1) % this.particleCount;
      const angle = Math.random() * Math.PI * 2;
      const horiz = (0.3 + Math.random() * 0.7) * speed;
      p.active = true;
      p.x = x;
      p.y = y + 0.1;
      p.z = z;
      p.vx = Math.cos(angle) * horiz;
      p.vy = (0.5 + Math.random() * 0.8) * speed;
      p.vz = Math.sin(angle) * horiz;
      p.life = 0;
      p.maxLife = 0.45 + Math.random() * 0.45;
      p.size = 0.65 + Math.random() * 0.75;
      p.color.setHex(colorHex);
    }
  }

  private updateParticles(dt: number): void {
    let anyActive = false;
    for (let i = 0; i < this.particleCount; i++) {
      const p = this.particles[i];
      if (!p.active) continue;
      anyActive = true;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        _mat4.makeScale(0, 0, 0);
        this.particleInst.setMatrixAt(i, _mat4);
        continue;
      }
      p.vy -= 14 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      const s = p.size * (1 - p.life / p.maxLife);
      _v1.set(p.x, p.y, p.z);
      _quat.identity();
      _scale.set(s, s, s);
      _mat4.compose(_v1, _quat, _scale);
      this.particleInst.setMatrixAt(i, _mat4);
      this.particleInst.setColorAt(i, p.color);
    }
    if (anyActive) {
      this.particleInst.instanceMatrix.needsUpdate = true;
      if (this.particleInst.instanceColor) {
        this.particleInst.instanceColor.needsUpdate = true;
      }
    }
  }

  private updateFlight(dt: number): void {
    const flight = this.activeFlight;
    if (!flight) return;

    flight.elapsed += dt;
    const sim = flight.sim;
    const totalDur = Math.max(0.15, sim.durationSec);
    const tNorm = Math.min(1, flight.elapsed / totalDur);
    const exactIdx = tNorm * (sim.points.length - 1);
    const i0 = Math.floor(exactIdx);
    const i1 = Math.min(sim.points.length - 1, i0 + 1);
    const alpha = exactIdx - i0;

    const p0 = sim.points[i0];
    const p1 = sim.points[i1];
    const bx = p0.x + (p1.x - p0.x) * alpha;
    const by = p0.y + (p1.y - p0.y) * alpha;
    const bz = p0.z + (p1.z - p0.z) * alpha;

    const ballEntry = this.ballMeshes.get(flight.playerId);
    const hole = getHole(this.state.holeIndex);
    const gy = getElevationAt(hole, bx, bz);

    if (ballEntry) {
      ballEntry.mesh.visible = true;
      ballEntry.mesh.position.set(bx, by + 0.05, bz);
      ballEntry.mesh.rotation.x += dt * 12;
      ballEntry.shadow.visible = true;
      ballEntry.shadow.position.set(bx, gy + 0.02, bz);
      const heightRatio = Math.max(0.25, 1 - Math.max(0, by - gy) * 0.08);
      ballEntry.shadow.scale.setScalar(heightRatio);
    }

    // Append trail point
    if (this.trailCount < 258) {
      const idx3 = this.trailCount * 3;
      this.trailPoints[idx3] = bx;
      this.trailPoints[idx3 + 1] = by + 0.05;
      this.trailPoints[idx3 + 2] = bz;
      this.trailCount++;
      this.trailGeo.attributes.position.needsUpdate = true;
      this.trailGeo.setDrawRange(0, this.trailCount);
    }

    // Bounce sound + dust burst
    if (
      flight.nextBounceIdx < sim.bounces.length &&
      flight.elapsed >= sim.bounces[flight.nextBounceIdx]
    ) {
      flight.nextBounceIdx++;
      const surf = getSurfaceAt(hole, bx, bz);
      const inBunker = surf === 'bunker';
      golfAudio.playBounce(inBunker);
      this.emitBurst(bx, gy, bz, inBunker ? 12 : 6, inBunker ? 0xe8d49c : 0x65c96d, 3.2);
    }

    // Obstacle impact particles (tree foliage leaves, wood bark, granite sparks)
    const obsHits = sim.obstacleHits;
    if (
      obsHits &&
      flight.nextObstacleIdx < obsHits.length &&
      flight.elapsed >= obsHits[flight.nextObstacleIdx].timeSec
    ) {
      const hit = obsHits[flight.nextObstacleIdx];
      flight.nextObstacleIdx++;
      const burstColor =
        hit.kind === 'foliage'
          ? 0x4ade80
          : hit.kind === 'wood'
            ? 0x92400e
            : hit.kind === 'rock'
              ? 0xcbd5e1
              : 0xfef08a;
      this.emitBurst(hit.x, hit.y, hit.z, hit.kind === 'foliage' ? 14 : 10, burstColor, 4.8);
    }

    // Water splash near end
    if (sim.hitWater && !flight.splashTriggered && tNorm > 0.92) {
      flight.splashTriggered = true;
      golfAudio.playSplash();
      this.emitBurst(bx, -0.35, bz, 22, 0x7dd3fc, 6.2);
    }

    // Cup sink celebration
    if (sim.sunk && !flight.cupTriggered && tNorm > 0.96) {
      flight.cupTriggered = true;
      this.celebrationPlayerId = flight.playerId;
      this.celebrationTimer = 1.6;
      golfAudio.playCupSink();
      const cup = getHoleCupPos(hole);
      this.emitBurst(cup.x, cup.y + 0.4, cup.z, 32, 0xfbbf24, 7.0);
    }

    if (tNorm >= 1) {
      const done = flight.onComplete;
      this.activeFlight = null;
      this.trailLine.visible = false;
      done();
    }
  }

  private updateCameraAndAnimations(dt: number): void {
    const hole = getHole(this.state.holeIndex);
    const cup = getHoleCupPos(hole);

    // Gentle cloud & blimp drift
    this.cloudsGroup.rotation.y += dt * 0.004;
    this.blimpGroup.position.x = -48 + Math.sin(this.elapsedTotal * 0.08) * 9;
    this.blimpGroup.position.y = 34 + Math.sin(this.elapsedTotal * 0.65) * 0.75;

    // Animate waving flag cloth gently with wind
    if (this.courseVisuals) {
      const flag = this.courseVisuals.flagCloth;
      flag.rotation.y =
        Math.atan2(this.state.wind.x, this.state.wind.z) +
        Math.sin(this.elapsedTotal * 3.8) * 0.14;
    }

    // Animate golfer swing, celebration fist-pump, torso coil & natural breathing
    let rigIdx = 0;
    if (this.celebrationTimer > 0) {
      this.celebrationTimer = Math.max(0, this.celebrationTimer - dt);
    }
    for (const [pid, rig] of this.golferRigs.entries()) {
      let targetSwing = 0;
      if (this.celebrationPlayerId === pid && this.celebrationTimer > 0) {
        targetSwing = 1.45 + Math.sin(this.elapsedTotal * 12) * 0.25;
      } else if (this.swingAnimPlayerId === pid && this.swingAnimTimer > 0) {
        this.swingAnimTimer = Math.max(0, this.swingAnimTimer - dt);
        const p = 1 - this.swingAnimTimer / 0.48;
        // Fast downswing -> follow-through
        targetSwing =
          p < 0.35
            ? THREE.MathUtils.lerp(-1.25, 0.9, p / 0.35)
            : THREE.MathUtils.lerp(0.9, 0.15, (p - 0.35) / 0.65);
      } else if (
        this.state.screenState === 'playing' &&
        pid === this.state.activePlayerId &&
        pid === this.state.localPlayerId &&
        this.state.isCharging
      ) {
        targetSwing = -1.3 * this.state.previewPowerRatio;
      }
      rig.swingPivot.rotation.z = THREE.MathUtils.damp(
        rig.swingPivot.rotation.z,
        targetSwing,
        14,
        dt,
      );
      // Lifelike shoulder/torso rotation & subtle idle chest breathing
      rig.upperBodyPivot.rotation.y = rig.swingPivot.rotation.z * 0.28;
      rig.upperBodyPivot.scale.y = 1 + Math.sin(this.elapsedTotal * 2.1 + rigIdx * 1.4) * 0.008;
      rigIdx++;

      if (rig.powerAura.visible) {
        rig.powerAura.rotation.z += dt * 1.4;
      }
    }

    // Camera choreography
    if (this.state.screenState === 'title') {
      // Atmospheric Title Flyover Pan around the golf course
      const t = this.elapsedTotal * 0.16;
      const midX = (hole.tee.x + cup.x) * 0.5;
      const midZ = (hole.tee.z + cup.z) * 0.5;
      _v1.set(midX + Math.sin(t) * 52, 22 + Math.cos(t * 0.7) * 4, midZ + Math.cos(t) * 74);
      _v2.set(cup.x * 0.4, 2.0, cup.z * 0.35);
      this.camPos.lerp(_v1, 1 - Math.exp(-3 * dt));
      this.camLook.lerp(_v2, 1 - Math.exp(-3 * dt));
    } else if (this.activeFlight) {
      const ball = this.ballMeshes.get(this.activeFlight.playerId)?.mesh;
      if (ball) {
        const bp = ball.position;
        const dirX = Math.sin(this.state.previewAimYaw);
        const dirZ = Math.cos(this.state.previewAimYaw);
        _v1.set(
          bp.x - dirX * 11,
          Math.max(bp.y + 4.8, getElevationAt(hole, bp.x, bp.z) + 4.5),
          bp.z - dirZ * 11,
        );
        _v2.set(bp.x + dirX * 8, bp.y + 0.5, bp.z + dirZ * 8);
        this.camPos.x = THREE.MathUtils.damp(this.camPos.x, _v1.x, 5.5, dt);
        this.camPos.y = THREE.MathUtils.damp(this.camPos.y, _v1.y, 5.5, dt);
        this.camPos.z = THREE.MathUtils.damp(this.camPos.z, _v1.z, 5.5, dt);
        this.camLook.x = THREE.MathUtils.damp(this.camLook.x, _v2.x, 8, dt);
        this.camLook.y = THREE.MathUtils.damp(this.camLook.y, _v2.y, 8, dt);
        this.camLook.z = THREE.MathUtils.damp(this.camLook.z, _v2.z, 8, dt);
      }
    } else {
      const activePlayer =
        this.state.players.find((p) => p.id === this.state.activePlayerId) ?? this.state.players[0];
      if (activePlayer) {
        const bp: Vec3 = activePlayer.ballPos;
        const yaw =
          activePlayer.id === this.state.localPlayerId
            ? this.state.previewAimYaw
            : activePlayer.aimYaw;
        const fwdX = Math.sin(yaw);
        const fwdZ = Math.cos(yaw);
        const screenRightX = -Math.cos(yaw);
        const screenRightZ = Math.sin(yaw);

        if (this.state.cameraMode === 'overhead') {
          const midX = (bp.x + cup.x) * 0.5;
          const midZ = (bp.z + cup.z) * 0.5;
          const dist = Math.hypot(cup.x - bp.x, cup.z - bp.z);
          _v1.set(midX + 18, Math.max(32, dist * 0.62), midZ + 26);
          _v2.set(midX, 1.0, midZ);
        } else if (this.state.cameraMode === 'follow') {
          _v1.set(bp.x - fwdX * 14, bp.y + 7.2, bp.z - fwdZ * 14);
          _v2.set(bp.x + fwdX * 22, bp.y + 1.2, bp.z + fwdZ * 22);
        } else {
          // Reference Switch Sports framing: golfer left-of-center, tee + ball + white strip + lake + flag + skyline cleanly framed
          const distToCup = Math.hypot(cup.x - bp.x, cup.z - bp.z);
          const backDist = distToCup < 18 ? 4.8 : 5.35;
          const camH = distToCup < 18 ? 2.1 : 2.32;
          _v1.set(
            bp.x - fwdX * backDist + screenRightX * 0.55,
            bp.y + camH,
            bp.z - fwdZ * backDist + screenRightZ * 0.55,
          );
          _v2.set(
            bp.x + fwdX * 19 + screenRightX * 0.85,
            bp.y + 0.85,
            bp.z + fwdZ * 19 + screenRightZ * 0.85,
          );
        }

        if (this.snapCameraNextFrame) {
          this.camPos.copy(_v1);
          this.camLook.copy(_v2);
          this.snapCameraNextFrame = false;
        } else {
          this.camPos.x = THREE.MathUtils.damp(this.camPos.x, _v1.x, 6.5, dt);
          this.camPos.y = THREE.MathUtils.damp(this.camPos.y, _v1.y, 6.5, dt);
          this.camPos.z = THREE.MathUtils.damp(this.camPos.z, _v1.z, 6.5, dt);
          this.camLook.x = THREE.MathUtils.damp(this.camLook.x, _v2.x, 7.5, dt);
          this.camLook.y = THREE.MathUtils.damp(this.camLook.y, _v2.y, 7.5, dt);
          this.camLook.z = THREE.MathUtils.damp(this.camLook.z, _v2.z, 7.5, dt);
        }
      }
    }

    // Apply decaying trauma camera shake & dynamic FOV kick during fast ball flight
    this.camera.position.copy(this.camPos);
    if (this.cameraShakeTrauma > 0.001) {
      const shake = this.cameraShakeTrauma * this.cameraShakeTrauma;
      this.camera.position.x += (Math.random() - 0.5) * shake * 0.7;
      this.camera.position.y += (Math.random() - 0.5) * shake * 0.7;
      this.cameraShakeTrauma = Math.max(0, this.cameraShakeTrauma - dt * 1.9);
    }

    const targetFov = this.activeFlight && this.activeFlight.clubId === 'driver' ? 54 : 48;
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 6, dt);
      this.camera.updateProjectionMatrix();
    }

    this.camera.lookAt(this.camLook);
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.destroyed) return;
      const status = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (status === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.destroyed) return;
    const now = performance.now();
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (this.state.screenState !== 'paused') {
      this.elapsedTotal += dt;
      this.updateFlight(dt);
      this.updateParticles(dt);
      this.updateCameraAndAnimations(dt);
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private handleResize(): void {
    if (this.destroyed) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    if (width === 0 || height === 0) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public dispose(): void {
    this.destroyed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    this.renderer.domElement.removeEventListener('pointerdown', this.handlePointerDown);
    window.removeEventListener('pointermove', this.handlePointerMove);
    window.removeEventListener('pointerup', this.handlePointerUp);
    window.removeEventListener('pointercancel', this.handlePointerUp);
    if (this.courseVisuals) {
      this.courseVisuals.dispose();
    }
    this.aimLineGeo.dispose();
    this.aimDotsInst.geometry.dispose();
    (this.aimDotsInst.material as THREE.Material).dispose();
    this.trailGeo.dispose();
    this.particleInst.geometry.dispose();
    (this.particleInst.material as THREE.Material).dispose();
    Object.values(this.textures).forEach((t) => (t as THREE.Texture).dispose());
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
