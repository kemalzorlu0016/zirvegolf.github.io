import * as THREE from 'three';

export interface ProceduralGolfTextures {
  fairwayMap: THREE.CanvasTexture;
  greenMap: THREE.CanvasTexture;
  sandMap: THREE.CanvasTexture;
  grassRoughBump: THREE.CanvasTexture;
  ballBump: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  faceMap: THREE.CanvasTexture;
  fabricBump: THREE.CanvasTexture;
  barkMap: THREE.CanvasTexture;
}

export function createProceduralGolfTextures(maxAnisotropy: number): ProceduralGolfTextures {
  // 1. Realistic natural organic golf turf (9,000+ dense grass blades + soil grain + subtle mowing sheen)
  const fairwayCanvas = document.createElement('canvas');
  fairwayCanvas.width = 256;
  fairwayCanvas.height = 256;
  const fCtx = fairwayCanvas.getContext('2d')!;
  fCtx.fillStyle = '#cbe0be';
  fCtx.fillRect(0, 0, 256, 256);

  // Soft natural organic patches (subtle clover/soil richness without hard geometric grid)
  for (let i = 0; i < 90; i++) {
    const px = Math.random() * 256;
    const py = Math.random() * 256;
    const rad = 14 + Math.random() * 28;
    const g = fCtx.createRadialGradient(px, py, 2, px, py, rad);
    const darker = Math.random() > 0.45;
    g.addColorStop(0, darker ? 'rgba(42, 92, 34, 0.14)' : 'rgba(242, 252, 224, 0.12)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    fCtx.fillStyle = g;
    fCtx.fillRect(px - rad, py - rad, rad * 2, rad * 2);
  }

  // Dense realistic individual grass blades & micro-tufts
  for (let i = 0; i < 9500; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const h = 2 + Math.random() * 4.5;
    const tilt = (Math.random() - 0.5) * 2.2;
    const r = Math.random();
    fCtx.strokeStyle =
      r < 0.34
        ? 'rgba(24, 68, 22, 0.28)'
        : r < 0.7
          ? 'rgba(72, 136, 56, 0.24)'
          : 'rgba(232, 248, 200, 0.22)';
    fCtx.lineWidth = 1.05;
    fCtx.beginPath();
    fCtx.moveTo(x, y);
    fCtx.lineTo(x + tilt, y - h);
    fCtx.stroke();
  }
  const fairwayMap = new THREE.CanvasTexture(fairwayCanvas);
  fairwayMap.colorSpace = THREE.SRGBColorSpace;
  fairwayMap.wrapS = fairwayMap.wrapT = THREE.RepeatWrapping;
  fairwayMap.repeat.set(34, 42);
  fairwayMap.anisotropy = maxAnisotropy;

  // 2. Putting green ultra-fine velvet cut (subtle soft longitudinal mowing grain + micro blades)
  const greenCanvas = document.createElement('canvas');
  greenCanvas.width = 256;
  greenCanvas.height = 256;
  const gCtx = greenCanvas.getContext('2d')!;
  const mowGrad = gCtx.createLinearGradient(0, 0, 256, 0);
  mowGrad.addColorStop(0, '#44a846');
  mowGrad.addColorStop(0.49, '#49b34b');
  mowGrad.addColorStop(0.5, '#3b963d');
  mowGrad.addColorStop(1, '#3f9d41');
  gCtx.fillStyle = mowGrad;
  gCtx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 5500; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    gCtx.fillStyle = Math.random() > 0.5 ? 'rgba(235,255,220,0.08)' : 'rgba(12,48,14,0.09)';
    gCtx.fillRect(x, y, 1.4, 2.2);
  }
  const greenMap = new THREE.CanvasTexture(greenCanvas);
  greenMap.colorSpace = THREE.SRGBColorSpace;
  greenMap.wrapS = greenMap.wrapT = THREE.RepeatWrapping;
  greenMap.repeat.set(8, 8);
  greenMap.anisotropy = maxAnisotropy;

  // 3. Rippled bunker sand texture
  const sandCanvas = document.createElement('canvas');
  sandCanvas.width = 256;
  sandCanvas.height = 256;
  const sCtx = sandCanvas.getContext('2d')!;
  sCtx.fillStyle = '#e5cf9c';
  sCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 3200; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    sCtx.fillStyle = Math.random() > 0.5 ? 'rgba(255,250,235,0.22)' : 'rgba(155,120,70,0.18)';
    sCtx.fillRect(x, y, 2, 2);
  }
  for (let y = 0; y < 256; y += 9) {
    sCtx.strokeStyle = 'rgba(162, 130, 78, 0.28)';
    sCtx.lineWidth = 2;
    sCtx.beginPath();
    for (let x = 0; x <= 256; x += 16) {
      const wave = Math.sin((x / 256) * Math.PI * 4 + y * 0.1) * 2;
      if (x === 0) sCtx.moveTo(x, y + wave);
      else sCtx.lineTo(x, y + wave);
    }
    sCtx.stroke();
  }
  const sandMap = new THREE.CanvasTexture(sandCanvas);
  sandMap.colorSpace = THREE.SRGBColorSpace;
  sandMap.wrapS = sandMap.wrapT = THREE.RepeatWrapping;
  sandMap.repeat.set(4, 4);
  sandMap.anisotropy = maxAnisotropy;

  // 4. Crisp high-frequency Grass Blade Micro-Relief Bump Map
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 128;
  bumpCanvas.height = 128;
  const bCtx = bumpCanvas.getContext('2d')!;
  bCtx.fillStyle = '#7c7c7c';
  bCtx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 4200; i++) {
    const x = Math.random() * 128;
    const y = Math.random() * 128;
    const shade = 55 + Math.floor(Math.random() * 145);
    bCtx.fillStyle = `rgb(${shade},${shade},${shade})`;
    bCtx.fillRect(x, y, 1.5, 3);
  }
  const grassRoughBump = new THREE.CanvasTexture(bumpCanvas);
  grassRoughBump.wrapS = grassRoughBump.wrapT = THREE.RepeatWrapping;
  grassRoughBump.repeat.set(38, 38);

  // 5. Golf ball dimple bump map
  const ballCanvas = document.createElement('canvas');
  ballCanvas.width = 128;
  ballCanvas.height = 64;
  const blCtx = ballCanvas.getContext('2d')!;
  blCtx.fillStyle = '#dcdcdc';
  blCtx.fillRect(0, 0, 128, 64);
  blCtx.fillStyle = '#585858';
  for (let y = 4; y < 64; y += 8) {
    const offset = ((y / 8) % 2) * 4;
    for (let x = 4; x < 128; x += 8) {
      blCtx.beginPath();
      blCtx.arc((x + offset) % 128, y, 2.2, 0, Math.PI * 2);
      blCtx.fill();
    }
  }
  const ballBump = new THREE.CanvasTexture(ballCanvas);
  ballBump.wrapS = ballBump.wrapT = THREE.RepeatWrapping;

  // 6. Soft radial contact shadow disc
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 64;
  shadowCanvas.height = 64;
  const shCtx = shadowCanvas.getContext('2d')!;
  const grad = shCtx.createRadialGradient(32, 32, 4, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.58)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.24)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  shCtx.fillStyle = grad;
  shCtx.fillRect(0, 0, 64, 64);
  const contactShadowMap = new THREE.CanvasTexture(shadowCanvas);

  // 7. Lifelike Human Face Texture (UV mapped onto head sphere: center X=256 is +X/+Z front)
  const faceCanvas = document.createElement('canvas');
  faceCanvas.width = 512;
  faceCanvas.height = 256;
  const fc = faceCanvas.getContext('2d')!;
  // Natural skin gradient with warm undertones & cheek blush
  const skinGrad = fc.createLinearGradient(0, 0, 0, 256);
  skinGrad.addColorStop(0, '#d59a74');
  skinGrad.addColorStop(0.5, '#deaa86');
  skinGrad.addColorStop(1, '#c48560');
  fc.fillStyle = skinGrad;
  fc.fillRect(0, 0, 512, 256);

  // Subtle skin pore warmth & cheek tone around front face (u ~ 0.75 -> x ~ 384 or center 256 depending on rotation)
  // Place facial features centered at x = 256 (we rotate head geometry so u=0.5 faces +Z!)
  const cheekL = fc.createRadialGradient(212, 146, 2, 212, 146, 24);
  cheekL.addColorStop(0, 'rgba(218, 125, 108, 0.28)');
  cheekL.addColorStop(1, 'rgba(218, 125, 108, 0)');
  fc.fillStyle = cheekL;
  fc.fillRect(180, 120, 64, 54);

  const cheekR = fc.createRadialGradient(300, 146, 2, 300, 146, 24);
  cheekR.addColorStop(0, 'rgba(218, 125, 108, 0.28)');
  cheekR.addColorStop(1, 'rgba(218, 125, 108, 0)');
  fc.fillStyle = cheekR;
  fc.fillRect(268, 120, 64, 54);

  // Eyebrows
  fc.strokeStyle = '#3b281e';
  fc.lineWidth = 4.2;
  fc.lineCap = 'round';
  fc.beginPath();
  fc.moveTo(212, 108);
  fc.quadraticCurveTo(226, 102, 240, 108);
  fc.moveTo(272, 108);
  fc.quadraticCurveTo(286, 102, 300, 108);
  fc.stroke();

  // Realistic Eyes (sclera + hazel/brown iris + pupil + specular catchlight)
  [226, 286].forEach((ex) => {
    fc.fillStyle = '#f8fafc';
    fc.beginPath();
    fc.ellipse(ex, 122, 11, 5.5, 0, 0, Math.PI * 2);
    fc.fill();
    // Iris
    fc.fillStyle = '#4a3525';
    fc.beginPath();
    fc.arc(ex, 122, 4.8, 0, Math.PI * 2);
    fc.fill();
    // Pupil
    fc.fillStyle = '#111827';
    fc.beginPath();
    fc.arc(ex, 122, 2.4, 0, Math.PI * 2);
    fc.fill();
    // Catchlight
    fc.fillStyle = '#ffffff';
    fc.beginPath();
    fc.arc(ex + 1.5, 120.5, 1.1, 0, Math.PI * 2);
    fc.fill();
    // Upper lash line
    fc.strokeStyle = '#291c15';
    fc.lineWidth = 2.2;
    fc.beginPath();
    fc.arc(ex, 123, 10.5, Math.PI * 1.12, Math.PI * 1.88);
    fc.stroke();
  });

  // Subtle nose bridge shading
  fc.strokeStyle = 'rgba(165, 110, 82, 0.45)';
  fc.lineWidth = 2.5;
  fc.beginPath();
  fc.moveTo(256, 124);
  fc.lineTo(254, 145);
  fc.quadraticCurveTo(256, 149, 260, 146);
  fc.stroke();

  // Natural mouth / lips
  fc.fillStyle = '#c4796b';
  fc.beginPath();
  fc.moveTo(240, 168);
  fc.quadraticCurveTo(256, 163, 272, 168);
  fc.quadraticCurveTo(256, 177, 240, 168);
  fc.fill();
  fc.strokeStyle = 'rgba(110, 58, 48, 0.55)';
  fc.lineWidth = 1.4;
  fc.beginPath();
  fc.moveTo(242, 168);
  fc.quadraticCurveTo(256, 170, 270, 168);
  fc.stroke();

  const faceMap = new THREE.CanvasTexture(faceCanvas);
  faceMap.colorSpace = THREE.SRGBColorSpace;
  faceMap.anisotropy = maxAnisotropy;

  // 8. Knit Polo Fabric Weave Bump Map
  const fabCanvas = document.createElement('canvas');
  fabCanvas.width = 64;
  fabCanvas.height = 64;
  const fb = fabCanvas.getContext('2d')!;
  fb.fillStyle = '#808080';
  fb.fillRect(0, 0, 64, 64);
  for (let y = 0; y < 64; y += 4) {
    for (let x = 0; x < 64; x += 4) {
      fb.fillStyle = (x + y) % 8 === 0 ? '#a4a4a4' : '#646464';
      fb.fillRect(x, y, 2, 2);
    }
  }
  const fabricBump = new THREE.CanvasTexture(fabCanvas);
  fabricBump.wrapS = fabricBump.wrapT = THREE.RepeatWrapping;
  fabricBump.repeat.set(8, 8);

  // 9. Pine Tree Bark Texture
  const barkCanvas = document.createElement('canvas');
  barkCanvas.width = 128;
  barkCanvas.height = 128;
  const bk = barkCanvas.getContext('2d')!;
  bk.fillStyle = '#4a3222';
  bk.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 240; i++) {
    const x = Math.random() * 128;
    const y = Math.random() * 128;
    bk.fillStyle = Math.random() > 0.5 ? '#352216' : '#5e422e';
    bk.fillRect(x, y, 3, 12 + Math.random() * 16);
  }
  const barkMap = new THREE.CanvasTexture(barkCanvas);
  barkMap.colorSpace = THREE.SRGBColorSpace;
  barkMap.wrapS = barkMap.wrapT = THREE.RepeatWrapping;
  barkMap.repeat.set(2, 3);
  barkMap.anisotropy = maxAnisotropy;

  return {
    fairwayMap,
    greenMap,
    sandMap,
    grassRoughBump,
    ballBump,
    contactShadowMap,
    faceMap,
    fabricBump,
    barkMap,
  };
}
