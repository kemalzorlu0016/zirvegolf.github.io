import * as THREE from 'three';
import {
  getBroadleafTreeCoords,
  getElevationAt,
  getHoleCupPos,
  getResortTentCoords,
  getSurfaceAt,
} from '../game/courses.ts';
import type { CharacterSpec, ClubId, HoleDefinition } from '../game/types.ts';
import type { ProceduralGolfTextures } from './textures.ts';

export interface GolferRig {
  root: THREE.Group;
  upperBodyPivot: THREE.Group;
  swingPivot: THREE.Group;
  clubHeads: Record<ClubId, THREE.Object3D>;
  powerAura: THREE.Mesh;
  updateCharacter: (char: CharacterSpec) => void;
  setClub: (clubId: ClubId) => void;
  setPowerAura: (active: boolean, colorHex: string) => void;
}

function createLatheLimb(
  rBottom: number,
  rMid: number,
  rTop: number,
  height: number,
  radialSegments = 16,
): THREE.LatheGeometry {
  const pts = [
    new THREE.Vector2(0.001, 0),
    new THREE.Vector2(rBottom, 0.02 * height),
    new THREE.Vector2(rBottom * 0.92, 0.22 * height),
    new THREE.Vector2(rMid, 0.55 * height),
    new THREE.Vector2(rTop * 0.98, 0.88 * height),
    new THREE.Vector2(rTop * 0.85, height),
    new THREE.Vector2(0.001, height),
  ];
  return new THREE.LatheGeometry(pts, radialSegments);
}

export function createGolferRig(
  initialChar: CharacterSpec,
  initialClub: ClubId,
  textures: ProceduralGolfTextures,
): GolferRig {
  const root = new THREE.Group();

  // Calibrated PBR Materials (matte cloth/skin have low envMapIntensity so outdoor lighting looks natural, not plastic)
  const primaryMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialChar.primaryColor),
    bumpMap: textures.fabricBump,
    bumpScale: 0.008,
    roughness: 0.78,
    metalness: 0.02,
    envMapIntensity: 0.25,
  });
  const secondaryMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialChar.secondaryColor),
    bumpMap: textures.fabricBump,
    bumpScale: 0.006,
    roughness: 0.84,
    metalness: 0.02,
    envMapIntensity: 0.22,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialChar.accentColor),
    roughness: 0.28,
    metalness: 0.72,
    envMapIntensity: 0.9,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xd89f79,
    roughness: 0.65,
    metalness: 0.01,
    envMapIntensity: 0.16,
  });
  const faceMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.faceMap,
    roughness: 0.54,
    metalness: 0.01,
    envMapIntensity: 0.22,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: 0x261a14,
    roughness: 0.72,
    metalness: 0.05,
    envMapIntensity: 0.25,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    roughness: 0.42,
    metalness: 0.08,
    envMapIntensity: 0.45,
  });
  const soleMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.85,
    metalness: 0.05,
    envMapIntensity: 0.2,
  });
  const gloveMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.65,
    metalness: 0.02,
    envMapIntensity: 0.3,
  });
  const shaftMat = new THREE.MeshStandardMaterial({
    color: 0xcbd5e1,
    roughness: 0.18,
    metalness: 0.92,
    envMapIntensity: 1.0,
  });
  const gripMat = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    roughness: 0.88,
    metalness: 0.04,
    envMapIntensity: 0.2,
  });

  // 1. Grounded Sculpted Athletic Golf Shoes (sole + contoured upper + heel)
  const buildShoe = (x: number) => {
    const shoeGrp = new THREE.Group();
    shoeGrp.position.set(x, 0, 0.03);
    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.125, 0.032, 0.28), soleMat);
    sole.position.set(0, 0.016, 0.02);
    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.056, 0.14, 6, 12), shoeMat);
    upper.rotation.x = Math.PI / 2;
    upper.scale.set(1.05, 1.0, 0.78);
    upper.position.set(0, 0.055, 0.02);
    upper.castShadow = true;
    const tongue = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.03, 0.07), accentMat);
    tongue.position.set(0, 0.085, 0.01);
    tongue.rotation.x = -0.35;
    shoeGrp.add(sole, upper, tongue);
    return shoeGrp;
  };
  root.add(buildShoe(-0.145), buildShoe(0.145));

  // 2. Anatomically Contoured Legs + Sporty Side Accent Stripe
  const calfGeo = createLatheLimb(0.048, 0.068, 0.064, 0.42, 16);
  const thighGeo = createLatheLimb(0.066, 0.084, 0.095, 0.42, 16);
  const legStripeGeo = new THREE.BoxGeometry(0.022, 0.36, 0.028);

  [-0.145, 0.145].forEach((lx) => {
    const legRoot = new THREE.Group();
    legRoot.position.set(lx, 0.08, 0);

    const calf = new THREE.Mesh(calfGeo, secondaryMat);
    calf.rotation.x = 0.12;
    calf.castShadow = true;
    legRoot.add(calf);

    const thigh = new THREE.Mesh(thighGeo, secondaryMat);
    thigh.position.set(0, 0.39, 0.048);
    thigh.rotation.x = -0.14;
    thigh.castShadow = true;
    legRoot.add(thigh);

    const stripe = new THREE.Mesh(legStripeGeo, primaryMat);
    stripe.position.set(lx < 0 ? -0.064 : 0.064, 0.48, 0.025);
    legRoot.add(stripe);

    root.add(legRoot);
  });

  // 3. Pelvis / Belt / Metallic Buckle
  const pelvis = new THREE.Mesh(
    new THREE.CylinderGeometry(0.165, 0.18, 0.16, 18),
    secondaryMat,
  );
  pelvis.scale.set(1.12, 1, 0.82);
  pelvis.position.set(0, 0.87, 0);
  pelvis.castShadow = true;

  const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.172, 0.172, 0.048, 18), gripMat);
  belt.scale.set(1.12, 1, 0.84);
  belt.position.set(0, 0.94, 0);

  const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.046, 0.025), accentMat);
  buckle.position.set(0, 0.94, 0.145);
  root.add(pelvis, belt, buckle);

  // 4. Upper Body Pivot (Athletic 20° Forward Golf Address Hinge + Breathing)
  const upperBodyPivot = new THREE.Group();
  upperBodyPivot.position.set(0, 0.95, 0);
  upperBodyPivot.rotation.x = 0.32; // Lifelike forward athletic golf posture
  root.add(upperBodyPivot);

  // Contoured Human Torso (LatheGeometry chest + waist taper + shoulder width)
  const torsoPts = [
    new THREE.Vector2(0.001, 0),
    new THREE.Vector2(0.16, 0.02),
    new THREE.Vector2(0.155, 0.18),
    new THREE.Vector2(0.195, 0.38),
    new THREE.Vector2(0.21, 0.5),
    new THREE.Vector2(0.14, 0.56),
    new THREE.Vector2(0.001, 0.56),
  ];
  const torsoGeo = new THREE.LatheGeometry(torsoPts, 20);
  const torso = new THREE.Mesh(torsoGeo, primaryMat);
  torso.scale.set(1.16, 1, 0.78);
  torso.castShadow = true;
  upperBodyPivot.add(torso);

  // White Athletic Jacket Collar Trim & Placket Detail
  const whiteTrimMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5, metalness: 0.05 });
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.095, 0.026, 10, 18), whiteTrimMat);
  collar.rotation.x = Math.PI / 2 + 0.15;
  collar.position.set(0, 0.545, 0.01);
  const placket = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.16, 0.02), whiteTrimMat);
  placket.position.set(0, 0.45, 0.145);
  upperBodyPivot.add(collar, placket);

  // 5. Neck & Lifelike Sculpted Head (looking down toward the golf ball!)
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.056, 0.068, 0.13, 14), skinMat);
  neck.position.set(0, 0.59, 0.01);
  upperBodyPivot.add(neck);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.72, 0.02);
  headGroup.rotation.set(0.22, 0.24, 0); // Natural gaze focused down toward ball & target line
  upperBodyPivot.add(headGroup);

  // Cranium + Jawline sphere scaled anatomically; rotated -PI/2 on Y so UV u=0.5 faces +Z!
  const headGeo = new THREE.SphereGeometry(0.125, 24, 20);
  headGeo.rotateY(-Math.PI / 2);
  const headMesh = new THREE.Mesh(headGeo, faceMat);
  headMesh.scale.set(0.92, 1.12, 1.02);
  headMesh.castShadow = true;
  headGroup.add(headMesh);

  // Subtle 3D Nose Bridge & Ears for authentic silhouette from every camera angle
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.018, 0.048, 8), skinMat);
  nose.rotation.x = Math.PI * 0.42;
  nose.position.set(0, -0.01, 0.125);
  const earGeo = new THREE.SphereGeometry(0.026, 10, 8);
  const leftEar = new THREE.Mesh(earGeo, skinMat);
  leftEar.scale.set(0.5, 1.1, 0.75);
  leftEar.position.set(-0.115, -0.005, -0.01);
  const rightEar = new THREE.Mesh(earGeo, skinMat);
  rightEar.scale.set(0.5, 1.1, 0.75);
  rightEar.position.set(0.115, -0.005, -0.01);
  headGroup.add(nose, leftEar, rightEar);

  // Hair covering back & sides (-Z, leaving +Z face clean!) + Character-Specific Headwear
  const hairBack = new THREE.Mesh(
    new THREE.SphereGeometry(0.129, 18, 14, Math.PI * 1.05, Math.PI * 0.9, 0.08 * Math.PI, Math.PI * 0.56),
    hairMat,
  );
  hairBack.scale.set(0.95, 1.12, 1.04);
  headGroup.add(hairBack);

  const ponytail = new THREE.Mesh(new THREE.CapsuleGeometry(0.032, 0.14, 6, 10), hairMat);
  ponytail.position.set(0, -0.04, -0.14);
  ponytail.rotation.x = 0.55;
  headGroup.add(ponytail);

  const topBun = new THREE.Group();
  const bunBase = new THREE.Mesh(new THREE.SphereGeometry(0.072, 14, 12), hairMat);
  bunBase.position.set(0, 0.165, -0.055);
  const hairCrown = new THREE.Mesh(
    new THREE.SphereGeometry(0.132, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.52),
    hairMat,
  );
  hairCrown.scale.set(0.95, 1.06, 1.04);
  topBun.add(hairCrown, bunBase);
  headGroup.add(topBun);

  const hatGroup = new THREE.Group();
  hatGroup.position.set(0, 0.028, 0);
  const capCrown = new THREE.Mesh(
    new THREE.SphereGeometry(0.132, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.48),
    primaryMat,
  );
  capCrown.scale.set(0.95, 1.04, 1.05);
  const capBrim = new THREE.Mesh(
    new THREE.CylinderGeometry(0.136, 0.14, 0.014, 18, 1, false, -0.75, 1.5),
    accentMat,
  );
  capBrim.position.set(0, 0.005, 0.085);
  capBrim.rotation.x = 0.14;

  const sunBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.26, 0.014, 22), secondaryMat);
  sunBrim.position.set(0, 0.005, 0);

  const beretTop = new THREE.Mesh(new THREE.SphereGeometry(0.142, 16, 12), primaryMat);
  beretTop.scale.set(1.08, 0.42, 1.08);
  beretTop.position.set(0.02, 0.05, -0.01);

  hatGroup.add(capCrown, capBrim, sunBrim, beretTop);
  headGroup.add(hatGroup);

  const applyCharacterVisuals = (char: CharacterSpec) => {
    primaryMat.color.set(char.primaryColor);
    secondaryMat.color.set(char.secondaryColor);
    accentMat.color.set(char.accentColor);
    const isFemale = char.id === 'defne' || char.id === 'ece';
    const isDefneBun = char.id === 'defne';
    ponytail.visible = isFemale && !isDefneBun;
    topBun.visible = isDefneBun;
    hairMat.color.setHex(char.id === 'defne' ? 0xc25e1a : char.id === 'ece' ? 0x4a2c18 : 0x1c1512);

    hatGroup.visible = !isDefneBun;
    capCrown.visible = char.hatStyle === 'cap' || char.hatStyle === 'visor' || char.hatStyle === 'sunhat';
    capBrim.visible = char.hatStyle === 'cap' || char.hatStyle === 'visor';
    sunBrim.visible = char.hatStyle === 'sunhat';
    beretTop.visible = char.hatStyle === 'beret';
  };
  applyCharacterVisuals(initialChar);

  // 6. Seamlessly Jointed Two-Handed Golf Swing Pivot (Shoulders -> Elbows -> Gloved Hands -> Club Grip)
  const swingPivot = new THREE.Group();
  swingPivot.position.set(0, 0.48, 0.04);
  upperBodyPivot.add(swingPivot);

  const upAxis = new THREE.Vector3(0, 1, 0);
  const addSegmentBetween = (
    parent: THREE.Group,
    a: THREE.Vector3,
    b: THREE.Vector3,
    rA: number,
    rB: number,
    mat: THREE.Material,
  ) => {
    const dir = new THREE.Vector3().subVectors(b, a);
    const len = dir.length();
    const geo = new THREE.CylinderGeometry(rB, rA, len, 12);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(a).addScaledVector(dir, 0.5);
    mesh.quaternion.setFromUnitVectors(upAxis, dir.normalize());
    mesh.castShadow = true;
    parent.add(mesh);
    return mesh;
  };

  // Exact anatomical landmarks in swingPivot space so hands meet cleanly on the grip!
  const lShoulder = new THREE.Vector3(-0.21, -0.02, 0.0);
  const lElbow = new THREE.Vector3(-0.22, -0.25, 0.14);
  const lHandPos = new THREE.Vector3(-0.008, -0.43, 0.31);

  const rShoulder = new THREE.Vector3(0.21, -0.02, 0.0);
  const rElbow = new THREE.Vector3(0.22, -0.25, 0.14);
  const rHandPos = new THREE.Vector3(0.008, -0.49, 0.325);

  // Shoulders & Polo Sleeves
  const lMidSleeve = new THREE.Vector3().lerpVectors(lShoulder, lElbow, 0.55);
  const rMidSleeve = new THREE.Vector3().lerpVectors(rShoulder, rElbow, 0.55);
  const jointCapGeo = new THREE.SphereGeometry(0.046, 10, 8);
  [lShoulder, rShoulder].forEach((s) => {
    const cap = new THREE.Mesh(jointCapGeo, primaryMat);
    cap.position.copy(s);
    swingPivot.add(cap);
  });
  addSegmentBetween(swingPivot, lShoulder, lMidSleeve, 0.056, 0.05, primaryMat);
  addSegmentBetween(swingPivot, lMidSleeve, lElbow, 0.044, 0.038, skinMat);
  addSegmentBetween(swingPivot, lElbow, lHandPos, 0.038, 0.028, skinMat);

  addSegmentBetween(swingPivot, rShoulder, rMidSleeve, 0.056, 0.05, primaryMat);
  addSegmentBetween(swingPivot, rMidSleeve, rElbow, 0.044, 0.038, skinMat);
  addSegmentBetween(swingPivot, rElbow, rHandPos, 0.038, 0.028, skinMat);

  const elbowGeo = new THREE.SphereGeometry(0.038, 10, 8);
  [lElbow, rElbow].forEach((el) => {
    const elMesh = new THREE.Mesh(elbowGeo, skinMat);
    elMesh.position.copy(el);
    swingPivot.add(elMesh);
  });

  // Gloved Left Hand + Bare Right Hand gripping the club
  const lGlove = new THREE.Mesh(new THREE.SphereGeometry(0.038, 12, 10), gloveMat);
  lGlove.scale.set(0.95, 1.15, 0.95);
  lGlove.position.copy(lHandPos);
  const rHand = new THREE.Mesh(new THREE.SphereGeometry(0.037, 12, 10), skinMat);
  rHand.scale.set(0.95, 1.15, 0.95);
  rHand.position.copy(rHandPos);
  swingPivot.add(lGlove, rHand);

  // Golf Club oriented forward (+Z) from gloved hands cleanly down to the golf ball
  const clubGroup = new THREE.Group();
  clubGroup.position.set(0, -0.44, 0.315);
  clubGroup.rotation.x = -0.44;
  swingPivot.add(clubGroup);

  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.016, 0.24, 10), gripMat);
  grip.position.set(0, -0.04, 0);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.007, 0.92, 10), shaftMat);
  shaft.position.set(0, -0.58, 0);
  shaft.castShadow = true;
  clubGroup.add(grip, shaft);

  // Authentic Metallic Golf Club Heads (golden driver matching reference)
  const driverHead = new THREE.Mesh(
    new THREE.BoxGeometry(0.155, 0.082, 0.19),
    new THREE.MeshPhysicalMaterial({
      color: 0xf59e0b,
      roughness: 0.14,
      metalness: 0.72,
      clearcoat: 0.95,
    }),
  );
  driverHead.position.set(0.05, -1.03, 0.04);

  const ironHead = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.055, 0.04),
    new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.18, metalness: 0.94 }),
  );
  ironHead.position.set(0.035, -1.0, 0.02);

  const wedgeHead = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.065, 0.038),
    new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.24, metalness: 0.88 }),
  );
  wedgeHead.position.set(0.035, -1.0, 0.02);
  wedgeHead.rotation.x = 0.38;

  const putterHead = new THREE.Mesh(
    new THREE.BoxGeometry(0.145, 0.04, 0.055),
    new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.2, metalness: 0.9 }),
  );
  putterHead.position.set(0.045, -1.0, 0.01);

  clubGroup.add(driverHead, ironHead, wedgeHead, putterHead);

  const clubHeads: Record<ClubId, THREE.Object3D> = {
    driver: driverHead,
    iron: ironHead,
    wedge: wedgeHead,
    putter: putterHead,
  };

  const setClub = (clubId: ClubId) => {
    (Object.keys(clubHeads) as ClubId[]).forEach((k) => {
      clubHeads[k].visible = k === clubId;
    });
  };
  setClub(initialClub);

  // 7. Grounded Contact Shadow & Power Aura Ring
  const contactShadowGeo = new THREE.CircleGeometry(0.62, 20);
  contactShadowGeo.rotateX(-Math.PI / 2);
  const contactShadowMat = new THREE.MeshBasicMaterial({
    map: textures.contactShadowMap,
    transparent: true,
    opacity: 0.72,
    depthWrite: false,
  });
  const golferShadow = new THREE.Mesh(contactShadowGeo, contactShadowMat);
  golferShadow.scale.set(1.0, 1, 1.32);
  golferShadow.position.y = 0.02;
  root.add(golferShadow);

  const auraGeo = new THREE.RingGeometry(0.55, 0.76, 32);
  auraGeo.rotateX(-Math.PI / 2);
  const auraMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color(initialChar.accentColor),
    transparent: true,
    opacity: 0.85,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const powerAura = new THREE.Mesh(auraGeo, auraMat);
  powerAura.position.y = 0.035;
  powerAura.visible = false;
  root.add(powerAura);

  return {
    root,
    upperBodyPivot,
    swingPivot,
    clubHeads,
    powerAura,
    updateCharacter: (char: CharacterSpec) => {
      applyCharacterVisuals(char);
      auraMat.color.set(char.accentColor);
    },
    setClub,
    setPowerAura: (active: boolean, colorHex: string) => {
      powerAura.visible = active;
      auraMat.color.set(colorHex);
    },
  };
}

export interface CourseVisuals {
  group: THREE.Group;
  flagCloth: THREE.Mesh;
  waterMeshes: THREE.Mesh[];
  dispose: () => void;
}

export function createCourseVisuals(
  hole: HoleDefinition,
  textures: ProceduralGolfTextures,
  isSoftwareGl: boolean,
): CourseVisuals {
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];

  // 1. Continuous Valley Terrain Mesh with rich outdoor contrast (low envMapIntensity)
  const spanX = 260;
  const spanZ = 340;
  const segX = isSoftwareGl ? 80 : 104;
  const segZ = isSoftwareGl ? 104 : 136;

  const terrainGeo = new THREE.PlaneGeometry(spanX, spanZ, segX, segZ);
  terrainGeo.rotateX(-Math.PI / 2);
  const posAttr = terrainGeo.attributes.position as THREE.BufferAttribute;
  const colors = new Float32Array(posAttr.count * 3);

  const cFairwayA = new THREE.Color('#65c429');
  const cFairwayB = new THREE.Color('#5ab624');
  const cRough = new THREE.Color('#27551c');
  const cOuterHills = new THREE.Color('#1d4418');
  const cGreen = new THREE.Color('#69d036');
  const cTee = new THREE.Color('#70cc2b');
  const cBunker = new THREE.Color('#ebd59b');
  const cWaterBed = new THREE.Color('#12628d');
  const cWork = new THREE.Color();

  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const z = posAttr.getZ(i);
    let y = getElevationAt(hole, x, z);

    const edgeDistX = Math.max(0, Math.abs(x) - 56);
    const edgeDistZ = Math.max(0, Math.abs(z) - 108);
    const rim = Math.hypot(edgeDistX, edgeDistZ);
    if (rim > 0) {
      y += Math.min(32, rim * 0.34 + Math.sin(x * 0.07) * Math.cos(z * 0.06) * 3.2);
    }

    posAttr.setY(i, y);

    const surf = getSurfaceAt(hole, x, z);
    const organicNoise = (Math.sin(x * 0.31 + z * 0.19) * 0.5 + Math.cos(x * 0.13 - z * 0.27) * 0.5) * 0.04;
    let col = cRough;
    if (surf === 'green') col = cGreen;
    else if (surf === 'tee') col = cTee;
    else if (surf === 'fairway') {
      const mowStripe = Math.floor((z + 150) / 8) % 2 === 0;
      col = mowStripe ? cFairwayA : cFairwayB;
    } else if (surf === 'bunker') col = cBunker;
    else if (surf === 'water') col = cWaterBed;
    else if (rim > 6) col = cOuterHills;

    cWork.copy(col);
    if (surf === 'rough' || surf === 'fairway') {
      cWork.offsetHSL(0, 0, organicNoise);
    }
    colors[i * 3] = cWork.r;
    colors[i * 3 + 1] = cWork.g;
    colors[i * 3 + 2] = cWork.b;
  }

  terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  terrainGeo.computeVertexNormals();
  disposables.push(terrainGeo);

  const terrainMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    map: textures.fairwayMap,
    bumpMap: textures.grassRoughBump,
    bumpScale: 0.12,
    roughness: 0.94,
    metalness: 0.0,
    envMapIntensity: 0.14,
  });
  terrainMat.color.setHex(0xffffff);
  disposables.push(terrainMat);

  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  group.add(terrainMesh);

  // 2. Putting Green Velvet Surface Accent
  const greenGeo = new THREE.CircleGeometry(1, 40);
  greenGeo.rotateX(-Math.PI / 2);
  const greenMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.greenMap,
    roughness: 0.68,
    metalness: 0.0,
    envMapIntensity: 0.18,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const greenDisc = new THREE.Mesh(greenGeo, greenMat);
  const cupPos = getHoleCupPos(hole);
  greenDisc.position.set(hole.green.x, cupPos.y + 0.025, hole.green.z);
  greenDisc.scale.set(hole.green.rx, 1, hole.green.rz);
  greenDisc.receiveShadow = true;
  group.add(greenDisc);
  disposables.push(greenGeo, greenMat);

  // 3. Bunkers Sand Accent
  const bunkerGeo = new THREE.CircleGeometry(1, 28);
  bunkerGeo.rotateX(-Math.PI / 2);
  const bunkerMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.sandMap,
    roughness: 0.95,
    metalness: 0.0,
    envMapIntensity: 0.15,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  disposables.push(bunkerGeo, bunkerMat);
  for (const b of hole.bunkers) {
    const bMesh = new THREE.Mesh(bunkerGeo, bunkerMat);
    const by = getElevationAt(hole, b.x, b.z);
    bMesh.position.set(b.x, by + 0.03, b.z);
    bMesh.scale.set(b.rx, 1, b.rz);
    bMesh.rotation.y = b.rotation ?? 0;
    bMesh.receiveShadow = true;
    group.add(bMesh);
  }

  // 4. Reflective Alpine Water Lakes + Carved Warm Sandstone Rocky Shoreline Lip
  const waterMeshes: THREE.Mesh[] = [];
  const waterGeo = new THREE.CircleGeometry(1, 36);
  waterGeo.rotateX(-Math.PI / 2);
  const waterMat = new THREE.MeshPhysicalMaterial({
    color: 0x1680b8,
    roughness: 0.06,
    metalness: 0.22,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
    transparent: true,
    opacity: 0.92,
    envMapIntensity: 1.15,
  });
  const shoreRimGeo = new THREE.TorusGeometry(1.0, 0.075, 10, 36);
  shoreRimGeo.rotateX(Math.PI / 2);
  const shoreRimMat = new THREE.MeshStandardMaterial({
    color: 0xc9a977,
    roughness: 0.92,
    metalness: 0.02,
    envMapIntensity: 0.16,
  });
  disposables.push(waterGeo, waterMat, shoreRimGeo, shoreRimMat);

  for (const w of hole.waterZones) {
    const wMesh = new THREE.Mesh(waterGeo, waterMat);
    wMesh.position.set(w.x, -0.45, w.z);
    wMesh.scale.set(w.rx, 1, w.rz);
    wMesh.rotation.y = w.rotation ?? 0;
    wMesh.receiveShadow = true;
    group.add(wMesh);
    waterMeshes.push(wMesh);

    const rimMesh = new THREE.Mesh(shoreRimGeo, shoreRimMat);
    rimMesh.position.set(w.x, -0.15, w.z);
    rimMesh.scale.set(w.rx * 1.01, 1.35, w.rz * 1.01);
    rimMesh.rotation.y = w.rotation ?? 0;
    rimMesh.receiveShadow = true;
    group.add(rimMesh);
  }

  // 5. Crisp Elevated Rectangular Tee Details (Blue Golf Tee, White Aim Strip & Fence Posts)
  const teeY = getElevationAt(hole, hole.tee.x, hole.tee.z);
  const blueTeeMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.35, metalness: 0.1 });
  const whiteLineMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc, transparent: true, opacity: 0.88 });
  const teePeg = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.01, 0.09, 10), blueTeeMat);
  teePeg.position.set(hole.tee.x, teeY + 0.045, hole.tee.z);
  const teeAimStrip = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.016, 0.14), whiteLineMat);
  teeAimStrip.position.set(hole.tee.x + 2.0, teeY + 0.015, hole.tee.z);
  group.add(teePeg, teeAimStrip);
  disposables.push(teePeg.geometry, teeAimStrip.geometry, blueTeeMat, whiteLineMat);

  const teeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.25, metalness: 0.55 });
  const teePostMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.45, metalness: 0.1 });
  const fenceRailGeo = new THREE.CylinderGeometry(0.032, 0.032, 2.8, 8);
  const markerStemGeo = new THREE.CylinderGeometry(0.055, 0.065, 0.72, 8);
  disposables.push(teeMat, teePostMat, fenceRailGeo, markerStemGeo);

  [-6.2, 6.2].forEach((offsetX) => {
    const fGroup = new THREE.Group();
    const my = getElevationAt(hole, hole.tee.x + offsetX, hole.tee.z);
    fGroup.position.set(hole.tee.x + offsetX, my, hole.tee.z);
    const p1 = new THREE.Mesh(markerStemGeo, teePostMat);
    p1.position.set(0, 0.36, -1.2);
    const p2 = new THREE.Mesh(markerStemGeo, teePostMat);
    p2.position.set(0, 0.36, 1.2);
    const rail = new THREE.Mesh(fenceRailGeo, teePostMat);
    rail.rotation.x = Math.PI / 2;
    rail.position.set(0, 0.56, 0);
    fGroup.add(p1, p2, rail);
    group.add(fGroup);
  });

  // 6. Cup Rim & Composite Flagstick (Vibrant Magenta-Pink Flag matching reference)
  const cupGroup = new THREE.Group();
  cupGroup.position.set(cupPos.x, cupPos.y + 0.035, cupPos.z);

  const cupHoleGeo = new THREE.CircleGeometry(0.5, 24);
  cupHoleGeo.rotateX(-Math.PI / 2);
  const cupHoleMat = new THREE.MeshBasicMaterial({ color: 0x090f0b });
  const cupHole = new THREE.Mesh(cupHoleGeo, cupHoleMat);

  const cupRimGeo = new THREE.RingGeometry(0.48, 0.58, 24);
  cupRimGeo.rotateX(-Math.PI / 2);
  const cupRimMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3, metalness: 0.2 });
  const cupRim = new THREE.Mesh(cupRimGeo, cupRimMat);
  cupRim.position.y = 0.005;

  const poleGeo = new THREE.CylinderGeometry(0.032, 0.036, 3.8, 10);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0xfef9c3, roughness: 0.3, metalness: 0.65 });
  const pole = new THREE.Mesh(poleGeo, poleMat);
  pole.position.y = 1.9;
  pole.castShadow = true;

  const finial = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 10), teeMat);
  finial.position.y = 3.84;

  const flagGeo = new THREE.PlaneGeometry(1.3, 0.78, 8, 2);
  flagGeo.translate(0.65, 0, 0);
  const flagMat = new THREE.MeshStandardMaterial({
    color: 0xec4899,
    emissive: 0xbe185d,
    emissiveIntensity: 0.18,
    roughness: 0.72,
    metalness: 0.02,
    envMapIntensity: 0.2,
    side: THREE.DoubleSide,
  });
  const flagCloth = new THREE.Mesh(flagGeo, flagMat);
  flagCloth.position.set(0.02, 3.4, 0);
  flagCloth.castShadow = true;

  cupGroup.add(cupHole, cupRim, pole, finial, flagCloth);
  group.add(cupGroup);
  disposables.push(cupHoleGeo, cupHoleMat, cupRimGeo, cupRimMat, poleGeo, poleMat, flagGeo, flagMat);

  // 7. Multi-Tier Natural Alpine Pine Trees (Bark + 4-Tier Foliage with low envMapIntensity!)
  const treePositions: Array<{ x: number; z: number; scale: number }> = [...hole.treeAnchors];
  for (let i = 0; i < 42; i++) {
    const angle = (i / 42) * Math.PI * 2;
    const radiusX = 64 + (i % 3) * 12;
    const radiusZ = 104 + ((i + 1) % 3) * 14;
    treePositions.push({
      x: Math.cos(angle) * radiusX,
      z: Math.sin(angle) * radiusZ,
      scale: 1.0 + ((i % 5) - 2) * 0.14,
    });
  }

  const trunkGeo = new THREE.CylinderGeometry(0.24, 0.42, 2.8, 9);
  trunkGeo.translate(0, 1.4, 0);
  const trunkMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.barkMap,
    roughness: 0.94,
    metalness: 0.0,
    envMapIntensity: 0.12,
  });

  const bough1Geo = new THREE.ConeGeometry(2.5, 3.4, 9);
  bough1Geo.translate(0, 3.4, 0);
  const bough2Geo = new THREE.ConeGeometry(2.0, 3.0, 9);
  bough2Geo.translate(0, 5.1, 0);
  const bough3Geo = new THREE.ConeGeometry(1.45, 2.6, 9);
  bough3Geo.translate(0, 6.7, 0);
  const bough4Geo = new THREE.ConeGeometry(0.85, 2.1, 8);
  bough4Geo.translate(0, 8.1, 0);

  const foliageMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.92,
    metalness: 0.0,
    envMapIntensity: 0.12,
  });

  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treePositions.length);
  const b1Inst = new THREE.InstancedMesh(bough1Geo, foliageMat, treePositions.length);
  const b2Inst = new THREE.InstancedMesh(bough2Geo, foliageMat, treePositions.length);
  const b3Inst = new THREE.InstancedMesh(bough3Geo, foliageMat, treePositions.length);
  const b4Inst = new THREE.InstancedMesh(bough4Geo, foliageMat, treePositions.length);

  [trunkInst, b1Inst, b2Inst, b3Inst, b4Inst].forEach((inst) => {
    inst.castShadow = !isSoftwareGl;
    inst.receiveShadow = true;
  });

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();
  treePositions.forEach((tp, idx) => {
    let ty = getElevationAt(hole, tp.x, tp.z);
    const edgeDistX = Math.max(0, Math.abs(tp.x) - 56);
    const edgeDistZ = Math.max(0, Math.abs(tp.z) - 108);
    const rim = Math.hypot(edgeDistX, edgeDistZ);
    if (rim > 0) {
      ty += Math.min(32, rim * 0.34 + Math.sin(tp.x * 0.07) * Math.cos(tp.z * 0.06) * 3.2);
    }
    dummy.position.set(tp.x, ty - 0.2, tp.z);
    dummy.rotation.set(0, (idx * 1.37) % (Math.PI * 2), 0);
    dummy.scale.setScalar(tp.scale);
    dummy.updateMatrix();
    trunkInst.setMatrixAt(idx, dummy.matrix);
    b1Inst.setMatrixAt(idx, dummy.matrix);
    b2Inst.setMatrixAt(idx, dummy.matrix);
    b3Inst.setMatrixAt(idx, dummy.matrix);
    b4Inst.setMatrixAt(idx, dummy.matrix);

    // Rich deep natural pine colors
    const hue = 0.35 + (idx % 3) * 0.014;
    const baseL = 0.1 + (idx % 4) * 0.02;
    tint.setHSL(hue, 0.56, baseL);
    b1Inst.setColorAt(idx, tint);
    tint.setHSL(hue, 0.54, baseL + 0.02);
    b2Inst.setColorAt(idx, tint);
    tint.setHSL(hue, 0.52, baseL + 0.04);
    b3Inst.setColorAt(idx, tint);
    tint.setHSL(hue, 0.5, baseL + 0.06);
    b4Inst.setColorAt(idx, tint);
  });

  [trunkInst, b1Inst, b2Inst, b3Inst, b4Inst].forEach((inst) => inst.computeBoundingSphere());
  group.add(trunkInst, b1Inst, b2Inst, b3Inst, b4Inst);
  disposables.push(trunkGeo, trunkMat, bough1Geo, bough2Geo, bough3Geo, bough4Geo, foliageMat);

  // 8. Lush Broadleaf Canopy Trees (exact shared coords with physics obstacle colliders)
  const broadCoords = getBroadleafTreeCoords(hole);
  const broadTrunkGeo = new THREE.CylinderGeometry(0.32, 0.52, 4.0, 10);
  broadTrunkGeo.translate(0, 2.0, 0);
  const canopySphereGeo = new THREE.SphereGeometry(2.3, 14, 12);
  const canopyMatMain = new THREE.MeshStandardMaterial({
    color: 0x2e9c33,
    roughness: 0.85,
    metalness: 0.0,
    envMapIntensity: 0.14,
  });
  const canopyMatLight = new THREE.MeshStandardMaterial({
    color: 0x4cc445,
    roughness: 0.82,
    metalness: 0.0,
    envMapIntensity: 0.16,
  });
  disposables.push(broadTrunkGeo, canopySphereGeo, canopyMatMain, canopyMatLight);

  broadCoords.forEach((bc) => {
    const btGroup = new THREE.Group();
    const by = getElevationAt(hole, bc.x, bc.z);
    btGroup.position.set(bc.x, by - 0.15, bc.z);
    btGroup.scale.setScalar(bc.s);

    const tr = new THREE.Mesh(broadTrunkGeo, trunkMat);
    tr.castShadow = !isSoftwareGl;
    btGroup.add(tr);

    const puffs = [
      { x: 0, y: 5.2, z: 0, r: 1.15, m: canopyMatMain },
      { x: -1.3, y: 4.5, z: 0.8, r: 0.85, m: canopyMatLight },
      { x: 1.35, y: 4.6, z: -0.6, r: 0.88, m: canopyMatMain },
      { x: 0.2, y: 6.1, z: 0.4, r: 0.82, m: canopyMatLight },
    ];
    puffs.forEach((pf) => {
      const m = new THREE.Mesh(canopySphereGeo, pf.m);
      m.position.set(pf.x, pf.y, pf.z);
      m.scale.setScalar(pf.r);
      m.castShadow = !isSoftwareGl;
      m.receiveShadow = true;
      btGroup.add(m);
    });
    group.add(btGroup);
  });

  // 10. Resort Festival Pavilions / Tents near tee woods & green spectator area
  const tentSpots = getResortTentCoords(hole);
  const tentRoofGeo = new THREE.ConeGeometry(3.4, 2.4, 4);
  tentRoofGeo.rotateY(Math.PI / 4);
  const tentPostGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.6, 6);
  const tentPostMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
  disposables.push(tentRoofGeo, tentPostGeo, tentPostMat);

  tentSpots.forEach((ts) => {
    const tGrp = new THREE.Group();
    const ty = getElevationAt(hole, ts.x, ts.z);
    tGrp.position.set(ts.x, ty, ts.z);
    tGrp.rotation.y = ts.rot;
    const roofMat = new THREE.MeshStandardMaterial({
      color: ts.color,
      roughness: 0.65,
      metalness: 0.04,
      envMapIntensity: 0.2,
    });
    disposables.push(roofMat);
    const roof = new THREE.Mesh(tentRoofGeo, roofMat);
    roof.position.y = 3.5;
    roof.castShadow = !isSoftwareGl;
    tGrp.add(roof);

    [
      [-1.8, -1.8],
      [1.8, -1.8],
      [-1.8, 1.8],
      [1.8, 1.8],
    ].forEach(([px, pz]) => {
      const post = new THREE.Mesh(tentPostGeo, tentPostMat);
      post.position.set(px, 1.3, pz);
      tGrp.add(post);
    });
    group.add(tGrp);
  });

  // 10b. Distant Iconic Marina Bay Resort 3-Tower Skyline & Cantilevered SkyPark Deck
  const skylineGroup = new THREE.Group();
  skylineGroup.position.set(74, 3, -210);
  skylineGroup.rotation.y = -0.26;
  skylineGroup.scale.set(1.12, 1.12, 1.12);
  const towerGlassMat = new THREE.MeshStandardMaterial({
    color: 0x7ab4e8,
    emissive: 0x2d6aa3,
    emissiveIntensity: 0.22,
    roughness: 0.32,
    metalness: 0.45,
    envMapIntensity: 0.8,
  });
  const skyDeckMat = new THREE.MeshStandardMaterial({
    color: 0xb7d9f6,
    roughness: 0.4,
    metalness: 0.35,
    envMapIntensity: 0.6,
  });
  const towerGeo = new THREE.BoxGeometry(7.2, 46, 5.2);
  disposables.push(towerGeo, towerGlassMat, skyDeckMat);

  [-14, 0, 14].forEach((tx, idx) => {
    const tPair = new THREE.Group();
    tPair.position.set(tx, 23, 0);
    const leftLeg = new THREE.Mesh(towerGeo, towerGlassMat);
    leftLeg.position.set(-1.6, 0, 0);
    leftLeg.rotation.z = -0.07;
    const rightLeg = new THREE.Mesh(towerGeo, towerGlassMat);
    rightLeg.position.set(1.6, 0, 0);
    rightLeg.rotation.z = 0.07;
    tPair.add(leftLeg, rightLeg);
    if (idx === 1) tPair.scale.set(1.04, 1.02, 1.04);
    skylineGroup.add(tPair);
  });

  const skyDeckGeo = new THREE.BoxGeometry(48, 3.4, 7.6);
  const skyDeck = new THREE.Mesh(skyDeckGeo, skyDeckMat);
  skyDeck.position.set(2.5, 47.5, 0);
  skylineGroup.add(skyDeck);
  disposables.push(skyDeckGeo);
  group.add(skylineGroup);

  // 11. Granite Rock Outcrops
  const rockGeo = new THREE.DodecahedronGeometry(1.4, 1);
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x6e7370,
    roughness: 0.92,
    metalness: 0.04,
    envMapIntensity: 0.18,
  });
  disposables.push(rockGeo, rockMat);
  hole.rockAnchors.forEach((rk, i) => {
    const rGroup = new THREE.Group();
    const ry = getElevationAt(hole, rk.x, rk.z);
    rGroup.position.set(rk.x, ry - 0.15, rk.z);
    rGroup.rotation.y = i * 1.1;
    const mainRock = new THREE.Mesh(rockGeo, rockMat);
    mainRock.scale.set(rk.scale * 1.25, rk.scale * 0.72, rk.scale);
    mainRock.position.y = rk.scale * 0.42;
    mainRock.castShadow = !isSoftwareGl;
    const sideRock = new THREE.Mesh(rockGeo, rockMat);
    sideRock.scale.set(rk.scale * 0.68, rk.scale * 0.48, rk.scale * 0.62);
    sideRock.position.set(rk.scale * 1.15, rk.scale * 0.22, 0.35);
    rGroup.add(mainRock, sideRock);
    group.add(rGroup);
  });

  // 12. Real 3D Instanced Multi-Blade Grass Clumps along rough & tree edges
  const tuftCoords: Array<{ x: number; z: number; s: number; rot: number }> = [];
  const maxTufts = isSoftwareGl ? 650 : 1200;
  for (let i = 0; i < 3200 && tuftCoords.length < maxTufts; i++) {
    const h1 = Math.sin(i * 12.9898 + hole.index * 7.1) * 43758.5453;
    const h2 = Math.sin(i * 78.233 + hole.index * 3.7) * 28461.1234;
    const u = h1 - Math.floor(h1);
    const v = h2 - Math.floor(h2);
    const gx = (u - 0.5) * 112;
    const gz = (v - 0.5) * 206;
    const surf = getSurfaceAt(hole, gx, gz);
    // Natural patchiness so tufts form organic meadow clusters rather than uniform dots
    const patch = Math.sin(gx * 0.16) * Math.cos(gz * 0.14) + Math.sin((gx + gz) * 0.09);
    if (surf === 'rough' && patch > -0.35) {
      tuftCoords.push({
        x: gx,
        z: gz,
        s: 0.65 + ((i % 7) / 7) * 0.7,
        rot: (i * 2.13) % (Math.PI * 2),
      });
    }
  }

  if (tuftCoords.length > 0) {
    // Build a 5-blade fanned grass clump BufferGeometry
    const bladesPerClump = 5;
    const positions: number[] = [];
    const normals: number[] = [];
    const indices: number[] = [];
    for (let b = 0; b < bladesPerClump; b++) {
      const ang = (b / bladesPerClump) * Math.PI * 2 + (b % 2) * 0.25;
      const cosA = Math.cos(ang);
      const sinA = Math.sin(ang);
      const ox = cosA * 0.05;
      const oz = sinA * 0.05;
      const bw = 0.042;
      const bh = 0.24 + (b % 3) * 0.06;
      const lean = 0.09 + (b % 2) * 0.05;

      const baseIdx = b * 3;
      // Left base, right base, tapered leaned tip
      positions.push(
        ox - sinA * bw, 0, oz + cosA * bw,
        ox + sinA * bw, 0, oz - cosA * bw,
        ox + cosA * lean, bh, oz + sinA * lean,
      );
      normals.push(0, 1, 0, 0, 1, 0, 0, 1, 0);
      indices.push(baseIdx, baseIdx + 1, baseIdx + 2);
    }

    const bladeGeo = new THREE.BufferGeometry();
    bladeGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    bladeGeo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    bladeGeo.setIndex(indices);

    const bladeMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.96,
      metalness: 0.0,
      envMapIntensity: 0.06,
      side: THREE.DoubleSide,
    });

    const tuftInst = new THREE.InstancedMesh(bladeGeo, bladeMat, tuftCoords.length);
    const tDummy = new THREE.Object3D();
    const tColor = new THREE.Color();
    tuftCoords.forEach((tc, idx) => {
      const ty = getElevationAt(hole, tc.x, tc.z);
      tDummy.position.set(tc.x, ty - 0.02, tc.z);
      tDummy.rotation.set(0, tc.rot, 0);
      tDummy.scale.set(tc.s, tc.s, tc.s);
      tDummy.updateMatrix();
      tuftInst.setMatrixAt(idx, tDummy.matrix);
      // Rich natural dark-to-mid grass green hues blending seamlessly into the rough turf
      tColor.setHSL(0.305 + (idx % 4) * 0.012, 0.56, 0.13 + (idx % 5) * 0.022);
      tuftInst.setColorAt(idx, tColor);
    });
    tuftInst.computeBoundingSphere();
    group.add(tuftInst);
    disposables.push(bladeGeo, bladeMat);
  }

  return {
    group,
    flagCloth,
    waterMeshes,
    dispose: () => {
      disposables.forEach((d) => d.dispose());
    },
  };
}
