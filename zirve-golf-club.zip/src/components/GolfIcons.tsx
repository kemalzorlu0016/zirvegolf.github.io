import type { CharacterSpec, ClubId, PowerId } from '../game/types.ts';

export function TitleCrestSvg() {
  return (
    <div className="flex items-center gap-3.5 sm:gap-4" aria-label="Zirve Golf Club">
      <img
        src="/app-icon-192.png"
        alt="Zirve Golf Club uygulama ikonu"
        referrerPolicy="no-referrer"
        className="w-20 h-20 sm:w-24 sm:h-24 shrink-0 drop-shadow-[0_6px_14px_rgba(7,19,13,0.65)] select-none"
      />
      <div className="min-w-0">
        <div className="font-display text-3xl sm:text-[42px] font-extrabold tracking-wide text-white leading-none drop-shadow-[0_2px_6px_rgba(7,19,13,0.75)] whitespace-nowrap">
          ZİRVE GOLF
        </div>
        <div className="mt-2 h-[2.5px] w-full bg-[#e5b84b] shadow-sm" />
        <div className="mt-1.5 text-[11px] sm:text-[13px] font-bold tracking-[0.18em] text-slate-50 drop-shadow-[0_2px_4px_rgba(7,19,13,0.8)] whitespace-nowrap">
          3D ÇOK OYUNCULU ŞAMPİYONA
        </div>
      </div>
    </div>
  );
}

export function ClubIconSvg({ clubId, active }: { clubId: ClubId; active?: boolean }) {
  const stroke = active ? '#0b1610' : '#f1f5f9';
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0" aria-hidden="true">
      {clubId === 'driver' && (
        <g fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="17" y1="3" x2="8" y2="17" />
          <path d="M5 17 C4 19 6 21 10 20 C13 19.5 13 17 10 16.5 Z" fill={active ? '#0b1610' : '#f59e0b'} />
        </g>
      )}
      {clubId === 'iron' && (
        <g fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="16" y1="3" x2="9" y2="18" />
          <path d="M6 18 L12 18 L11 20.5 L5.5 20.5 Z" fill={active ? '#0b1610' : '#38bdf8'} />
        </g>
      )}
      {clubId === 'wedge' && (
        <g fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="15" y1="3" x2="10" y2="17" />
          <path d="M6 16 L12 18 L10 21 L5 19 Z" fill={active ? '#0b1610' : '#a78bfa'} />
        </g>
      )}
      {clubId === 'putter' && (
        <g fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="13" y1="3" x2="13" y2="19" />
          <rect x="6" y="18" width="9" height="3" rx="1" fill={active ? '#0b1610' : '#34d399'} />
        </g>
      )}
    </svg>
  );
}

export function PowerIconSvg({ powerId }: { powerId: PowerId }) {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0" aria-hidden="true">
      {powerId === 'super_drive' && (
        <path
          d="M13 2 L4 14 H11 L10 22 L20 10 H13 Z"
          fill="#fbbf24"
          stroke="#1f2937"
          strokeWidth="1.4"
          strokeLinejoin="round"
        />
      )}
      {powerId === 'laser_aim' && (
        <g fill="none" stroke="#34d399" strokeWidth="2" strokeLinecap="round">
          <circle cx="12" cy="12" r="7" />
          <circle cx="12" cy="12" r="2.2" fill="#34d399" />
          <line x1="12" y1="2" x2="12" y2="5" />
          <line x1="12" y1="19" x2="12" y2="22" />
          <line x1="2" y1="12" x2="5" y2="12" />
          <line x1="19" y1="12" x2="22" y2="12" />
        </g>
      )}
      {powerId === 'wind_shield' && (
        <g fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 3 L19 6 V12 C19 16.5 15.8 19.8 12 21 C8.2 19.8 5 16.5 5 12 V6 Z" fill="#0c4a6e" />
          <path d="M8.5 11 H14.5 C15.6 11 15.6 9.5 14.5 9.5" />
          <path d="M8.5 14 H13.5 C14.5 14 14.5 15.5 13.5 15.5" />
        </g>
      )}
      {powerId === 'cup_magnet' && (
        <g fill="none" stroke="#fcd34d" strokeWidth="2.2" strokeLinecap="round">
          <path d="M7 5 V12 A5 5 0 0 0 17 12 V5" />
          <line x1="7" y1="5" x2="7" y2="8" stroke="#ef4444" strokeWidth="3" />
          <line x1="17" y1="5" x2="17" y2="8" stroke="#ef4444" strokeWidth="3" />
        </g>
      )}
    </svg>
  );
}

export function CharacterAvatarSvg({
  char,
  className = 'w-12 h-12 rounded-xl border border-white/15',
}: {
  char: CharacterSpec;
  className?: string;
}) {
  return (
    <svg viewBox="0 0 64 64" className={`shrink-0 bg-[#0d1812] ${className}`} aria-hidden="true">
      {/* Shoulders / Jacket */}
      <path d="M12 62 C12 46 21 40 32 40 C43 40 52 46 52 62 Z" fill={char.primaryColor} />
      <path d="M26 40 L32 48 L38 40" fill="none" stroke={char.accentColor} strokeWidth="2.5" />
      {char.id === 'defne' ? (
        <g>
          {/* Auburn top-bun hairstyle */}
          <circle cx="32" cy="14" r="7.5" fill="#c25e1a" />
          <path d="M20 28 C20 15 44 15 44 28 Z" fill="#c25e1a" />
          <circle cx="32" cy="30" r="10.5" fill="#f1c2a0" />
          <path d="M21 27 Q32 21 43 27 Q38 18 26 18 Z" fill="#c25e1a" />
          <circle cx="28" cy="30" r="1.4" fill="#1e293b" />
          <circle cx="36" cy="30" r="1.4" fill="#1e293b" />
        </g>
      ) : (
        <g>
          {/* Head */}
          <circle cx="32" cy="27" r="11" fill="#f1c2a0" />
          {/* Hat */}
          {char.hatStyle === 'sunhat' ? (
            <g>
              <ellipse cx="32" cy="20" rx="18" ry="4" fill={char.secondaryColor} />
              <path d="M21 20 C21 11 43 11 43 20 Z" fill={char.primaryColor} />
            </g>
          ) : char.hatStyle === 'beret' ? (
            <ellipse cx="34" cy="17" rx="13" ry="6" fill={char.primaryColor} stroke={char.accentColor} strokeWidth="1.5" />
          ) : (
            <g>
              <path d="M20 22 C20 12 44 12 44 22 Z" fill={char.primaryColor} />
              <path d="M21 22 H47" stroke={char.accentColor} strokeWidth="3.5" strokeLinecap="round" />
            </g>
          )}
        </g>
      )}
    </svg>
  );
}
