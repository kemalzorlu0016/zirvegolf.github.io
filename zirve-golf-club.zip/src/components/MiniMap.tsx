import { useEffect, useState } from 'react';
import { getBroadleafTreeCoords, getResortTentCoords } from '../game/courses.ts';
import type { HoleDefinition, ObstacleHitInfo, PlayerMatchState, Vec3 } from '../game/types.ts';

export interface MiniMapShotRecord {
  id: number;
  points: Vec3[];
  landedPos: Vec3;
  hitWater: boolean;
  sunk: boolean;
  playerColor: string;
}

export interface ActiveMapFlight {
  points: Vec3[];
  startTimeMs: number;
  durationSec: number;
  hitWater: boolean;
}

interface MiniMapProps {
  hole: HoleDefinition;
  players: PlayerMatchState[];
  localPlayerId: string;
  aimYaw?: number;
  aimPoints?: Vec3[];
  landingPos?: Vec3;
  aimHitWater?: boolean;
  aimObstacleHit?: ObstacleHitInfo;
  predictedDistanceM?: number;
  shotHistory?: MiniMapShotRecord[];
  activeShot?: ActiveMapFlight | null;
  windSpeedMs?: number;
}

function toPolylinePoints(pts: Vec3[], maxIdx?: number): string {
  const limit = maxIdx !== undefined ? Math.min(pts.length, maxIdx + 1) : pts.length;
  const step = limit > 48 ? Math.ceil(limit / 48) : 1;
  const coords: string[] = [];
  for (let i = 0; i < limit; i += step) {
    coords.push(`${pts[i].x.toFixed(1)},${pts[i].z.toFixed(1)}`);
  }
  if (limit > 0) {
    const last = pts[limit - 1];
    const lastStr = `${last.x.toFixed(1)},${last.z.toFixed(1)}`;
    if (coords[coords.length - 1] !== lastStr) {
      coords.push(lastStr);
    }
  }
  return coords.join(' ');
}

export function MiniMap({
  hole,
  players,
  localPlayerId,
  aimYaw,
  aimPoints,
  landingPos,
  aimHitWater = false,
  aimObstacleHit,
  predictedDistanceM,
  shotHistory = [],
  activeShot = null,
  windSpeedMs,
}: MiniMapProps) {
  const { minX, maxX, minZ, maxZ } = hole.bounds;
  const pad = 12;
  const vbX = minX - pad;
  const vbY = minZ - pad;
  const vbW = maxX - minX + pad * 2;
  const vbH = maxZ - minZ + pad * 2;

  const localPlayer = players.find((p) => p.id === localPlayerId);
  const broadleafTrees = getBroadleafTreeCoords(hole);
  const tents = getResortTentCoords(hole);

  // Live animated ball progress along activeShot
  const [flightProgress, setFlightProgress] = useState(0);
  useEffect(() => {
    if (!activeShot || activeShot.points.length < 2) {
      setFlightProgress(0);
      return;
    }
    let raf = 0;
    const durMs = Math.max(150, activeShot.durationSec * 1000);
    const tick = () => {
      const elapsed = performance.now() - activeShot.startTimeMs;
      const p = Math.max(0, Math.min(1, elapsed / durMs));
      setFlightProgress(p);
      if (p < 1) {
        raf = requestAnimationFrame(tick);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [activeShot]);

  let liveBallPos: Vec3 | null = null;
  let liveTrailPts = '';
  if (activeShot && activeShot.points.length >= 2) {
    const exactIdx = flightProgress * (activeShot.points.length - 1);
    const i0 = Math.floor(exactIdx);
    const i1 = Math.min(activeShot.points.length - 1, i0 + 1);
    const alpha = exactIdx - i0;
    const p0 = activeShot.points[i0];
    const p1 = activeShot.points[i1];
    liveBallPos = {
      x: p0.x + (p1.x - p0.x) * alpha,
      y: p0.y + (p1.y - p0.y) * alpha,
      z: p0.z + (p1.z - p0.z) * alpha,
    };
    liveTrailPts = `${toPolylinePoints(activeShot.points, i0)} ${liveBallPos.x.toFixed(1)},${liveBallPos.z.toFixed(1)}`;
  }

  return (
    <div
      className="relative rounded-xl bg-[#21591f] border-2 border-white/95 shadow-2xl w-[184px] sm:w-[244px] md:w-[272px] lg:w-[296px] overflow-hidden"
      aria-label="Saha Mini Haritası"
    >
      <svg
        viewBox={`${vbX} ${vbY} ${vbW} ${vbH}`}
        preserveAspectRatio="xMidYMid meet"
        className="w-full h-[240px] sm:h-[318px] md:h-[354px] lg:h-[386px] max-h-[48vh] block bg-[#21591f]"
        role="img"
        aria-label={`${hole.name} saha haritası`}
      >
        {/* Subtle rough outer contour */}
        {hole.fairways.map((seg, i) => (
          <line
            key={`rough-${i}`}
            x1={seg.x1}
            y1={seg.z1}
            x2={seg.x2}
            y2={seg.z2}
            stroke="#367f28"
            strokeWidth={seg.width * 2.55}
            strokeLinecap="round"
          />
        ))}

        {/* Fairway corridor segments */}
        {hole.fairways.map((seg, i) => (
          <line
            key={`fw-${i}`}
            x1={seg.x1}
            y1={seg.z1}
            x2={seg.x2}
            y2={seg.z2}
            stroke="#73c837"
            strokeWidth={seg.width * 1.95}
            strokeLinecap="round"
          />
        ))}

        {/* Water hazards with sandstone shoreline */}
        {hole.waterZones.map((w, i) => (
          <ellipse
            key={`w-${i}`}
            cx={w.x}
            cy={w.z}
            rx={w.rx}
            ry={w.rz}
            transform={w.rotation ? `rotate(${(-w.rotation * 180) / Math.PI} ${w.x} ${w.z})` : undefined}
            fill="#5ec2ea"
            stroke="#d4b886"
            strokeWidth={2.2}
          />
        ))}

        {/* Bunkers */}
        {hole.bunkers.map((b, i) => (
          <ellipse
            key={`b-${i}`}
            cx={b.x}
            cy={b.z}
            rx={b.rx}
            ry={b.rz}
            transform={b.rotation ? `rotate(${(-b.rotation * 180) / Math.PI} ${b.x} ${b.z})` : undefined}
            fill="#ebd59b"
            stroke="#c9a861"
            strokeWidth={1.1}
          />
        ))}

        {/* Putting Green */}
        <ellipse
          cx={hole.green.x}
          cy={hole.green.z}
          rx={hole.green.rx}
          ry={hole.green.rz}
          fill="#85e043"
          stroke="#4db32f"
          strokeWidth={1.5}
        />

        {/* Tee Box */}
        <rect
          x={hole.tee.x - 5}
          y={hole.tee.z - 4}
          width={10}
          height={8}
          rx={1.5}
          fill="#80d93f"
          stroke="#ffffff"
          strokeOpacity={0.65}
          strokeWidth={0.9}
        />

        {/* Course Obstacles: Pines, Broadleaf Trees, Rocks, Resort Pavilions */}
        {hole.treeAnchors.map((t, i) => (
          <circle
            key={`pt-${i}`}
            cx={t.x}
            cy={t.z}
            r={2.5 * t.scale}
            fill="#14532d"
            stroke="#22c55e"
            strokeWidth={0.55}
            opacity={0.85}
          />
        ))}
        {broadleafTrees.map((bt, i) => (
          <circle
            key={`bt-${i}`}
            cx={bt.x}
            cy={bt.z}
            r={3.2 * bt.s}
            fill="#166534"
            stroke="#4ade80"
            strokeWidth={0.6}
            opacity={0.88}
          />
        ))}
        {hole.rockAnchors.map((rk, i) => (
          <circle
            key={`rk-${i}`}
            cx={rk.x}
            cy={rk.z}
            r={1.7 * rk.scale}
            fill="#94a3b8"
            stroke="#475569"
            strokeWidth={0.6}
          />
        ))}
        {tents.map((ts, i) => (
          <rect
            key={`tn-${i}`}
            x={ts.x - 2.3}
            y={ts.z - 2.3}
            width={4.6}
            height={4.6}
            rx={0.6}
            fill="#f59e0b"
            stroke="#fef3c7"
            strokeWidth={0.6}
          />
        ))}

        {/* Executed Shot History Trails & Landing Markers on Current Hole */}
        {shotHistory.map((shot, idx) => {
          const poly = toPolylinePoints(shot.points);
          return (
            <g key={shot.id}>
              <polyline
                points={poly}
                fill="none"
                stroke={shot.hitWater ? '#f87171' : '#fde047'}
                strokeWidth={2.2}
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity={0.9}
              />
              {shot.hitWater ? (
                <g transform={`translate(${shot.landedPos.x}, ${shot.landedPos.z})`}>
                  <circle r={3.2} fill="#ef4444" stroke="#ffffff" strokeWidth={0.9} />
                  <line x1={-1.8} y1={-1.8} x2={1.8} y2={1.8} stroke="#ffffff" strokeWidth={1.1} />
                  <line x1={1.8} y1={-1.8} x2={-1.8} y2={1.8} stroke="#ffffff" strokeWidth={1.1} />
                </g>
              ) : (
                <g transform={`translate(${shot.landedPos.x}, ${shot.landedPos.z})`}>
                  <circle r={3.6} fill="#f59e0b" stroke="#ffffff" strokeWidth={0.9} />
                  <text
                    x={0}
                    y={1.3}
                    textAnchor="middle"
                    fill="#0f172a"
                    fontSize="4.2"
                    fontWeight="800"
                  >
                    {idx + 1}
                  </text>
                </g>
              )}
            </g>
          );
        })}

        {/* Live Animated Shot Trail During Flight */}
        {activeShot && liveTrailPts && (
          <polyline
            points={liveTrailPts}
            fill="none"
            stroke="#ffffff"
            strokeWidth={2.8}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Predicted Aim Trajectory Polyline & Landing Crosshair (when aiming) */}
        {localPlayer && !localPlayer.holedOut && !activeShot && (aimPoints?.length || landingPos) && (
          <g>
            {aimPoints && aimPoints.length >= 2 ? (
              <polyline
                points={toPolylinePoints(aimPoints)}
                fill="none"
                stroke={aimObstacleHit ? '#fb923c' : '#38bdf8'}
                strokeWidth={2.3}
                strokeDasharray="3.2 2.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            ) : (
              landingPos && (
                <line
                  x1={localPlayer.ballPos.x}
                  y1={localPlayer.ballPos.z}
                  x2={landingPos.x}
                  y2={landingPos.z}
                  stroke="#38bdf8"
                  strokeWidth={2.3}
                  strokeDasharray="3.2 2.6"
                  strokeLinecap="round"
                />
              )
            )}

            {/* Obstacle collision point warning marker */}
            {aimObstacleHit && (
              <g transform={`translate(${aimObstacleHit.x}, ${aimObstacleHit.z})`}>
                <circle r={3.5} fill="#fb923c" stroke="#ffffff" strokeWidth={0.9} />
                <text x={0} y={1.4} textAnchor="middle" fill="#0f172a" fontSize="4.5" fontWeight="900">
                  !
                </text>
              </g>
            )}

            {/* Target Landing Crosshair */}
            {landingPos && (
              <g transform={`translate(${landingPos.x}, ${landingPos.z})`}>
                <circle
                  r={4.8}
                  fill="none"
                  stroke={aimHitWater ? '#ef4444' : '#fde047'}
                  strokeWidth={1.3}
                  opacity={0.95}
                />
                <circle
                  r={2.2}
                  fill={aimHitWater ? '#ef4444' : '#fde047'}
                  stroke="#0f172a"
                  strokeWidth={0.8}
                />
              </g>
            )}
          </g>
        )}

        {/* Cup Flag (Vibrant Magenta-Pink matching 3D cup) */}
        <g transform={`translate(${hole.cup.x}, ${hole.cup.z})`}>
          <circle r={2.5} fill="#0f172a" />
          <line x1={0} y1={0} x2={0} y2={-15} stroke="#ffffff" strokeWidth={1.8} />
          <polygon points="0,-15 11,-11 0,-7" fill="#ec4899" stroke="#831843" strokeWidth={0.6} />
        </g>

        {/* Players Balls + Directional Arrow (or live flying ball) */}
        {activeShot && liveBallPos ? (
          <g transform={`translate(${liveBallPos.x}, ${liveBallPos.z})`}>
            <circle r={5.6} fill="none" stroke="#fde047" strokeWidth={1.5} opacity={0.9} />
            <circle r={3.6} fill="#ffffff" stroke="#0f172a" strokeWidth={1} />
          </g>
        ) : (
          players.map((p) => {
            if (p.holedOut) return null;
            const isMe = p.id === localPlayerId;
            const yaw = isMe && aimYaw !== undefined ? aimYaw : p.aimYaw;
            const arrowDeg = (Math.atan2(Math.sin(yaw), -Math.cos(yaw)) * 180) / Math.PI;
            return (
              <g key={p.id} transform={`translate(${p.ballPos.x}, ${p.ballPos.z})`}>
                {isMe && (
                  <g transform={`rotate(${arrowDeg})`}>
                    <polygon
                      points="0,-9 -3.2,-3.2 3.2,-3.2"
                      fill="#f97316"
                      stroke="#ffffff"
                      strokeWidth={0.6}
                    />
                  </g>
                )}
                <circle
                  r={isMe ? 3.8 : 2.8}
                  fill={isMe ? '#ffffff' : p.color}
                  stroke="#0f172a"
                  strokeWidth={1}
                />
              </g>
            );
          })
        )}
      </svg>

      {/* Embedded Bottom-Left Aim Distance / Obstacle Hint */}
      {predictedDistanceM !== undefined && !activeShot && (
        <div className="pointer-events-none absolute bottom-1.5 left-1.5 rounded bg-[#09120e]/85 border border-white/40 px-1.5 py-0.5 text-[10px] font-mono-tabular font-extrabold text-[#fde047] shadow">
          ~{predictedDistanceM}m{aimObstacleHit ? ' · Engel!' : ''}
        </div>
      )}

      {/* Embedded Bottom-Right Wind Speed Badge inside MiniMap */}
      {windSpeedMs !== undefined && (
        <div className="pointer-events-none absolute bottom-1.5 right-1.5 flex flex-col items-center">
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#09120e]/85 border-2 border-white/85 flex items-center justify-center shadow">
            <span className="font-mono-tabular text-[10px] font-extrabold text-white leading-none">
              {windSpeedMs.toFixed(0)}
            </span>
          </div>
          <span className="mt-0.5 text-[9px] sm:text-[10px] font-bold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] leading-none">
            {windSpeedMs.toFixed(1)} m/s
          </span>
        </div>
      )}
    </div>
  );
}
