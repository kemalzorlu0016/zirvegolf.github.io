import { Users, Play, UserCheck } from 'lucide-react';
import { CHARACTERS } from '../game/catalog.ts';
import type { CharacterId } from '../game/types.ts';
import { CharacterAvatarSvg, TitleCrestSvg } from './GolfIcons.tsx';

interface TitleScreenProps {
  selectedCharacterId: CharacterId;
  onStartSolo: () => void;
  onOpenMultiplayer: () => void;
  onOpenCharacterSelect: () => void;
}

export function TitleScreen({
  selectedCharacterId,
  onStartSolo,
  onOpenMultiplayer,
  onOpenCharacterSelect,
}: TitleScreenProps) {
  const char = CHARACTERS[selectedCharacterId];

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-6 sm:p-10">
      {/* Left-third calm sky region with Title Emblem & Primary Actions */}
      <div className="max-w-md pointer-events-auto">
        <TitleCrestSvg />

        <div className="mt-6 flex flex-col gap-3 max-w-xs">
          <button
            type="button"
            data-start="true"
            onClick={onStartSolo}
            className="flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#e5b84b] hover:bg-[#f0c75e] text-[#0c1a12] font-display font-bold text-lg shadow-lg transition-transform active:scale-[0.98] whitespace-nowrap"
          >
            <Play className="w-5 h-5 fill-current" aria-hidden="true" />
            Hemen Oyna (Solo)
          </button>

          <button
            type="button"
            onClick={onOpenMultiplayer}
            className="flex items-center justify-center gap-2.5 px-6 py-3 rounded-xl bg-[#11241a]/92 hover:bg-[#193527] text-stone-100 border border-white/20 font-semibold text-base shadow-md transition-colors whitespace-nowrap"
          >
            <Users className="w-4 h-4 text-[#38bdf8]" aria-hidden="true" />
            Online Çok Oyunculu
          </button>

          <button
            type="button"
            onClick={onOpenCharacterSelect}
            className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl bg-[#0e1b14]/88 hover:bg-[#172b20] text-stone-100 border border-white/15 transition-colors"
          >
            <div className="flex items-center gap-3 min-w-0">
              <CharacterAvatarSvg char={char} />
              <div className="text-left min-w-0">
                <div className="text-sm font-semibold text-white truncate">{char.name}</div>
                <div className="text-xs text-stone-300 truncate">
                  {char.specialPowerName}
                </div>
              </div>
            </div>
            <span className="flex items-center gap-1 text-xs font-semibold text-[#e5b84b] shrink-0 whitespace-nowrap">
              <UserCheck className="w-4 h-4" aria-hidden="true" />
              Değiştir
            </span>
          </button>
        </div>
      </div>

      {/* Bottom Safe Margin: Single flat borderless control hint */}
      <div className="text-center text-xs sm:text-sm font-medium text-stone-100 hud-text-shadow">
        A / D Nişan · 1–4 Sopa · Q Özel Güç · Space Basılı Tut Vuruş · C Kamera
      </div>
    </div>
  );
}
