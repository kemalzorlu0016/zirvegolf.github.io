import { useState } from 'react';
import {
  RefreshCw,
  Plus,
  LogIn,
  Play,
  LogOut,
  X,
  UserCheck,
  Bot,
  Copy,
  Check,
  Lock,
  Globe,
  Trash2,
} from 'lucide-react';
import { CHARACTERS } from '../game/catalog.ts';
import type { CharacterId, PublicRoomSummary, RoomState } from '../game/types.ts';
import { CharacterAvatarSvg } from './GolfIcons.tsx';

interface MultiplayerLobbyProps {
  connected: boolean;
  playerName: string;
  onChangePlayerName: (name: string) => void;
  selectedCharacterId: CharacterId;
  onOpenCharacterSelect: () => void;
  publicRooms: PublicRoomSummary[];
  currentRoom: RoomState | null;
  youId: string | null;
  errorMsg: string | null;
  onRefreshRooms: () => void;
  onCreateRoom: (customCode?: string, isPrivate?: boolean) => void;
  onJoinRoom: (code: string) => void;
  onAddBot: () => void;
  onRemoveBot: (botId: string) => void;
  onLeaveRoom: () => void;
  onStartMatch: () => void;
  onClose: () => void;
}

export function MultiplayerLobby({
  connected,
  playerName,
  onChangePlayerName,
  selectedCharacterId,
  onOpenCharacterSelect,
  publicRooms,
  currentRoom,
  youId,
  errorMsg,
  onRefreshRooms,
  onCreateRoom,
  onJoinRoom,
  onAddBot,
  onRemoveBot,
  onLeaveRoom,
  onStartMatch,
  onClose,
}: MultiplayerLobbyProps) {
  const [joinCode, setJoinCode] = useState('');
  const [customCode, setCustomCode] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const char = CHARACTERS[selectedCharacterId];
  const isHost = currentRoom && youId === currentRoom.hostId;

  const handleCopyCode = () => {
    if (!currentRoom) return;
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(currentRoom.code).catch(() => {});
    }
    setCopiedCode(true);
    window.setTimeout(() => setCopiedCode(false), 1800);
  };

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-black/70"
      role="dialog"
      aria-modal="true"
      aria-labelledby="mp-lobby-title"
    >
      <div className="w-full max-w-2xl rounded-2xl bg-[#102018] border border-white/15 shadow-2xl p-6 text-stone-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div>
            <h2 id="mp-lobby-title" className="font-display text-2xl font-bold text-white">
              Online Çok Oyunculu Lobi
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              {connected
                ? 'Sunucuya bağlı · Gerçek oyuncular ve CPU rakiplerle oyna'
                : 'Sunucuya bağlanılıyor...'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Lobiyi kapat"
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="mt-4 px-4 py-2.5 rounded-lg bg-red-950/90 border border-red-400/40 text-red-100 text-sm">
            {errorMsg}
          </div>
        )}

        {/* Player Identity & Character Switcher */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="mp-player-name" className="block text-xs font-semibold text-stone-300 mb-1.5">
              Oyuncu Adın
            </label>
            <input
              id="mp-player-name"
              type="text"
              maxLength={18}
              value={playerName}
              onChange={(e) => onChangePlayerName(e.target.value)}
              placeholder="Adını yaz..."
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#0b1510] border border-white/15 text-white text-sm focus:outline-none focus:border-[#e5b84b]"
            />
          </div>
          <div>
            <div className="text-xs font-semibold text-stone-300 mb-1.5">Seçili Karakter</div>
            <button
              type="button"
              onClick={onOpenCharacterSelect}
              className="w-full flex items-center justify-between gap-2 px-3 py-1.5 rounded-lg bg-[#0b1510] border border-white/15 hover:border-[#e5b84b] text-left transition-colors"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <CharacterAvatarSvg char={char} />
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white truncate">{char.name}</div>
                  <div className="text-xs text-[#e5b84b] truncate">{char.specialPowerName}</div>
                </div>
              </div>
              <UserCheck className="w-4 h-4 text-stone-300 shrink-0" aria-hidden="true" />
            </button>
          </div>
        </div>

        {!currentRoom ? (
          <div className="mt-5 space-y-5">
            {/* Create Room with Optional Custom Lobby Code + Join by Code */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-[#0b1510] border border-white/10 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#e5b84b]">
                    Yeni Lobi Kur
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsPrivate((v) => !v)}
                    aria-pressed={isPrivate}
                    className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-md border transition-colors ${
                      isPrivate
                        ? 'bg-amber-500/15 border-[#e5b84b]/60 text-[#e5b84b]'
                        : 'bg-white/5 border-white/15 text-stone-300 hover:text-white'
                    }`}
                  >
                    {isPrivate ? (
                      <>
                        <Lock className="w-3 h-3" aria-hidden="true" />
                        Gizli (Kodla)
                      </>
                    ) : (
                      <>
                        <Globe className="w-3 h-3" aria-hidden="true" />
                        Herkese Açık
                      </>
                    )}
                  </button>
                </div>

                <label htmlFor="custom-room-code" className="sr-only">
                  Özel Lobi Kodu (İsteğe Bağlı)
                </label>
                <input
                  id="custom-room-code"
                  type="text"
                  maxLength={6}
                  value={customCode}
                  onChange={(e) =>
                    setCustomCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))
                  }
                  placeholder="Özel Kod (boşsa otomatik)"
                  className="w-full px-3 py-2 rounded-lg bg-[#102018] border border-white/15 text-white text-sm font-mono-tabular uppercase placeholder:normal-case placeholder:font-sans placeholder:text-stone-500 focus:outline-none focus:border-[#e5b84b]"
                />

                <button
                  type="button"
                  disabled={!connected}
                  onClick={() => onCreateRoom(customCode.trim() || undefined, isPrivate)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#e5b84b] hover:bg-[#f0c75e] disabled:opacity-50 text-[#0c1a12] font-display font-bold text-sm transition-colors whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" aria-hidden="true" />
                  Yeni Oda Kur
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (joinCode.trim()) onJoinRoom(joinCode.trim());
                }}
                className="p-3.5 rounded-xl bg-[#0b1510] border border-white/10 flex flex-col justify-between gap-2.5"
              >
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-sky-300">
                    Lobi Kodu ile Katıl
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    Arkadaşının paylaştığı 3–6 haneli lobi kodunu gir.
                  </p>
                </div>

                <div className="space-y-2.5">
                  <label htmlFor="join-room-code" className="sr-only">
                    Lobi Kodu
                  </label>
                  <input
                    id="join-room-code"
                    type="text"
                    maxLength={6}
                    value={joinCode}
                    onChange={(e) =>
                      setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))
                    }
                    placeholder="Lobi Kodu (örn. KUPA26)"
                    className="w-full px-3 py-2 rounded-lg bg-[#102018] border border-white/15 text-white text-sm font-mono-tabular uppercase placeholder:normal-case placeholder:font-sans placeholder:text-stone-500 focus:outline-none focus:border-[#38bdf8]"
                  />
                  <button
                    type="submit"
                    disabled={!connected || joinCode.trim().length < 3}
                    className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 disabled:opacity-40 text-white text-sm font-semibold transition-colors whitespace-nowrap"
                  >
                    <LogIn className="w-4 h-4" aria-hidden="true" />
                    Koduyla Katıl
                  </button>
                </div>
              </form>
            </div>

            {/* Public Rooms List */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-semibold text-stone-200">Açık Odalar</h3>
                <button
                  type="button"
                  onClick={onRefreshRooms}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-[#38bdf8] hover:text-sky-300"
                >
                  <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
                  Yenile
                </button>
              </div>
              {publicRooms.length === 0 ? (
                <div className="p-5 rounded-xl bg-[#0b1510] border border-white/10 text-center text-sm text-stone-400">
                  Şu anda açık oda yok. Yeni oda kurup lobi kodunu paylaşabilir veya CPU rakipler ekleyebilirsin.
                </div>
              ) : (
                <div className="space-y-2">
                  {publicRooms.map((r) => {
                    const humanCount = Math.max(0, r.playerCount - r.botCount);
                    return (
                      <div
                        key={r.code}
                        className="flex items-center justify-between gap-3 px-4 py-3 rounded-xl bg-[#0b1510] border border-white/10"
                      >
                        <div className="min-w-0">
                          <div className="text-sm font-bold text-white flex items-center gap-2">
                            <span className="font-mono-tabular text-[#e5b84b]">{r.code}</span>
                            <span className="text-stone-400">·</span>
                            <span className="truncate">{r.hostName}</span>
                          </div>
                          <div className="text-xs text-stone-400 tabular-nums">
                            {humanCount} Oyuncu
                            {r.botCount > 0 ? ` + ${r.botCount} CPU` : ''} ({r.playerCount}/
                            {r.maxPlayers}) · {r.status === 'waiting' ? 'Bekliyor' : 'Oyunda'}
                          </div>
                        </div>
                        <button
                          type="button"
                          aria-label={`${r.code} odasına katıl`}
                          disabled={r.status !== 'waiting' || r.playerCount >= r.maxPlayers}
                          onClick={() => onJoinRoom(r.code)}
                          className="px-4 py-2 rounded-lg bg-[#e5b84b] hover:bg-[#f0c75e] disabled:opacity-40 text-[#0c1a12] text-xs font-bold whitespace-nowrap"
                        >
                          Katıl
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Inside Waiting Room */
          <div className="mt-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-[#0b1510] border border-[#e5b84b]/45">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-stone-400 uppercase tracking-wider font-semibold">
                    Lobi Kodu
                  </span>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded bg-white/10 text-stone-200">
                    {currentRoom.isPrivate ? (
                      <>
                        <Lock className="w-3 h-3 text-[#e5b84b]" aria-hidden="true" />
                        Gizli · Sadece Kodla
                      </>
                    ) : (
                      <>
                        <Globe className="w-3 h-3 text-emerald-400" aria-hidden="true" />
                        Herkese Açık
                      </>
                    )}
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-1">
                  <div
                    data-testid="lobby-room-code"
                    className="font-mono-tabular text-3xl font-bold text-[#e5b84b] tracking-wider"
                  >
                    {currentRoom.code}
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
                        Kopyalandı!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                        Kodu Kopyala
                      </>
                    )}
                  </button>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-stone-400">Lobi Doluluğu</div>
                <div className="text-base font-bold text-stone-100 tabular-nums">
                  {currentRoom.players.length} / 4 Oyuncu
                </div>
                <div className="text-[11px] text-stone-400 mt-0.5">
                  Arkadaşların kodla katılabilir veya CPU ekleyebilirsin
                </div>
              </div>
            </div>

            <div className="space-y-2">
              {currentRoom.players.map((p) => {
                const pChar = CHARACTERS[p.characterId];
                return (
                  <div
                    key={p.id}
                    className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl bg-[#0b1510] border border-white/10"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <CharacterAvatarSvg char={pChar} />
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <span
                            className="inline-block w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ backgroundColor: p.color }}
                          />
                          <span className="truncate">{p.name}</span>
                          {p.isBot && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-sky-500/20 border border-sky-400/40 text-sky-200 text-[11px] font-semibold">
                              <Bot className="w-3 h-3" aria-hidden="true" />
                              CPU
                            </span>
                          )}
                          {p.id === youId && (
                            <span className="text-xs text-[#e5b84b] font-semibold">(Sen)</span>
                          )}
                        </div>
                        <div className="text-xs text-stone-400 truncate">
                          {pChar.name} · {pChar.specialPowerName}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {p.id === currentRoom.hostId && (
                        <span className="text-xs font-semibold text-stone-300">Kurucu</span>
                      )}
                      {isHost && p.isBot && (
                        <button
                          type="button"
                          onClick={() => onRemoveBot(p.id)}
                          aria-label={`${p.name} botunu çıkar`}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/25 text-stone-300 hover:text-red-200 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={onLeaveRoom}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-stone-200 text-sm font-semibold"
                >
                  <LogOut className="w-4 h-4" aria-hidden="true" />
                  Odadan Ayrıl
                </button>

                {isHost && currentRoom.players.length < 4 && (
                  <button
                    type="button"
                    onClick={onAddBot}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/40 text-sky-100 text-sm font-semibold transition-colors"
                  >
                    <Bot className="w-4 h-4" aria-hidden="true" />
                    + CPU Rakip Ekle
                  </button>
                )}
              </div>

              {isHost ? (
                <button
                  type="button"
                  onClick={onStartMatch}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#e5b84b] hover:bg-[#f0c75e] text-[#0c1a12] font-display font-bold text-base shadow-lg"
                >
                  <Play className="w-4 h-4 fill-current" aria-hidden="true" />
                  Maçı Başlat
                </button>
              ) : (
                <div className="text-sm text-stone-300">
                  Oda kurucusunun maçı başlatması bekleniyor...
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
