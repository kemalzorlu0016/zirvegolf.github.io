import { useRef, type PointerEvent as ReactPointerEvent } from 'react';
import {
  Camera,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ClipboardList,
  Pause,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { CHARACTERS, CLUB_ORDER, GOLF_CLUBS, recommendClubForSituation } from '../game/catalog.ts';
import { computeLaunchParameters, simulateShotTrajectory } from '../game/physics.ts';
import type {
  CameraMode,
  ClubId,
  HoleDefinition,
  PlayerMatchState,
  SurfaceType,
} from '../game/types.ts';
import { CharacterAvatarSvg, ClubIconSvg, PowerIconSvg } from './GolfIcons.tsx';
import { type ActiveMapFlight, MiniMap, type MiniMapShotRecord } from './MiniMap.tsx';

export interface CenterCallout {
  title: string;
  subtitle?: string;
  tone?: 'emerald' | 'gold' | 'cyan' | 'red';
}

interface GameHudProps {
  hole: HoleDefinition;
  totalHoles: number;
  wind: { x: number; z: number };
  distanceToCupM: number;
  currentSurface: SurfaceType;
  isMultiplayer: boolean;
  roomCode: string | null;
  players: PlayerMatchState[];
  activePlayer: PlayerMatchState;
  localPlayer: PlayerMatchState;
  isMyTurn: boolean;
  isFlightPlaying: boolean;
  selectedClub: ClubId;
  aimYaw: number;
  powerRatio: number;
  isCharging: boolean;
  powerActive: boolean;
  cameraMode: CameraMode;
  muted: boolean;
  dockCollapsed: boolean;
  lastEventText: string;
  centerCallout: CenterCallout | null;
  shotHistory?: MiniMapShotRecord[];
  activeShot?: ActiveMapFlight | null;
  onSelectClub: (clubId: ClubId) => void;
  onAdjustAim: (deltaRad: number) => void;
  onPowerRatioChange: (ratio: number) => void;
  onShootNow: () => void;
  onTogglePower: () => void;
  onCycleCamera: () => void;
  onToggleMute: () => void;
  onOpenScorecard: () => void;
  onPause: () => void;
  onToggleDock: () => void;
}

const SURFACE_LABELS: Record<SurfaceType, string> = {
  tee: 'Tee',
  fairway: 'Fairway',
  rough: 'Uzun Çim',
  bunker: 'Kum Tuzağı',
  green: 'Green',
  water: 'Su',
  oob: 'Saha Dışı',
};

const CAMERA_LABELS: Record<CameraMode, string> = {
  aim: 'Nişan',
  follow: 'Takip',
  overhead: 'Kuş Bakışı',
};

export function GameHud({
  hole,
  totalHoles,
  wind,
  distanceToCupM,
  currentSurface,
  isMultiplayer,
  roomCode,
  players,
  activePlayer,
  localPlayer,
  isMyTurn,
  isFlightPlaying,
  selectedClub,
  aimYaw,
  powerRatio,
  isCharging,
  powerActive,
  cameraMode,
  muted,
  dockCollapsed,
  lastEventText,
  centerCallout,
  shotHistory,
  activeShot,
  onSelectClub,
  onAdjustAim,
  onPowerRatioChange,
  onShootNow,
  onTogglePower,
  onCycleCamera,
  onToggleMute,
  onOpenScorecard,
  onPause,
  onToggleDock,
}: GameHudProps) {
  const char = CHARACTERS[localPlayer.characterId];
  const recommendedClub = recommendClubForSituation(distanceToCupM, currentSurface);
  const windSpeedMs = Math.hypot(wind.x, wind.z);
  const windAngleDeg = (Math.atan2(wind.x, wind.z) * 180) / Math.PI;

  const launchPreview = computeLaunchParameters({
    holeIndex: hole.index,
    startPos: localPlayer.ballPos,
    clubId: selectedClub,
    characterId: localPlayer.characterId,
    powerRatio,
    aimYaw,
    wind,
    powerActive,
  });

  const simPreview = simulateShotTrajectory({
    holeIndex: hole.index,
    startPos: localPlayer.ballPos,
    clubId: selectedClub,
    characterId: localPlayer.characterId,
    powerRatio,
    aimYaw,
    wind,
    powerActive,
  });

  const canAct = isMyTurn && !isFlightPlaying && !localPlayer.holedOut;

  // Vertical power gauge pointer drag
  const powerTrackRef = useRef<HTMLDivElement | null>(null);
  const isDraggingPowerRef = useRef(false);

  const updatePowerFromPointer = (clientY: number) => {
    const el = powerTrackRef.current;
    if (!el || !canAct) return;
    const rect = el.getBoundingClientRect();
    const raw = 1 - (clientY - rect.top) / rect.height;
    const clamped = Math.max(0.1, Math.min(1, raw));
    onPowerRatioChange(clamped);
  };

  const handlePowerPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!canAct) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    isDraggingPowerRef.current = true;
    updatePowerFromPointer(e.clientY);
  };

  const handlePowerPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!isDraggingPowerRef.current) return;
    updatePowerFromPointer(e.clientY);
  };

  const handlePowerPointerUp = () => {
    isDraggingPowerRef.current = false;
  };

  const powerPct = Math.round(powerRatio * 100);

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none">
      {/* TOP-LEFT: Switch Sports Hole Strip + Turquoise Player Banner + Stroke Counter */}
      <div className="absolute top-3 left-3 sm:top-4 sm:left-4 flex flex-col items-start gap-1.5">
        {/* Hole & Par Dark Gradient Strip */}
        <div className="pointer-events-auto flex items-center gap-3 bg-gradient-to-r from-[#090e14]/92 via-[#0f172a]/85 to-[#0f172a]/35 border-l-4 border-white px-3.5 py-1.5 rounded-r-md shadow-lg">
          <span className="font-display text-lg sm:text-xl font-extrabold text-white tracking-tight drop-shadow tabular-nums">
            Delik {hole.index + 1} · Par {hole.par}
          </span>
          <span className="hidden sm:inline text-xs font-semibold text-stone-200/90">
            {distanceToCupM} m · {SURFACE_LABELS[currentSurface]} · {hole.index + 1}/{totalHoles}
          </span>
        </div>

        {/* Turquoise Player Identity Pill + Overlapping Circular Portrait */}
        <div className="pointer-events-auto relative flex items-center mt-0.5 pl-5">
          <div className="relative flex items-center pl-10 pr-4 py-1 rounded-full bg-gradient-to-r from-[#2dd4bf] via-[#14b8a6] to-[#0891b2]/85 border border-white/85 shadow-lg">
            <div className="absolute -left-5 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 border-white shadow-lg overflow-hidden bg-[#0e1b14]">
              <CharacterAvatarSvg char={char} className="w-full h-full rounded-full" />
            </div>
            <span className="font-display text-sm sm:text-base font-extrabold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.65)] whitespace-nowrap">
              {isMultiplayer ? localPlayer.name : char.name}
            </span>
          </div>
        </div>

        {/* Stroke / Multiplayer Turn Ribbon */}
        <div className="pointer-events-auto ml-7 flex items-center gap-2 rounded-md bg-[#0f172a]/88 border border-white/25 px-3.5 py-0.5 shadow-md">
          <span className="font-display text-xs sm:text-sm font-bold text-white tabular-nums">
            {isMultiplayer ? (
              isMyTurn ? (
                <span className="text-[#fde047]">
                  Sıra Sende · Vuruş {localPlayer.currentHoleStrokes + 1}
                </span>
              ) : (
                <span>Sıra: {activePlayer.name}</span>
              )
            ) : (
              <span>Vuruş {localPlayer.currentHoleStrokes + 1}</span>
            )}
          </span>
          {isMultiplayer && roomCode && (
            <span className="text-[10px] font-mono-tabular font-bold text-cyan-300 border-l border-white/20 pl-2">
              Oda {roomCode}
            </span>
          )}
        </div>
      </div>

      {/* TOP-CENTER: Transient Event Readout */}
      {lastEventText && (
        <div className="hidden lg:flex justify-center pt-4">
          <div className="rounded-full bg-[#09120e]/80 border border-white/25 px-4 py-1 text-xs font-semibold text-white shadow">
            {lastEventText}
          </div>
        </div>
      )}

      {/* TOP-RIGHT: Utility Buttons + Iconic Circular Turf/Wind Disc + Camera/Zoom + MiniMap */}
      <div className="absolute top-3 right-3 sm:top-4 sm:right-4 flex flex-col items-end gap-2">
        <div className="flex items-start gap-2.5">
          {/* Compact Utility Buttons */}
          <div className="pointer-events-auto flex items-center gap-1 pt-1">
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onOpenScorecard();
              }}
              title="Skor Kartı"
              aria-label="Skor Kartı"
              className="w-9 h-9 rounded-lg bg-[#09120e]/75 hover:bg-[#14261d] border border-white/25 flex items-center justify-center text-white transition-colors"
            >
              <ClipboardList className="w-4 h-4" />
            </button>
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onToggleMute();
              }}
              title="Sesi Aç / Kapat [M]"
              aria-label={muted ? 'Sesi Aç' : 'Sesi Kapat'}
              className="w-9 h-9 rounded-lg bg-[#09120e]/75 hover:bg-[#14261d] border border-white/25 flex items-center justify-center text-white transition-colors"
            >
              {muted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onPause();
              }}
              title="Duraklat [P]"
              aria-label="Oyunu Duraklat"
              className="w-9 h-9 rounded-lg bg-[#09120e]/75 hover:bg-[#14261d] border border-white/25 flex items-center justify-center text-white transition-colors"
            >
              <Pause className="w-4 h-4" />
            </button>
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onToggleDock();
              }}
              title={dockCollapsed ? 'Kontrolleri Göster [H]' : 'Kontrolleri Gizle [H]'}
              aria-label={dockCollapsed ? 'Kontrolleri Göster' : 'Kontrolleri Gizle'}
              className="w-9 h-9 rounded-lg bg-[#09120e]/75 hover:bg-[#14261d] border border-white/25 flex items-center justify-center text-white transition-colors"
            >
              {dockCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {/* Iconic Circular Wind & Mowed Turf Disc (Switch Sports style) */}
          <div
            className="pointer-events-auto w-20 h-20 sm:w-24 sm:h-24 rounded-full border-2 border-white/95 bg-[#0f172a]/55 shadow-xl flex flex-col items-center justify-center relative"
            aria-label={`Rüzgar ${windSpeedMs.toFixed(1)} metre bölü saniye`}
          >
            {/* Inner Striped Green Turf Circle + Wind Direction Arrow */}
            <div
              className="w-11 h-11 sm:w-13 sm:h-13 rounded-full border border-white/60 shadow-inner relative overflow-hidden flex items-center justify-center"
              style={{
                background:
                  'repeating-linear-gradient(90deg, #6dc933 0px, #6dc933 5px, #53af24 5px, #53af24 10px)',
              }}
            >
              <span
                className="text-white font-black text-base sm:text-lg drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]"
                style={{ transform: `rotate(${Math.round(windAngleDeg)}deg)` }}
                aria-hidden="true"
              >
                ↑
              </span>
            </div>
            <span className="mt-1 font-mono-tabular text-[11px] sm:text-xs font-extrabold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] leading-none">
              {windSpeedMs.toFixed(1)} m/s
            </span>
          </div>
        </div>

        {/* Camera / Zoom Button right above MiniMap */}
        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.currentTarget.blur();
            onCycleCamera();
          }}
          title="Kamera Modu Değiştir [C]"
          className="pointer-events-auto inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#09120e]/75 hover:bg-[#14261d] border border-white/60 text-xs font-bold text-white shadow transition-colors"
        >
          <Camera className="w-3.5 h-3.5 text-cyan-300" aria-hidden="true" />
          <span>[C] {CAMERA_LABELS[cameraMode]}</span>
        </button>

        {/* Crisp Rectangular White-Bordered MiniMap (Always Visible) */}
        <div className="pointer-events-auto">
          <MiniMap
            hole={hole}
            players={players}
            localPlayerId={localPlayer.id}
            aimYaw={aimYaw}
            aimPoints={simPreview.points}
            landingPos={
              simPreview.hitWater
                ? (simPreview.points[simPreview.points.length - 1] ?? simPreview.finalPos)
                : simPreview.finalPos
            }
            aimHitWater={simPreview.hitWater}
            aimObstacleHit={simPreview.obstacleHits?.[0]}
            predictedDistanceM={simPreview.totalDistanceM}
            shotHistory={shotHistory}
            activeShot={activeShot}
            windSpeedMs={windSpeedMs}
          />
        </div>
      </div>

      {/* CENTER CALLOUT BANNER (Eagle / Birdie / Green approach) */}
      {(centerCallout || (currentSurface === 'green' && !isFlightPlaying && isMyTurn)) && (
        <div className="pointer-events-none absolute top-20 inset-x-0 flex justify-center">
          {centerCallout ? (
            <div
              className={`rounded-2xl border-2 px-7 py-2 text-center shadow-2xl ${
                centerCallout.tone === 'gold'
                  ? 'bg-[#1a2e1f]/95 border-[#fde047] text-[#fde047]'
                  : centerCallout.tone === 'red'
                    ? 'bg-[#2a1414]/95 border-red-400 text-red-200'
                    : centerCallout.tone === 'cyan'
                      ? 'bg-[#0e2230]/95 border-sky-400 text-sky-100'
                      : 'bg-[#11291b]/95 border-[#34d399] text-[#6ee7b7]'
              }`}
            >
              <div className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight drop-shadow">
                {centerCallout.title}
              </div>
              {centerCallout.subtitle && (
                <div className="text-xs sm:text-sm font-semibold text-white mt-0.5">
                  {centerCallout.subtitle}
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-2xl bg-[#11291b]/88 border border-[#34d399]/75 px-6 py-1.5 text-center shadow-xl">
              <div className="font-display text-lg sm:text-xl font-extrabold text-[#6ee7b7] tracking-tight">
                Green
              </div>
              <div className="text-xs font-mono-tabular font-bold text-white">
                {distanceToCupM} m kaldı · Putter
              </div>
            </div>
          )}
        </div>
      )}

      {/* LEFT-MIDDLE: Vertical Interactive Power & Shot Speed Meter (matches white vertical bar with 3 pips!) */}
      {!dockCollapsed && (
        <div className="pointer-events-auto absolute left-4 sm:left-10 top-[54%] -translate-y-1/2 flex items-center gap-2.5">
          <div className="flex flex-col items-center gap-1.5">
            {/* Vertical White-Outlined Power Track */}
            <div
              ref={powerTrackRef}
              onPointerDown={handlePowerPointerDown}
              onPointerMove={handlePowerPointerMove}
              onPointerUp={handlePowerPointerUp}
              onPointerCancel={handlePowerPointerUp}
              role="slider"
              aria-label="Atış Hızı ve Güç Yüzdesi"
              aria-valuemin={10}
              aria-valuemax={100}
              aria-valuenow={powerPct}
              className={`relative w-4 h-44 sm:h-52 border-2 border-white/95 rounded-sm bg-black/35 shadow-lg overflow-visible ${
                canAct ? 'cursor-ns-resize' : 'opacity-60'
              }`}
            >
              {/* Golden Level Fill */}
              <div
                className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#f59e0b] to-[#fde047] transition-[height] duration-75"
                style={{ height: `${powerPct}%` }}
              />

              {/* 3 Crisp White Reference Dots */}
              {[25, 50, 75].map((tick) => (
                <div
                  key={tick}
                  className="pointer-events-none absolute left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-white shadow"
                  style={{ bottom: `${tick}%` }}
                />
              ))}

              {/* Active Golden Marker Dot at current power level */}
              <div
                className="pointer-events-none absolute left-1/2 -translate-x-1/2 translate-y-1/2 w-3.5 h-3.5 rounded-full bg-[#fde047] border-2 border-white shadow"
                style={{ bottom: `${powerPct}%` }}
              />
            </div>

            {/* Subtle Fine Range Stepper Readout */}
            <div className="rounded-lg bg-[#09120e]/82 border border-white/25 px-2 py-1 text-center shadow">
              <div className="font-mono-tabular text-[11px] font-extrabold text-[#fde047] leading-tight">
                %{powerPct} {isCharging ? '⚡' : ''}
              </div>
              <div className="font-mono-tabular text-[10px] font-semibold text-white/90 leading-tight whitespace-nowrap">
                {launchPreview.speedKmh} km/s · ~{simPreview.totalDistanceM}m
              </div>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM-LEFT: Aim Direction Controls (matching "Direction" slot, leaving bottom-center totally clear!) */}
      {!dockCollapsed && (
        <div className="pointer-events-auto absolute bottom-3 left-3 sm:bottom-4 sm:left-4 flex items-center gap-1.5 rounded-full bg-[#09120e]/78 border border-white/40 px-2.5 py-1.5 shadow-lg">
          <button
            type="button"
            disabled={!canAct}
            onClick={() => onAdjustAim(0.06)}
            aria-label="Sola nişan al"
            className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 disabled:opacity-40 flex items-center justify-center text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-bold text-white px-1 whitespace-nowrap">
            [A/D] Nişan
          </span>
          <button
            type="button"
            disabled={!canAct}
            onClick={() => onAdjustAim(-0.06)}
            aria-label="Sağa nişan al"
            className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 disabled:opacity-40 flex items-center justify-center text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* BOTTOM-RIGHT: Circular 4-Club Medallions + Special Power [Q] + Swing CTA (cleanly clear of center tee!) */}
      {!dockCollapsed && (
        <div className="pointer-events-auto absolute bottom-3 right-3 sm:bottom-4 sm:right-4 flex flex-col items-end gap-1.5">
          <div className="flex items-center gap-2">
            {/* Circular Club Wheel */}
            <div className="flex items-center gap-1.5">
              {CLUB_ORDER.map((cid) => {
                const club = GOLF_CLUBS[cid];
                const active = selectedClub === cid;
                const isRec = recommendedClub === cid;
                return (
                  <button
                    key={cid}
                    type="button"
                    disabled={!canAct}
                    onClick={(e) => {
                      e.currentTarget.blur();
                      onSelectClub(cid);
                    }}
                    title={`[${club.keyHint}] ${club.name} (~${club.approxMaxMeters}m · ${club.loftDeg}°)`}
                    aria-label={`${club.shortName} sopası`}
                    className={`relative w-11 h-11 sm:w-13 sm:h-13 rounded-full flex items-center justify-center transition-all ${
                      active
                        ? 'bg-[#0f172a]/90 border-2 border-white scale-110 shadow-xl ring-2 ring-[#fde047]/70'
                        : 'bg-[#09120e]/70 hover:bg-[#13241c] border border-white/50 opacity-90'
                    } disabled:opacity-45`}
                  >
                    <ClubIconSvg clubId={cid} active={false} />
                    <span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-[#09120e] border border-white/60 text-[9px] font-bold text-white flex items-center justify-center">
                      {club.keyHint}
                    </span>
                    {isRec && !active && (
                      <span
                        className="absolute -bottom-0.5 right-0 w-2.5 h-2.5 rounded-full bg-[#34d399] border border-white"
                        title="Önerilen Sopa"
                      />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Circular Character Special Power [Q] */}
            <button
              type="button"
              disabled={!canAct || localPlayer.powerCharges <= 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onTogglePower();
              }}
              title={`[Q] ${char.specialPowerName}: ${char.specialPowerDesc}`}
              aria-label={`Özel Güç: ${char.specialPowerName}`}
              className={`relative w-11 h-11 sm:w-13 sm:h-13 rounded-full flex items-center justify-center transition-all ${
                powerActive
                  ? 'bg-[#166534] border-2 border-[#4ade80] scale-105 shadow-xl'
                  : 'bg-[#09120e]/75 hover:bg-[#15281e] border border-white/50'
              } disabled:opacity-40`}
            >
              <PowerIconSvg powerId={char.specialPowerId} />
              <span className="absolute -top-1 -right-1 px-1 rounded-full bg-[#09120e] border border-white/60 text-[9px] font-bold text-[#fde047]">
                Q·{localPlayer.powerCharges}
              </span>
            </button>

            {/* Primary Shot Action Button */}
            <button
              type="button"
              disabled={!canAct}
              onClick={(e) => {
                e.currentTarget.blur();
                onShootNow();
              }}
              className="px-4 sm:px-5 py-2.5 rounded-full bg-gradient-to-b from-[#fde047] to-[#eab308] hover:brightness-105 disabled:opacity-45 text-[#0b1610] font-display font-extrabold text-xs sm:text-sm border-2 border-white shadow-xl transition-transform active:scale-[0.97] whitespace-nowrap"
            >
              {isFlightPlaying
                ? 'Top Havada...'
                : !isMyTurn
                  ? 'Rakip Sırası'
                  : 'Vuruş Yap [Space]'}
            </button>
          </div>

          {/* Crisp Active Club & Power Caption below the circular row (matching "Driver" caption!) */}
          <div className="flex items-center gap-2 text-xs font-extrabold text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] pr-1">
            <span>{GOLF_CLUBS[selectedClub].shortName}</span>
            <span className="text-white/70">·</span>
            <span className="font-mono-tabular text-[#fde047]">
              ~{GOLF_CLUBS[selectedClub].approxMaxMeters}m · {GOLF_CLUBS[selectedClub].loftDeg}°
            </span>
            {powerActive && (
              <span className="text-[#4ade80]">· {char.specialPowerName} Aktif!</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
