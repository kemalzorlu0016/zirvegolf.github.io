import { X, Check } from 'lucide-react';
import { CHARACTERS, CHARACTER_ORDER } from '../game/catalog.ts';
import type { CharacterId } from '../game/types.ts';
import { CharacterAvatarSvg, PowerIconSvg } from './GolfIcons.tsx';

interface CharacterModalProps {
  selectedId: CharacterId;
  onSelect: (id: CharacterId) => void;
  onClose: () => void;
}

export function CharacterModal({ selectedId, onSelect, onClose }: CharacterModalProps) {
  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/70"
      role="dialog"
      aria-modal="true"
      aria-labelledby="character-modal-title"
    >
      <div className="w-full max-w-3xl rounded-2xl bg-[#102018] border border-white/15 shadow-2xl p-6 text-stone-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div>
            <h2 id="character-modal-title" className="font-display text-2xl font-bold text-white">
              Karakter Seçimi ve Özel Güçler
            </h2>
            <p className="text-sm text-stone-300 mt-0.5">
              Her golfçünün atış gücü, kontrol dengesi ve maç başına 3 kullanımlık özel gücü vardır.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Karakter penceresini kapat"
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5">
          {CHARACTER_ORDER.map((cid) => {
            const char = CHARACTERS[cid];
            const isSelected = cid === selectedId;
            return (
              <button
                key={cid}
                type="button"
                onClick={() => {
                  onSelect(cid);
                  onClose();
                }}
                className={`text-left p-4 rounded-xl border transition-colors flex flex-col gap-3 ${
                  isSelected
                    ? 'bg-[#183325] border-[#e5b84b]'
                    : 'bg-[#0c1711] border-white/10 hover:border-white/30'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <CharacterAvatarSvg char={char} />
                    <div>
                      <div className="font-display text-lg font-bold text-white">{char.name}</div>
                      <div className="text-xs text-stone-400">{char.title}</div>
                    </div>
                  </div>
                  {isSelected && (
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-[#e5b84b]">
                      <Check className="w-4 h-4" aria-hidden="true" />
                      Seçili
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-300 leading-relaxed">{char.bio}</p>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <div className="text-stone-400 mb-1">Güç</div>
                    <div className="h-1.5 rounded bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-[#f59e0b]"
                        style={{ width: `${char.powerStat * 10}%` }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="text-stone-400 mb-1">Kontrol</div>
                    <div className="h-1.5 rounded bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-[#38bdf8]"
                        style={{ width: `${char.controlStat * 10}%` }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="text-stone-400 mb-1">Spin</div>
                    <div className="h-1.5 rounded bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-[#34d399]"
                        style={{ width: `${char.spinStat * 10}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Special Power Box */}
                <div className="pt-2.5 border-t border-white/10 flex items-start gap-2.5">
                  <PowerIconSvg powerId={char.specialPowerId} />
                  <div>
                    <div className="text-xs font-bold text-[#e5b84b]">
                      Özel Güç: {char.specialPowerName}
                    </div>
                    <div className="text-xs text-stone-300 mt-0.5">{char.specialPowerDesc}</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
