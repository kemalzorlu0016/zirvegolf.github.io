import { Trophy, RotateCcw, Home, Play, X } from 'lucide-react';
import { CHARACTERS } from '../game/catalog.ts';
import { HOLES } from '../game/courses.ts';
import type { PlayerMatchState } from '../game/types.ts';

interface PauseModalProps {
  onResume: () => void;
  onResetHole: () => void;
  onBackToTitle: () => void;
}

export function PauseModal({ onResume, onResetHole, onBackToTitle }: PauseModalProps) {
  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/70"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pause-modal-title"
    >
      <div className="w-full max-w-sm rounded-2xl bg-[#102018] border border-white/15 p-6 text-center shadow-2xl">
        <h2 id="pause-modal-title" className="font-display text-2xl font-bold text-white">
          Oyun Duraklatıldı
        </h2>
        <p className="text-sm text-stone-300 mt-1">Devam edebilir veya ana menüye dönebilirsin.</p>

        <div className="mt-6 flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#e5b84b] hover:bg-[#f0c75e] text-[#0b1610] font-display font-bold text-base"
          >
            <Play className="w-4 h-4 fill-current" aria-hidden="true" />
            Devam Et
          </button>
          <button
            type="button"
            onClick={onResetHole}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-sm font-semibold"
          >
            <RotateCcw className="w-4 h-4" aria-hidden="true" />
            Deliği Sıfırla
          </button>
          <button
            type="button"
            onClick={onBackToTitle}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/15 text-stone-300 text-sm font-semibold"
          >
            <Home className="w-4 h-4" aria-hidden="true" />
            Ana Menüye Dön
          </button>
        </div>
      </div>
    </div>
  );
}

interface ScorecardModalProps {
  players: PlayerMatchState[];
  currentHoleIndex: number;
  onClose: () => void;
}

export function ScorecardModal({ players, currentHoleIndex, onClose }: ScorecardModalProps) {
  const totalPar = HOLES.reduce((sum, h) => sum + h.par, 0);

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/70"
      role="dialog"
      aria-modal="true"
      aria-labelledby="scorecard-title"
    >
      <div className="w-full max-w-xl rounded-2xl bg-[#102018] border border-white/15 p-6 shadow-2xl text-stone-100">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <h2 id="scorecard-title" className="font-display text-xl font-bold text-white">
            Turnuva Skor Kartı
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Skor kartını kapat"
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-stone-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm text-left tabular-nums">
            <thead>
              <tr className="text-xs text-stone-400 border-b border-white/10">
                <th className="py-2 pr-3">Oyuncu</th>
                {HOLES.map((h) => (
                  <th key={h.index} className="py-2 px-2 text-center">
                    D{h.index + 1} (P{h.par})
                  </th>
                ))}
                <th className="py-2 pl-3 text-right">Toplam ({totalPar})</th>
              </tr>
            </thead>
            <tbody>
              {players.map((p) => (
                <tr key={p.id} className="border-b border-white/5">
                  <td className="py-2.5 pr-3">
                    <div className="font-semibold text-white">{p.name}</div>
                    <div className="text-xs text-stone-400">{CHARACTERS[p.characterId].name}</div>
                  </td>
                  {HOLES.map((h) => {
                    const score =
                      p.holeScores[h.index] ??
                      (h.index === currentHoleIndex ? p.currentHoleStrokes : null);
                    return (
                      <td key={h.index} className="py-2.5 px-2 text-center font-mono-tabular">
                        {score === null ? '—' : score}
                      </td>
                    );
                  })}
                  <td className="py-2.5 pl-3 text-right font-mono-tabular font-bold text-[#e5b84b]">
                    {p.totalStrokes}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

interface GameOverModalProps {
  players: PlayerMatchState[];
  isMultiplayer: boolean;
  isHost: boolean;
  onPlayAgain: () => void;
  onBackToTitle: () => void;
}

export function GameOverModal({
  players,
  isMultiplayer,
  isHost,
  onPlayAgain,
  onBackToTitle,
}: GameOverModalProps) {
  const totalPar = HOLES.reduce((sum, h) => sum + h.par, 0);
  const sorted = [...players].sort((a, b) => a.totalStrokes - b.totalStrokes);
  const winner = sorted[0];

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/75"
      role="dialog"
      aria-modal="true"
      aria-labelledby="gameover-title"
    >
      <div className="w-full max-w-lg rounded-2xl bg-[#102018] border border-[#e5b84b]/40 p-6 shadow-2xl text-stone-100">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#e5b84b]/20 text-[#e5b84b] mb-3">
            <Trophy className="w-6 h-6" aria-hidden="true" />
          </div>
          <h2 id="gameover-title" className="font-display text-2xl font-bold text-white">
            Turnuva Tamamlandı!
          </h2>
          {winner && (
            <p className="text-sm text-[#e5b84b] font-semibold mt-1">
              Kazanan: {winner.name} ({winner.totalStrokes} vuruş / Par {totalPar})
            </p>
          )}
        </div>

        <div className="mt-5 space-y-2">
          {sorted.map((p, rank) => {
            const diff = p.totalStrokes - totalPar;
            const diffLabel = diff === 0 ? 'E' : diff > 0 ? `+${diff}` : `${diff}`;
            return (
              <div
                key={p.id}
                className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-[#0b1510] border border-white/10"
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono-tabular text-sm font-bold text-stone-400">
                    #{rank + 1}
                  </span>
                  <div>
                    <div className="text-sm font-bold text-white">{p.name}</div>
                    <div className="text-xs text-stone-400">{CHARACTERS[p.characterId].name}</div>
                  </div>
                </div>
                <div className="font-mono-tabular text-right">
                  <span className="text-base font-bold text-white">{p.totalStrokes}</span>
                  <span className="text-xs text-stone-400 ml-2">({diffLabel})</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          {(!isMultiplayer || isHost) && (
            <button
              type="button"
              data-start="true"
              onClick={onPlayAgain}
              className="flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#e5b84b] hover:bg-[#f0c75e] text-[#0b1610] font-display font-bold text-base"
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              Tekrar Oyna
            </button>
          )}
          <button
            type="button"
            onClick={onBackToTitle}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-sm font-semibold"
          >
            <Home className="w-4 h-4" aria-hidden="true" />
            Ana Menü
          </button>
        </div>
      </div>
    </div>
  );
}
