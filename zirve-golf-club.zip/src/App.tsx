import { useCallback, useEffect, useRef, useState } from 'react';
import { CharacterModal } from './components/CharacterModal.tsx';
import { type CenterCallout, GameHud } from './components/GameHud.tsx';
import type { ActiveMapFlight, MiniMapShotRecord } from './components/MiniMap.tsx';
import { GameOverModal, PauseModal, ScorecardModal } from './components/Modals.tsx';
import { MultiplayerLobby } from './components/MultiplayerLobby.tsx';
import { TitleScreen } from './components/TitleScreen.tsx';
import { golfAudio } from './game/audio.ts';
import { CHARACTERS, CLUB_ORDER, PLAYER_COLORS, recommendClubForSituation } from './game/catalog.ts';
import {
  getHole,
  getHoleCupPos,
  getHoleStartTee,
  getInitialAimYaw,
  getSurfaceAt,
  HOLES,
} from './game/courses.ts';
import { estimateOptimalPowerRatio, simulateShotTrajectory } from './game/physics.ts';
import type {
  CameraMode,
  CharacterId,
  ClientWsMessage,
  ClubId,
  GameScreenState,
  PlayerMatchState,
  PublicRoomSummary,
  RoomState,
  ServerWsMessage,
} from './game/types.ts';
import { GolfSceneManager } from './three/GolfSceneManager.ts';

function createInitialSoloPlayer(characterId: CharacterId): PlayerMatchState {
  const hole = getHole(0);
  const tee = getHoleStartTee(hole);
  const cup = getHoleCupPos(hole);
  const char = CHARACTERS[characterId];
  const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);
  return {
    id: 'solo',
    name: 'Sen',
    characterId,
    color: PLAYER_COLORS[0],
    connected: true,
    ballPos: { ...tee },
    currentHoleStrokes: 0,
    holeScores: HOLES.map(() => null),
    totalStrokes: 0,
    holedOut: false,
    powerCharges: char.maxChargesPerMatch,
    activePower: false,
    selectedClub: recommendClubForSituation(dist, 'tee'),
    aimYaw: getInitialAimYaw(tee, cup),
  };
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<GolfSceneManager | null>(null);

  // Core Screen & Match State
  const [screenState, setScreenState] = useState<GameScreenState>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return 'playing';
    }
    return 'title';
  });

  const [selectedCharacterId, setSelectedCharacterId] = useState<CharacterId>('defne');
  const [soloPlayer, setSoloPlayer] = useState<PlayerMatchState>(() =>
    createInitialSoloPlayer('defne'),
  );
  const [soloHoleIndex, setSoloHoleIndex] = useState(0);
  const [soloWind, setSoloWind] = useState(() => ({ ...getHole(0).defaultWind }));

  // Local Aim / Club / Power Controls
  const [aimYaw, setAimYaw] = useState(() => {
    const h = getHole(0);
    return getInitialAimYaw(getHoleStartTee(h), getHoleCupPos(h));
  });
  const [selectedClub, setSelectedClub] = useState<ClubId>(() => {
    const h = getHole(0);
    const tee = getHoleStartTee(h);
    const cup = getHoleCupPos(h);
    const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);
    return recommendClubForSituation(dist, 'tee');
  });
  const [powerRatio, setPowerRatio] = useState(() => {
    const h = getHole(0);
    const tee = getHoleStartTee(h);
    const cup = getHoleCupPos(h);
    const yaw = getInitialAimYaw(tee, cup);
    const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);
    const club = recommendClubForSituation(dist, 'tee');
    return estimateOptimalPowerRatio({
      holeIndex: 0,
      startPos: tee,
      clubId: club,
      characterId: 'defne',
      aimYaw: yaw,
      wind: h.defaultWind,
      powerActive: false,
    });
  });
  const [isCharging, setIsCharging] = useState(false);
  const [powerActive, setPowerActive] = useState(false);
  const [cameraMode, setCameraMode] = useState<CameraMode>('aim');
  const [muted, setMuted] = useState(false);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [isFlightPlaying, setIsFlightPlaying] = useState(false);
  const [holeShotHistory, setHoleShotHistory] = useState<MiniMapShotRecord[]>([]);
  const [activeFlightMap, setActiveFlightMap] = useState<ActiveMapFlight | null>(null);
  const lastTrackedHoleRef = useRef(0);
  const shotSeqRef = useRef(1);
  const [lastEventText, setLastEventText] = useState('');
  const [centerCallout, setCenterCallout] = useState<CenterCallout | null>(null);
  const calloutTimerRef = useRef<number | null>(null);

  const showCallout = useCallback((callout: CenterCallout, durationMs = 2600) => {
    if (calloutTimerRef.current !== null) {
      clearTimeout(calloutTimerRef.current);
    }
    setCenterCallout(callout);
    calloutTimerRef.current = window.setTimeout(() => {
      setCenterCallout(null);
      calloutTimerRef.current = null;
    }, durationMs);
  }, []);

  // Modals
  const [showCharModal, setShowCharModal] = useState(false);
  const [showLobbyModal, setShowLobbyModal] = useState(false);
  const [showScorecard, setShowScorecard] = useState(false);

  // Online Multiplayer WebSocket State
  const wsRef = useRef<WebSocket | null>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const [playerName, setPlayerName] = useState('Golfçü');
  const [youId, setYouId] = useState<string | null>(null);
  const [publicRooms, setPublicRooms] = useState<PublicRoomSummary[]>([]);
  const [mpRoom, setMpRoom] = useState<RoomState | null>(null);
  const [mpError, setMpError] = useState<string | null>(null);
  const youIdRef = useRef<string | null>(null);
  youIdRef.current = youId;

  const isMultiplayer = mpRoom !== null && mpRoom.status !== 'waiting';
  const activeHoleIndex = isMultiplayer ? mpRoom.currentHoleIndex : soloHoleIndex;
  const activeWind = isMultiplayer ? mpRoom.wind : soloWind;
  const playersList = isMultiplayer ? mpRoom.players : [soloPlayer];
  const localPlayer =
    (isMultiplayer ? mpRoom.players.find((p) => p.id === youId) : soloPlayer) ?? soloPlayer;
  const activePlayer =
    (isMultiplayer
      ? mpRoom.players.find((p) => p.id === mpRoom.currentTurnPlayerId)
      : soloPlayer) ?? localPlayer;
  const isMyTurn = !isMultiplayer || mpRoom.currentTurnPlayerId === youId;

  // Keep body data-state synced & reset minimap shot history whenever hole index changes
  useEffect(() => {
    document.body.dataset.state = screenState;
  }, [screenState]);

  useEffect(() => {
    if (lastTrackedHoleRef.current !== activeHoleIndex) {
      lastTrackedHoleRef.current = activeHoleIndex;
      setHoleShotHistory([]);
      setActiveFlightMap(null);
    }
  }, [activeHoleIndex]);

  // Send WS helper
  const sendWs = useCallback((msg: ClientWsMessage) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(msg));
    }
  }, []);

  // Throttled aim sync in multiplayer
  const lastAimSentRef = useRef(0);
  const broadcastAim = useCallback(
    (nextYaw: number, nextClub: ClubId, nextPower: boolean) => {
      if (!mpRoom || mpRoom.status !== 'playing') return;
      const now = performance.now();
      if (now - lastAimSentRef.current < 110) return;
      lastAimSentRef.current = now;
      sendWs({
        type: 'player:aim',
        aimYaw: nextYaw,
        clubId: nextClub,
        activePower: nextPower,
      });
    },
    [mpRoom, sendWs],
  );

  // Ref callback for pointer-drag aiming from Three.js canvas without remounting WebGL
  const onAimDeltaRef = useRef<(deltaRad: number) => void>(() => {});
  onAimDeltaRef.current = (deltaRad: number) => {
    if (!isMyTurn || isFlightPlaying || showCharModal || showScorecard) return;
    setAimYaw((prev) => {
      const next = prev + deltaRad;
      broadcastAim(next, selectedClub, powerActive);
      return next;
    });
  };

  // Mount Three.js scene once
  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;
    const manager = new GolfSceneManager(container, (deltaRad) => onAimDeltaRef.current(deltaRad));
    sceneRef.current = manager;
    return () => {
      manager.dispose();
      sceneRef.current = null;
    };
  }, []);

  // Sync Three.js scene state whenever relevant HUD/player props change
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    scene.syncState({
      screenState,
      holeIndex: activeHoleIndex,
      wind: activeWind,
      cameraMode,
      players: playersList,
      activePlayerId: activePlayer.id,
      localPlayerId: localPlayer.id,
      previewClubId: selectedClub,
      previewAimYaw: aimYaw,
      previewPowerRatio: powerRatio,
      previewPowerActive: powerActive,
      isCharging,
    });
  }, [
    screenState,
    activeHoleIndex,
    activeWind,
    cameraMode,
    playersList,
    activePlayer.id,
    localPlayer.id,
    selectedClub,
    aimYaw,
    powerRatio,
    powerActive,
    isCharging,
  ]);

  // WebSocket Connection with auto-reconnect
  useEffect(() => {
    let closedByCleanup = false;
    let reconnectTimer = 0;

    const connect = () => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        setMpError(null);
        ws.send(JSON.stringify({ type: 'rooms:list' }));
      };

      ws.onmessage = (ev) => {
        let msg: ServerWsMessage;
        try {
          msg = JSON.parse(ev.data) as ServerWsMessage;
        } catch {
          return;
        }

        if (msg.type === 'welcome') {
          youIdRef.current = msg.clientId;
          setYouId(msg.clientId);
        } else if (msg.type === 'rooms:listed') {
          setPublicRooms(msg.rooms);
        } else if (msg.type === 'room:joined') {
          youIdRef.current = msg.youId;
          setMpRoom(msg.room);
          setYouId(msg.youId);
          setMpError(null);
        } else if (msg.type === 'room:left') {
          setMpRoom(null);
          setScreenState('title');
        } else if (msg.type === 'error') {
          setMpError(msg.message);
        } else if (msg.type === 'player:aimed') {
          setMpRoom((prev) => {
            if (!prev) return prev;
            return {
              ...prev,
              players: prev.players.map((p) =>
                p.id === msg.playerId
                  ? {
                      ...p,
                      aimYaw: msg.aimYaw,
                      selectedClub: msg.clubId,
                      activePower: msg.activePower,
                    }
                  : p,
              ),
            };
          });
        } else if (msg.type === 'room:state') {
          setMpRoom(msg.room);
          setLastEventText(msg.room.lastEventText);
          if (msg.room.status === 'playing') {
            setShowLobbyModal(false);
            setShowCharModal(false);
            setScreenState('playing');
            const me = msg.room.players.find((p) => p.id === youIdRef.current);
            if (me) {
              setAimYaw(me.aimYaw);
              setSelectedClub(me.selectedClub);
              setPowerActive(false);
              setPowerRatio(
                estimateOptimalPowerRatio({
                  holeIndex: msg.room.currentHoleIndex,
                  startPos: me.ballPos,
                  clubId: me.selectedClub,
                  characterId: me.characterId,
                  aimYaw: me.aimYaw,
                  wind: msg.room.wind,
                  powerActive: false,
                }),
              );
            }
          } else if (msg.room.status === 'finished') {
            setScreenState('gameover');
          }
        } else if (msg.type === 'shot:executed') {
          setIsFlightPlaying(true);
          setActiveFlightMap({
            points: msg.simulation.points,
            startTimeMs: performance.now(),
            durationSec: msg.simulation.durationSec,
            hitWater: msg.simulation.hitWater,
          });
          golfAudio.playSwing(msg.clubId, 0.8);
          setLastEventText(msg.room.lastEventText);

          const finishCommit = () => {
            setIsFlightPlaying(false);
            setActiveFlightMap(null);
            const impactPos = msg.simulation.hitWater
              ? (msg.simulation.points[msg.simulation.points.length - 1] ?? msg.simulation.finalPos)
              : msg.simulation.finalPos;
            const shooterObj = msg.room.players.find((p) => p.id === msg.playerId);
            setHoleShotHistory((prev) => [
              ...prev,
              {
                id: shotSeqRef.current++,
                points: msg.simulation.points,
                landedPos: impactPos,
                hitWater: msg.simulation.hitWater,
                sunk: msg.simulation.sunk,
                playerColor: shooterObj?.color ?? '#fde047',
              },
            ]);
            if (msg.simulation.hitWater) {
              showCallout({ title: 'Suya Düştü!', subtitle: '+1 Ceza Vuruşu', tone: 'red' }, 2100);
            } else if (msg.simulation.sunk) {
              const shooter = msg.room.players.find((p) => p.id === msg.playerId);
              showCallout(
                {
                  title: 'Delikte!',
                  subtitle: shooter ? `${shooter.name} deliğe soktu` : 'Harika vuruş!',
                  tone: 'gold',
                },
                2200,
              );
            }
            setMpRoom(msg.room);
            if (msg.room.status === 'finished') {
              setScreenState('gameover');
            } else {
              setScreenState('playing');
              const me = msg.room.players.find((p) => p.id === youIdRef.current);
              if (me) {
                setAimYaw(me.aimYaw);
                setSelectedClub(me.selectedClub);
                setPowerActive(false);
                setPowerRatio(
                  estimateOptimalPowerRatio({
                    holeIndex: msg.room.currentHoleIndex,
                    startPos: me.ballPos,
                    clubId: me.selectedClub,
                    characterId: me.characterId,
                    aimYaw: me.aimYaw,
                    wind: msg.room.wind,
                    powerActive: false,
                  }),
                );
              }
            }
          };

          if (sceneRef.current) {
            sceneRef.current.playShotFlight(
              msg.playerId,
              msg.clubId,
              msg.powerActive,
              msg.simulation,
              finishCommit,
            );
          } else {
            finishCommit();
          }
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!closedByCleanup) {
          reconnectTimer = window.setTimeout(connect, 2200);
        }
      };
    };

    connect();
    return () => {
      closedByCleanup = true;
      clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, []);

  // Start Solo Match
  const startSoloGame = useCallback(
    (charIdOverride?: CharacterId) => {
      const charToUse = charIdOverride ?? selectedCharacterId;
      const hole = getHole(0);
      const tee = getHoleStartTee(hole);
      const cup = getHoleCupPos(hole);
      const initYaw = getInitialAimYaw(tee, cup);
      const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);

      const recClub = recommendClubForSituation(dist, 'tee');
      const optPower = estimateOptimalPowerRatio({
        holeIndex: 0,
        startPos: tee,
        clubId: recClub,
        characterId: charToUse,
        aimYaw: initYaw,
        wind: hole.defaultWind,
        powerActive: false,
      });

      setMpRoom(null);
      setSoloHoleIndex(0);
      setSoloWind({ ...hole.defaultWind });
      setSoloPlayer(createInitialSoloPlayer(charToUse));
      setAimYaw(initYaw);
      setSelectedClub(recClub);
      setPowerRatio(optPower);
      setPowerActive(false);
      setIsCharging(false);
      setIsFlightPlaying(false);
      setHoleShotHistory([]);
      setActiveFlightMap(null);
      setLastEventText(`Delik 1: ${hole.name} — Nişan al ve vur!`);
      setShowLobbyModal(false);
      setShowCharModal(false);
      setShowScorecard(false);
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      document.body.dataset.state = 'playing';
      setScreenState('playing');
    },
    [selectedCharacterId],
  );

  const handleSelectClubWithAssist = useCallback(
    (nextClub: ClubId) => {
      golfAudio.playUiClick();
      setSelectedClub(nextClub);
      const optPower = estimateOptimalPowerRatio({
        holeIndex: activeHoleIndex,
        startPos: localPlayer.ballPos,
        clubId: nextClub,
        characterId: localPlayer.characterId,
        aimYaw,
        wind: activeWind,
        powerActive,
      });
      setPowerRatio(optPower);
      broadcastAim(aimYaw, nextClub, powerActive);
    },
    [
      activeHoleIndex,
      activeWind,
      aimYaw,
      broadcastAim,
      localPlayer.ballPos,
      localPlayer.characterId,
      powerActive,
    ],
  );

  // Switch Character (only allowed in Menu or Waiting Lobby, never during a match)
  const handleSelectCharacter = useCallback(
    (cid: CharacterId) => {
      if (screenState !== 'title') return;
      if (mpRoom && mpRoom.status !== 'waiting') return;
      golfAudio.playUiClick();
      setSelectedCharacterId(cid);
      setPowerActive(false);
      setSoloPlayer((prev) => ({
        ...prev,
        characterId: cid,
        powerCharges: CHARACTERS[cid].maxChargesPerMatch,
      }));
      if (mpRoom) {
        sendWs({ type: 'room:character', characterId: cid });
      }
      setLastEventText(`Karakter değiştirildi: ${CHARACTERS[cid].name}`);
    },
    [mpRoom, screenState, sendWs],
  );

  // Execute Shot (Solo or Multiplayer)
  const executeShot = useCallback(
    (ratioToUse: number) => {
      if (screenState !== 'playing' || isFlightPlaying || !isMyTurn || localPlayer.holedOut) {
        return;
      }
      const clampedRatio = Math.max(0.1, Math.min(1, ratioToUse));
      const usePower = powerActive && localPlayer.powerCharges > 0;
      setIsCharging(false);

      if (isMultiplayer) {
        sendWs({
          type: 'player:shot',
          clubId: selectedClub,
          powerRatio: clampedRatio,
          aimYaw,
          usePower,
        });
        return;
      }

      // Solo shot execution
      const sim = simulateShotTrajectory({
        holeIndex: soloHoleIndex,
        startPos: soloPlayer.ballPos,
        clubId: selectedClub,
        characterId: soloPlayer.characterId,
        powerRatio: clampedRatio,
        aimYaw,
        wind: soloWind,
        powerActive: usePower,
      });

      setIsFlightPlaying(true);
      setActiveFlightMap({
        points: sim.points,
        startTimeMs: performance.now(),
        durationSec: sim.durationSec,
        hitWater: sim.hitWater,
      });
      golfAudio.playSwing(selectedClub, clampedRatio);
      setLastEventText(
        `Çıkış hızı: ${sim.launchSpeedKmh} km/s · Mesafe: ${sim.totalDistanceM}m`,
      );

      const commitSoloResult = () => {
        setIsFlightPlaying(false);
        setActiveFlightMap(null);
        setPowerActive(false);

        const impactPos = sim.hitWater
          ? (sim.points[sim.points.length - 1] ?? sim.finalPos)
          : sim.finalPos;
        setHoleShotHistory((prev) => [
          ...prev,
          {
            id: shotSeqRef.current++,
            points: sim.points,
            landedPos: impactPos,
            hitWater: sim.hitWater,
            sunk: sim.sunk,
            playerColor: soloPlayer.color,
          },
        ]);

        const hole = getHole(soloHoleIndex);
        const cup = getHoleCupPos(hole);
        const newStrokes = soloPlayer.currentHoleStrokes + 1 + sim.penaltyStrokes;
        const nextCharges = usePower
          ? Math.max(0, soloPlayer.powerCharges - 1)
          : soloPlayer.powerCharges;

        if (sim.sunk) {
          const diff = newStrokes - hole.par;
          const calloutTitle =
            newStrokes === 1
              ? 'Hole-in-One!'
              : diff <= -2
                ? 'Eagle!'
                : diff === -1
                  ? 'Birdie!'
                  : diff === 0
                    ? 'Par'
                    : diff === 1
                      ? 'Bogey'
                      : `+${diff}`;
          const calloutSub =
            diff === 0 ? 'Eşit (E)' : diff < 0 ? `${diff} vuruş` : `+${diff} vuruş`;
          showCallout({
            title: calloutTitle,
            subtitle: calloutSub,
            tone: diff <= 0 ? 'gold' : 'cyan',
          });

          const updatedScores = [...soloPlayer.holeScores];
          updatedScores[soloHoleIndex] = newStrokes;
          const newTotal = updatedScores.reduce<number>((sum, v) => sum + (v ?? 0), 0);

          const nextHoleIdx = soloHoleIndex + 1;
          if (nextHoleIdx >= HOLES.length) {
            setSoloPlayer({
              ...soloPlayer,
              ballPos: { ...sim.finalPos },
              currentHoleStrokes: newStrokes,
              holeScores: updatedScores,
              totalStrokes: newTotal,
              holedOut: true,
              powerCharges: nextCharges,
            });
            setLastEventText(`Delik tamamlandı! (${newStrokes} vuruş)`);
            setScreenState('gameover');
          } else {
            const nextHole = getHole(nextHoleIdx);
            const nextTee = getHoleStartTee(nextHole);
            const nextCup = getHoleCupPos(nextHole);
            const dist = Math.hypot(nextCup.x - nextTee.x, nextCup.z - nextTee.z);
            const nextYaw = getInitialAimYaw(nextTee, nextCup);
            const nextClub = recommendClubForSituation(dist, 'tee');
            const optPower = estimateOptimalPowerRatio({
              holeIndex: nextHoleIdx,
              startPos: nextTee,
              clubId: nextClub,
              characterId: soloPlayer.characterId,
              aimYaw: nextYaw,
              wind: nextHole.defaultWind,
              powerActive: false,
            });
            setSoloHoleIndex(nextHoleIdx);
            setSoloWind({ ...nextHole.defaultWind });
            setSoloPlayer({
              ...soloPlayer,
              ballPos: { ...nextTee },
              currentHoleStrokes: 0,
              holeScores: updatedScores,
              totalStrokes: newTotal,
              holedOut: false,
              powerCharges: nextCharges,
            });
            setAimYaw(nextYaw);
            setSelectedClub(nextClub);
            setPowerRatio(optPower);
            setLastEventText(
              `Delik ${soloHoleIndex + 1} tamam (${newStrokes} vuruş)! Şimdi Delik ${nextHoleIdx + 1}: ${nextHole.name}`,
            );
          }
        } else {
          const dist = Math.hypot(cup.x - sim.finalPos.x, cup.z - sim.finalPos.z);
          const surf = getSurfaceAt(hole, sim.finalPos.x, sim.finalPos.z);
          const nextYaw = getInitialAimYaw(sim.finalPos, cup);
          const recClub = recommendClubForSituation(dist, surf);
          const optPower = estimateOptimalPowerRatio({
            holeIndex: soloHoleIndex,
            startPos: sim.finalPos,
            clubId: recClub,
            characterId: soloPlayer.characterId,
            aimYaw: nextYaw,
            wind: soloWind,
            powerActive: false,
          });

          setSoloPlayer({
            ...soloPlayer,
            ballPos: { ...sim.finalPos },
            currentHoleStrokes: newStrokes,
            powerCharges: nextCharges,
          });
          setAimYaw(nextYaw);
          setSelectedClub(recClub);
          setPowerRatio(optPower);
          if (sim.hitWater) {
            showCallout({ title: 'Suya Düştü!', subtitle: '+1 Ceza Vuruşu', tone: 'red' }, 2200);
            setLastEventText('Top suya düştü! (+1 ceza vuruşu)');
          } else if (sim.hitBunker) {
            showCallout({ title: 'Kum Tuzağı', subtitle: `${Math.round(dist)} m kaldı`, tone: 'gold' }, 1800);
            setLastEventText(`Kum tuzağına düştü! Kalan mesafe: ${Math.round(dist)}m`);
          } else {
            if (dist < 16 && surf === 'green') {
              showCallout({ title: 'Harika Yaklaşım!', subtitle: `${Math.round(dist)} m kaldı`, tone: 'emerald' }, 1700);
            }
            setLastEventText(`${sim.totalDistanceM}m ilerledi · Kalan: ${Math.round(dist)}m`);
          }
        }
      };

      if (sceneRef.current) {
        sceneRef.current.playShotFlight(
          soloPlayer.id,
          selectedClub,
          usePower,
          sim,
          commitSoloResult,
        );
      } else {
        commitSoloResult();
      }
    },
    [
      aimYaw,
      isFlightPlaying,
      isMultiplayer,
      isMyTurn,
      localPlayer.holedOut,
      localPlayer.powerCharges,
      powerActive,
      screenState,
      selectedClub,
      sendWs,
      soloHoleIndex,
      soloPlayer,
      soloWind,
    ],
  );

  // Power charging oscillation loop while holding Space
  const chargeDirRef = useRef(1);
  const powerRatioRef = useRef(powerRatio);
  powerRatioRef.current = powerRatio;

  useEffect(() => {
    if (!isCharging) return;
    let raf = 0;
    let last = performance.now();
    const step = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      let next = powerRatioRef.current + chargeDirRef.current * dt * 0.92;
      if (next >= 1) {
        next = 1;
        chargeDirRef.current = -1;
      } else if (next <= 0.12) {
        next = 0.12;
        chargeDirRef.current = 1;
      }
      powerRatioRef.current = next;
      setPowerRatio(next);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [isCharging]);

  // Continuous A/D aim rotation & edge-triggered shortcuts
  const keysHeldRef = useRef(new Set<string>());

  useEffect(() => {
    if (screenState !== 'playing') {
      keysHeldRef.current.clear();
      return;
    }
    let raf = 0;
    let last = performance.now();
    const step = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      const held = keysHeldRef.current;
      let delta = 0;
      if (held.has('KeyA') || held.has('ArrowLeft')) delta += dt * 0.95;
      if (held.has('KeyD') || held.has('ArrowRight')) delta -= dt * 0.95;
      if (delta !== 0 && isMyTurn && !isFlightPlaying && !showCharModal && !showScorecard) {
        setAimYaw((prev) => {
          const next = prev + delta;
          broadcastAim(next, selectedClub, powerActive);
          return next;
        });
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [
    broadcastAim,
    isFlightPlaying,
    isMyTurn,
    powerActive,
    screenState,
    selectedClub,
    showCharModal,
    showScorecard,
  ]);

  const spaceDownActiveRef = useRef(false);
  const spaceHoldTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }

      if (screenState === 'title') {
        if (!showCharModal && !showLobbyModal && (e.code === 'Enter' || e.code === 'Space')) {
          e.preventDefault();
          startSoloGame();
        }
        return;
      }

      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (showCharModal) {
          setShowCharModal(false);
          return;
        }
        if (showScorecard) {
          setShowScorecard(false);
          return;
        }
        if (screenState === 'playing') {
          setScreenState('paused');
        } else if (screenState === 'paused') {
          setScreenState('playing');
        }
        return;
      }

      if (screenState !== 'playing') return;

      keysHeldRef.current.add(e.code);

      if (e.repeat) return;

      // Club hotkeys 1-4
      const clubIdx = ['Digit1', 'Digit2', 'Digit3', 'Digit4'].indexOf(e.code);
      if (clubIdx !== -1 && isMyTurn && !isFlightPlaying) {
        handleSelectClubWithAssist(CLUB_ORDER[clubIdx]);
      } else if (e.code === 'KeyQ' && isMyTurn && !isFlightPlaying) {
        if (localPlayer.powerCharges > 0) {
          setPowerActive((prev) => {
            const next = !prev;
            if (next) golfAudio.playPowerActivate();
            broadcastAim(aimYaw, selectedClub, next);
            return next;
          });
        }
      } else if (e.code === 'KeyC') {
        setCameraMode((prev) =>
          prev === 'aim' ? 'follow' : prev === 'follow' ? 'overhead' : 'aim',
        );
      } else if (e.code === 'KeyM') {
        setMuted(golfAudio.toggleMute());
      } else if (e.code === 'KeyH') {
        setDockCollapsed((prev) => !prev);
      } else if (e.code === 'Space' && isMyTurn && !isFlightPlaying && !showCharModal) {
        e.preventDefault();
        // Quick tap (<180ms) shoots at exact current powerRatio; holding oscillates power smoothly
        spaceDownActiveRef.current = true;
        if (spaceHoldTimerRef.current !== null) {
          clearTimeout(spaceHoldTimerRef.current);
        }
        spaceHoldTimerRef.current = window.setTimeout(() => {
          if (spaceDownActiveRef.current) {
            chargeDirRef.current = 1;
            setIsCharging(true);
          }
        }, 180);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysHeldRef.current.delete(e.code);
      if (e.code === 'Space' && spaceDownActiveRef.current) {
        e.preventDefault();
        spaceDownActiveRef.current = false;
        if (spaceHoldTimerRef.current !== null) {
          clearTimeout(spaceHoldTimerRef.current);
          spaceHoldTimerRef.current = null;
        }
        executeShot(powerRatioRef.current);
      }
    };

    const onBlur = () => {
      keysHeldRef.current.clear();
      spaceDownActiveRef.current = false;
      if (spaceHoldTimerRef.current !== null) {
        clearTimeout(spaceHoldTimerRef.current);
        spaceHoldTimerRef.current = null;
      }
      setIsCharging(false);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      if (spaceHoldTimerRef.current !== null) {
        clearTimeout(spaceHoldTimerRef.current);
      }
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [
    aimYaw,
    broadcastAim,
    executeShot,
    handleSelectClubWithAssist,
    isFlightPlaying,
    isMyTurn,
    localPlayer.powerCharges,
    powerActive,
    screenState,
    selectedClub,
    showCharModal,
    showLobbyModal,
    showScorecard,
    startSoloGame,
  ]);

  const currentHole = getHole(activeHoleIndex);
  const cupPos = getHoleCupPos(currentHole);
  const distanceToCupM = Math.max(
    0,
    Math.round(
      Math.hypot(cupPos.x - localPlayer.ballPos.x, cupPos.z - localPlayer.ballPos.z),
    ),
  );
  const currentSurface = getSurfaceAt(
    currentHole,
    localPlayer.ballPos.x,
    localPlayer.ballPos.z,
  );

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0e1b14]">
      {/* Isolated Three.js Canvas Mount */}
      <div
        ref={canvasMountRef}
        data-testid="golf-canvas-container"
        className="absolute inset-0 w-full h-full"
      />

      {/* Title Screen */}
      {screenState === 'title' && (
        <TitleScreen
          selectedCharacterId={selectedCharacterId}
          onStartSolo={() => startSoloGame()}
          onOpenMultiplayer={() => {
            golfAudio.playUiClick();
            sendWs({ type: 'rooms:list' });
            setShowLobbyModal(true);
          }}
          onOpenCharacterSelect={() => {
            golfAudio.playUiClick();
            setShowCharModal(true);
          }}
        />
      )}

      {/* Playing HUD */}
      {screenState === 'playing' && (
        <GameHud
          hole={currentHole}
          totalHoles={HOLES.length}
          wind={activeWind}
          distanceToCupM={distanceToCupM}
          currentSurface={currentSurface}
          isMultiplayer={isMultiplayer}
          roomCode={mpRoom?.code ?? null}
          players={playersList}
          activePlayer={activePlayer}
          localPlayer={localPlayer}
          isMyTurn={isMyTurn}
          isFlightPlaying={isFlightPlaying}
          selectedClub={selectedClub}
          aimYaw={aimYaw}
          powerRatio={powerRatio}
          isCharging={isCharging}
          powerActive={powerActive}
          cameraMode={cameraMode}
          muted={muted}
          dockCollapsed={dockCollapsed}
          lastEventText={lastEventText}
          centerCallout={centerCallout}
          shotHistory={holeShotHistory}
          activeShot={activeFlightMap}
          onSelectClub={handleSelectClubWithAssist}
          onAdjustAim={(delta) => {
            setAimYaw((prev) => {
              const next = prev + delta;
              broadcastAim(next, selectedClub, powerActive);
              return next;
            });
          }}
          onPowerRatioChange={(r) => setPowerRatio(r)}
          onShootNow={() => executeShot(powerRatio)}
          onTogglePower={() => {
            if (localPlayer.powerCharges <= 0) return;
            setPowerActive((prev) => {
              const next = !prev;
              if (next) golfAudio.playPowerActivate();
              broadcastAim(aimYaw, selectedClub, next);
              return next;
            });
          }}
          onCycleCamera={() => {
            golfAudio.playUiClick();
            setCameraMode((prev) =>
              prev === 'aim' ? 'follow' : prev === 'follow' ? 'overhead' : 'aim',
            );
          }}
          onToggleMute={() => setMuted(golfAudio.toggleMute())}
          onOpenScorecard={() => {
            golfAudio.playUiClick();
            setShowScorecard(true);
          }}
          onPause={() => setScreenState('paused')}
          onToggleDock={() => setDockCollapsed((prev) => !prev)}
        />
      )}

      {/* Pause Modal */}
      {screenState === 'paused' && (
        <PauseModal
          onResume={() => setScreenState('playing')}
          onResetHole={() => {
            if (isMultiplayer) {
              setScreenState('playing');
            } else {
              const h = getHole(soloHoleIndex);
              const tee = getHoleStartTee(h);
              const cup = getHoleCupPos(h);
              const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);
              setSoloPlayer((prev) => ({
                ...prev,
                ballPos: { ...tee },
                currentHoleStrokes: 0,
              }));
              setHoleShotHistory([]);
              setActiveFlightMap(null);
              setAimYaw(getInitialAimYaw(tee, cup));
              setSelectedClub(recommendClubForSituation(dist, 'tee'));
              setPowerActive(false);
              setScreenState('playing');
            }
          }}
          onBackToTitle={() => {
            if (mpRoom) {
              sendWs({ type: 'room:leave' });
              setMpRoom(null);
            }
            setScreenState('title');
          }}
        />
      )}

      {/* Scorecard Modal */}
      {showScorecard && (
        <ScorecardModal
          players={playersList}
          currentHoleIndex={activeHoleIndex}
          onClose={() => setShowScorecard(false)}
        />
      )}

      {/* Game Over / Match Victory Modal */}
      {screenState === 'gameover' && (
        <GameOverModal
          players={playersList}
          isMultiplayer={isMultiplayer}
          isHost={mpRoom?.hostId === youId}
          onPlayAgain={() => {
            if (isMultiplayer) {
              sendWs({ type: 'room:rematch' });
            } else {
              startSoloGame();
            }
          }}
          onBackToTitle={() => {
            if (mpRoom) {
              sendWs({ type: 'room:leave' });
              setMpRoom(null);
            }
            setScreenState('title');
          }}
        />
      )}

      {/* Character Selector Modal (only in Menu or Waiting Lobby) */}
      {showCharModal && screenState === 'title' && (!mpRoom || mpRoom.status === 'waiting') && (
        <CharacterModal
          selectedId={selectedCharacterId}
          onSelect={handleSelectCharacter}
          onClose={() => setShowCharModal(false)}
        />
      )}

      {/* Online Multiplayer Lobby Modal */}
      {showLobbyModal && (
        <MultiplayerLobby
          connected={wsConnected}
          playerName={playerName}
          onChangePlayerName={setPlayerName}
          selectedCharacterId={selectedCharacterId}
          onOpenCharacterSelect={() => setShowCharModal(true)}
          publicRooms={publicRooms}
          currentRoom={mpRoom}
          youId={youId}
          errorMsg={mpError}
          onRefreshRooms={() => sendWs({ type: 'rooms:list' })}
          onCreateRoom={(customCode, isPrivate) =>
            sendWs({
              type: 'room:create',
              playerName,
              characterId: selectedCharacterId,
              customCode,
              isPrivate,
            })
          }
          onJoinRoom={(code) =>
            sendWs({
              type: 'room:join',
              code,
              playerName,
              characterId: selectedCharacterId,
            })
          }
          onAddBot={() => sendWs({ type: 'room:add_bot' })}
          onRemoveBot={(botId) => sendWs({ type: 'room:remove_bot', botId })}
          onLeaveRoom={() => {
            sendWs({ type: 'room:leave' });
            setMpRoom(null);
          }}
          onStartMatch={() => sendWs({ type: 'room:start' })}
          onClose={() => setShowLobbyModal(false)}
        />
      )}
    </div>
  );
}
