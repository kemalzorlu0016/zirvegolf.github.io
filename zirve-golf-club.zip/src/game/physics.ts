import { CHARACTERS, GOLF_CLUBS } from './catalog.ts';
import {
  getCourseObstacles,
  getElevationAt,
  getGroundNormalAt,
  getHole,
  getHoleCupPos,
  getSurfaceAt,
} from './courses.ts';
import type {
  CharacterId,
  ClubId,
  ObstacleHitInfo,
  ShotInput,
  ShotSimulationResult,
  SurfaceType,
  Vec3,
} from './types.ts';

export const CUP_RADIUS = 0.56; // Friendly sports-arcade cup radius for satisfying putts
export const MAX_CUP_CAPTURE_SPEED = 6.8;
const GRAVITY = 9.81;

export function computeLaunchParameters(input: ShotInput): {
  speedMs: number;
  speedKmh: number;
  loftRad: number;
  windFactor: number;
  velocity: Vec3;
} {
  const club = GOLF_CLUBS[input.clubId];
  const char = CHARACTERS[input.characterId];
  const hole = getHole(input.holeIndex);
  const surface = getSurfaceAt(hole, input.startPos.x, input.startPos.z);

  const clampedPower = Math.max(0.08, Math.min(1, input.powerRatio));
  let baseSpeed = club.minSpeed + (club.maxSpeed - club.minSpeed) * clampedPower;

  // Apply character power multiplier
  baseSpeed *= char.powerMultiplier;

  // Apply surface lie penalty (bunkers & rough slow down non-wedge clubs)
  if (surface === 'bunker') {
    baseSpeed *= club.sandPenalty;
  } else if (surface === 'rough') {
    baseSpeed *= club.roughPenalty;
  }

  // Apply active character special power
  let windFactor = 1 - char.windResistance;
  if (input.powerActive) {
    if (char.specialPowerId === 'super_drive') {
      baseSpeed *= 1.28;
      windFactor *= 0.5;
    } else if (char.specialPowerId === 'wind_shield') {
      windFactor = 0;
      baseSpeed *= 1.07; // extra carry glide
    } else if (char.specialPowerId === 'laser_aim') {
      windFactor *= 0.75;
    }
  }

  const loftRad = (club.loftDeg * Math.PI) / 180;
  const horizSpeed = baseSpeed * Math.cos(loftRad);
  const vertSpeed = baseSpeed * Math.sin(loftRad);

  const vx = Math.sin(input.aimYaw) * horizSpeed;
  const vz = Math.cos(input.aimYaw) * horizSpeed;

  return {
    speedMs: baseSpeed,
    speedKmh: Math.round(baseSpeed * 3.6),
    loftRad,
    windFactor,
    velocity: { x: vx, y: vertSpeed, z: vz },
  };
}

export function simulateShotTrajectory(input: ShotInput): ShotSimulationResult {
  const hole = getHole(input.holeIndex);
  const club = GOLF_CLUBS[input.clubId];
  const char = CHARACTERS[input.characterId];
  const cup = getHoleCupPos(hole);
  const obstacles = getCourseObstacles(hole);

  const safeStartY = getElevationAt(hole, input.startPos.x, input.startPos.z) + 0.06;
  const safeStart: Vec3 = { x: input.startPos.x, y: safeStartY, z: input.startPos.z };

  const launch = computeLaunchParameters(input);

  let px = safeStart.x;
  let py = safeStart.y;
  let pz = safeStart.z;
  let vx = launch.velocity.x;
  let vy = launch.velocity.y;
  let vz = launch.velocity.z;

  const BALL_RADIUS = 0.14;
  const dt = 1 / 120; // 120Hz sub-stepping prevents tunneling through blocks, trunks, rocks & terrain
  const sampleEvery = 4; // 30Hz trajectory snapshots
  const maxSteps = 120 * 14; // max 14s shot

  const points: Vec3[] = [{ x: px, y: py, z: pz }];
  const bounces: number[] = [];
  const obstacleHits: ObstacleHitInfo[] = [];
  let lastObstacleHitTime = -1;

  let firstLandingPos: Vec3 | null = null;
  let hitWater = false;
  let hitBunker = false;
  let sunk = false;
  let restCounter = 0;
  let step = 0;

  while (step < maxSteps) {
    step++;
    const timeSec = step * dt;
    const groundY = getElevationAt(hole, px, pz);
    const airborne = py > groundY + 0.08 || vy > 0.35;

    if (airborne) {
      // Air drag + subtle Magnus backspin lift (keeps drivers airborne for realistic carry) + wind
      const drag = club.spinDrag;
      vx -= vx * drag * dt;
      vz -= vz * drag * dt;
      vx += input.wind.x * 0.42 * launch.windFactor * dt;
      vz += input.wind.z * 0.42 * launch.windFactor * dt;
      const horizSpeedNow = Math.hypot(vx, vz);
      const liftRatio = club.id === 'driver' ? 0.055 : club.id === 'iron' ? 0.03 : 0.012;
      const liftAccel = Math.min(GRAVITY * 0.32, horizSpeedNow * liftRatio);
      vy -= (GRAVITY - liftAccel) * dt;
    } else {
      // Ground rolling physics with slope normal
      const surf = getSurfaceAt(hole, px, pz);
      const normal = getGroundNormalAt(hole, px, pz);

      // Gravity along ground slope
      vx += normal.x * GRAVITY * 0.72 * dt;
      vz += normal.z * GRAVITY * 0.72 * dt;

      // Surface rolling friction
      let friction = 3.8;
      if (surf === 'green') friction = 1.65 / char.greenTouch;
      else if (surf === 'fairway' || surf === 'tee') friction = 4.2;
      else if (surf === 'rough') friction = 8.5;
      else if (surf === 'bunker') friction = 14.0;

      // Ece's Cup Magnet active power
      if (input.powerActive && char.specialPowerId === 'cup_magnet' && surf === 'green') {
        friction *= 0.84;
        const toCupX = cup.x - px;
        const toCupZ = cup.z - pz;
        const dCup = Math.hypot(toCupX, toCupZ);
        if (dCup < 4.5 && dCup > 0.05) {
          const pull = (1 - dCup / 4.5) * 9.5;
          vx += (toCupX / dCup) * pull * dt;
          vz += (toCupZ / dCup) * pull * dt;
        }
      }

      const speedHoriz = Math.hypot(vx, vz);
      if (speedHoriz > 0.0001) {
        const drop = friction * dt;
        const newSpeed = Math.max(0, speedHoriz - drop);
        const ratio = newSpeed / speedHoriz;
        vx *= ratio;
        vz *= ratio;
      }
      vy = 0;
      py = groundY + 0.06;
    }

    px += vx * dt;
    py += vy * dt;
    pz += vz * dt;

    // 3D Solid Block & Obstacle Collision (trees, rocks, resort pavilions, tee fences)
    for (let oi = 0; oi < obstacles.length; oi++) {
      const obs = obstacles[oi];
      if (py + BALL_RADIUS < obs.yMin || py - BALL_RADIUS > obs.yMax) continue;
      if (Math.abs(px - obs.x) > obs.radius + BALL_RADIUS) continue;
      if (Math.abs(pz - obs.z) > obs.radius + BALL_RADIUS) continue;

      let nx = 0;
      let ny = 0;
      let nz = 0;
      let hit = false;
      let pushDist = 0;

      if (obs.shape === 'cylinder' || obs.shape === 'cone') {
        const hFrac = Math.max(
          0,
          Math.min(1, (py - obs.yMin) / Math.max(0.01, obs.yMax - obs.yMin)),
        );
        const effR =
          obs.shape === 'cone'
            ? obs.radius * (1 - hFrac) + (obs.topRadius ?? obs.radius * 0.2) * hFrac
            : obs.radius;
        const dx = px - obs.x;
        const dz = pz - obs.z;
        const dist = Math.hypot(dx, dz);
        const minR = effR + BALL_RADIUS;
        if (dist < minR) {
          hit = true;
          if (dist > 1e-4) {
            nx = dx / dist;
            nz = dz / dist;
          } else {
            nx = 1;
            nz = 0;
          }
          pushDist = minR - dist;
        }
      } else if (obs.shape === 'sphere') {
        const yCenter = (obs.yMin + obs.yMax) * 0.5;
        const dx = px - obs.x;
        const dy = py - yCenter;
        const dz = pz - obs.z;
        const dist = Math.hypot(dx, dy, dz);
        const minR = obs.radius + BALL_RADIUS;
        if (dist < minR) {
          hit = true;
          if (dist > 1e-4) {
            nx = dx / dist;
            ny = dy / dist;
            nz = dz / dist;
          } else {
            nx = 0;
            ny = 1;
            nz = 0;
          }
          pushDist = minR - dist;
        }
      } else if (obs.shape === 'box') {
        const hx = obs.halfX ?? obs.radius * 0.7;
        const hz = obs.halfZ ?? obs.radius * 0.7;
        const cx = Math.max(obs.x - hx, Math.min(obs.x + hx, px));
        const cz = Math.max(obs.z - hz, Math.min(obs.z + hz, pz));
        const dx = px - cx;
        const dz = pz - cz;
        const dist = Math.hypot(dx, dz);
        if (dist < BALL_RADIUS) {
          hit = true;
          if (dist > 1e-4) {
            nx = dx / dist;
            nz = dz / dist;
            pushDist = BALL_RADIUS - dist;
          } else {
            // Inside box XZ footprint: push out nearest side or top roof
            const penX = hx - Math.abs(px - obs.x);
            const penZ = hz - Math.abs(pz - obs.z);
            const penTop = obs.yMax - py;
            if (penTop < penX && penTop < penZ && penTop >= 0) {
              ny = 1;
              pushDist = penTop + BALL_RADIUS;
            } else if (penX < penZ) {
              nx = px >= obs.x ? 1 : -1;
              pushDist = penX + BALL_RADIUS;
            } else {
              nz = pz >= obs.z ? 1 : -1;
              pushDist = penZ + BALL_RADIUS;
            }
          }
        }
      }

      if (hit) {
        px += nx * pushDist;
        py += ny * pushDist;
        pz += nz * pushDist;

        const vn = vx * nx + vy * ny + vz * nz;
        if (vn < 0) {
          if (obs.kind === 'foliage') {
            // Tree leaves absorb speed and drop the ball cleanly down out of canopy
            vx = (vx - 1.25 * vn * nx) * 0.45;
            vz = (vz - 1.25 * vn * nz) * 0.45;
            vy = Math.min(vy * 0.35, -1.4);
          } else {
            // Solid rock, tree trunk, or tent/fence frame deflects cleanly
            const factor = 1 + obs.restitution;
            vx -= factor * vn * nx;
            vy -= factor * vn * ny;
            vz -= factor * vn * nz;
            if (ny === 0 && Math.abs(vn) > 3) {
              vy += Math.min(2.2, Math.abs(vn) * 0.12);
            }
          }

          if (timeSec - lastObstacleHitTime > 0.16 && obstacleHits.length < 6) {
            lastObstacleHitTime = timeSec;
            obstacleHits.push({ timeSec, x: px, y: py, z: pz, kind: obs.kind });
            bounces.push(timeSec);
          }
        }
      }
    }

    const newGroundY = getElevationAt(hole, px, pz);
    const surfaceNow = getSurfaceAt(hole, px, pz);

    // Water hazard check (water surface at y = -0.45, basin dips from -0.1)
    if (surfaceNow === 'water' && (py <= -0.12 || (!airborne && Math.hypot(vx, vz) < 1.2))) {
      hitWater = true;
      points.push({ x: px, y: -0.4, z: pz });
      break;
    }

    // Out of bounds check
    if (surfaceNow === 'oob') {
      hitWater = true; // treat OOB drop identically to hazard penalty drop
      points.push({ x: px, y: Math.max(py, newGroundY + 0.06), z: pz });
      break;
    }

    // Ground impact & 3D terrain-normal bounce (prevents passing through steep hillsides or pond banks)
    if (py <= newGroundY + 0.06) {
      if (!firstLandingPos && club.loftDeg > 2) {
        firstLandingPos = { x: px, y: newGroundY + 0.06, z: pz };
      }

      if (surfaceNow === 'bunker') {
        hitBunker = true;
        if (vy < -1.2) {
          bounces.push(timeSec);
        }
        vx *= 0.3;
        vz *= 0.3;
        vy = 0;
        py = newGroundY + 0.06;
      } else {
        const gNormal = getGroundNormalAt(hole, px, pz);
        const vnGround = vx * gNormal.x + vy * gNormal.y + vz * gNormal.z;
        const slopeSteep = Math.hypot(gNormal.x, gNormal.z) > 0.22;

        if (vy < -1.1 || (slopeSteep && vnGround < -1.8)) {
          bounces.push(timeSec);
          const bounceRestitution =
            surfaceNow === 'green' ? 0.36 : surfaceNow === 'rough' ? 0.2 : 0.42;
          const horizKeep =
            surfaceNow === 'rough' ? club.rollFactor * 0.55 : club.rollFactor * 0.85;
          if (slopeSteep && vnGround < -1.8) {
            // Deflect velocity off steep terrain bank/plateau edge
            const factor = 1 + bounceRestitution;
            vx -= factor * vnGround * gNormal.x;
            vy -= factor * vnGround * gNormal.y;
            vz -= factor * vnGround * gNormal.z;
            vx *= 0.86;
            vz *= 0.86;
          } else {
            vy = -vy * bounceRestitution;
            vx *= horizKeep;
            vz *= horizKeep;
          }
          py = newGroundY + 0.06;
        } else {
          vy = 0;
          py = newGroundY + 0.06;
        }
      }
    }

    // Cup sink detection
    const distToCup = Math.hypot(px - cup.x, pz - cup.z);
    const heightAboveCup = Math.abs(py - (cup.y + 0.06));
    const currentSpeed = Math.hypot(vx, vz);
    const magnetBonus =
      input.powerActive && char.specialPowerId === 'cup_magnet' ? 1.45 : 1.0;

    if (
      distToCup <= CUP_RADIUS * magnetBonus &&
      heightAboveCup <= 0.42 &&
      currentSpeed <= MAX_CUP_CAPTURE_SPEED * magnetBonus
    ) {
      sunk = true;
      px = cup.x;
      py = cup.y - 0.14;
      pz = cup.z;
      points.push({ x: px, y: py, z: pz });
      break;
    }

    if (step % sampleEvery === 0) {
      points.push({ x: px, y: py, z: pz });
    }

    // Rest check
    if (!airborne && currentSpeed < 0.14) {
      restCounter++;
      if (restCounter >= 24) {
        points.push({ x: px, y: newGroundY + 0.06, z: pz });
        break;
      }
    } else {
      restCounter = 0;
    }
  }

  const finalPos: Vec3 = sunk
    ? { x: cup.x, y: cup.y - 0.14, z: cup.z }
    : hitWater
      ? { x: safeStart.x, y: safeStart.y, z: safeStart.z }
      : { x: px, y: getElevationAt(hole, px, pz) + 0.06, z: pz };

  const carryPoint = firstLandingPos ?? finalPos;
  const carryDistanceM = Math.round(
    Math.hypot(carryPoint.x - safeStart.x, carryPoint.z - safeStart.z),
  );
  const totalDistanceM = hitWater
    ? 0
    : Math.round(Math.hypot(finalPos.x - safeStart.x, finalPos.z - safeStart.z));
  const endSurface: SurfaceType = sunk
    ? 'green'
    : hitWater
      ? getSurfaceAt(hole, safeStart.x, safeStart.z)
      : getSurfaceAt(hole, finalPos.x, finalPos.z);

  return {
    points,
    finalPos,
    launchSpeedMs: Number(launch.speedMs.toFixed(1)),
    launchSpeedKmh: launch.speedKmh,
    carryDistanceM,
    totalDistanceM,
    sunk,
    hitWater,
    hitBunker,
    penaltyStrokes: hitWater ? 1 : 0,
    endSurface,
    durationSec: Number((step * dt).toFixed(2)),
    bounces,
    obstacleHits: obstacleHits.length > 0 ? obstacleHits : undefined,
  };
}

export function estimateOptimalPowerRatio(params: {
  holeIndex: number;
  startPos: Vec3;
  clubId: ClubId;
  characterId: CharacterId;
  aimYaw: number;
  wind: { x: number; z: number };
  powerActive: boolean;
}): number {
  const hole = getHole(params.holeIndex);
  const cup = getHoleCupPos(hole);
  const targetDist = Math.hypot(cup.x - params.startPos.x, cup.z - params.startPos.z);

  let bestPct = 65;
  let bestScore = Infinity;

  // Coarse sweep (step 4%) on exact integer percentages so there is zero rounding drift
  for (let pct = 12; pct <= 100; pct += 4) {
    const p = pct / 100;
    const sim = simulateShotTrajectory({
      holeIndex: params.holeIndex,
      startPos: params.startPos,
      clubId: params.clubId,
      characterId: params.characterId,
      powerRatio: p,
      aimYaw: params.aimYaw,
      wind: params.wind,
      powerActive: params.powerActive,
    });
    if (sim.sunk) return p;
    if (sim.hitWater) continue;
    const rem = Math.hypot(cup.x - sim.finalPos.x, cup.z - sim.finalPos.z);
    if (rem < bestScore) {
      bestScore = rem;
      bestPct = pct;
    }
  }

  // Fine 1% refinement around best coarse match
  const basePct = bestPct;
  for (let pct = Math.max(10, basePct - 5); pct <= Math.min(100, basePct + 5); pct++) {
    const p = pct / 100;
    const sim = simulateShotTrajectory({
      holeIndex: params.holeIndex,
      startPos: params.startPos,
      clubId: params.clubId,
      characterId: params.characterId,
      powerRatio: p,
      aimYaw: params.aimYaw,
      wind: params.wind,
      powerActive: params.powerActive,
    });
    if (sim.sunk) return p;
    if (sim.hitWater) continue;
    const rem = Math.hypot(cup.x - sim.finalPos.x, cup.z - sim.finalPos.z);
    if (rem < bestScore) {
      bestScore = rem;
      bestPct = pct;
    }
  }

  // Fallback if all samples hit hazard: pick proportional ratio
  if (!Number.isFinite(bestScore)) {
    const clubMax = GOLF_CLUBS[params.clubId].approxMaxMeters;
    return Number(Math.max(0.2, Math.min(0.92, targetDist / clubMax)).toFixed(2));
  }

  return bestPct / 100;
}

