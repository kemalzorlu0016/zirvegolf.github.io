import test from 'node:test';
import assert from 'node:assert/strict';
import { CHARACTERS, GOLF_CLUBS, recommendClubForSituation } from './catalog.ts';
import {
  getElevationAt,
  getHole,
  getHoleCupPos,
  getHoleStartTee,
  getInitialAimYaw,
  getSurfaceAt,
} from './courses.ts';
import { computeLaunchParameters, estimateOptimalPowerRatio, simulateShotTrajectory } from './physics.ts';

test('club recommendation chooses appropriate club for distance and lie', () => {
  assert.equal(recommendClubForSituation(180, 'tee'), 'driver');
  assert.equal(recommendClubForSituation(110, 'fairway'), 'iron');
  assert.equal(recommendClubForSituation(45, 'fairway'), 'wedge');
  assert.equal(recommendClubForSituation(90, 'bunker'), 'wedge');
  assert.equal(recommendClubForSituation(10, 'green'), 'putter');
});

test('course surface detection identifies tee, green, bunker, water, and oob', () => {
  const hole1 = getHole(0);
  assert.equal(getSurfaceAt(hole1, hole1.tee.x, hole1.tee.z), 'tee');
  assert.equal(getSurfaceAt(hole1, hole1.cup.x, hole1.cup.z), 'green');
  assert.equal(getSurfaceAt(hole1, hole1.bunkers[0].x, hole1.bunkers[0].z), 'bunker');
  assert.equal(getSurfaceAt(hole1, 999, 999), 'oob');

  const hole2 = getHole(1);
  assert.equal(getSurfaceAt(hole2, hole2.waterZones[0].x, hole2.waterZones[0].z), 'water');
  assert.ok(getElevationAt(hole1, hole1.tee.x, hole1.tee.z) > 1.5);
});

test('driver launches faster and further than iron, wedge, and putter', () => {
  const hole = getHole(2);
  const start = getHoleStartTee(hole);
  const cup = getHoleCupPos(hole);
  const yaw = getInitialAimYaw(start, cup);

  const driverShot = simulateShotTrajectory({
    holeIndex: 2,
    startPos: start,
    clubId: 'driver',
    characterId: 'defne',
    powerRatio: 0.78,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  const ironShot = simulateShotTrajectory({
    holeIndex: 2,
    startPos: start,
    clubId: 'iron',
    characterId: 'defne',
    powerRatio: 0.78,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  const wedgeShot = simulateShotTrajectory({
    holeIndex: 2,
    startPos: start,
    clubId: 'wedge',
    characterId: 'defne',
    powerRatio: 0.78,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  const putterLaunch = computeLaunchParameters({
    holeIndex: 2,
    startPos: cup,
    clubId: 'putter',
    characterId: 'defne',
    powerRatio: 0.5,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  assert.ok(driverShot.launchSpeedMs > ironShot.launchSpeedMs);
  assert.ok(ironShot.launchSpeedMs > wedgeShot.launchSpeedMs);
  assert.ok(driverShot.totalDistanceM > ironShot.totalDistanceM);
  assert.ok(ironShot.totalDistanceM > wedgeShot.totalDistanceM);
  assert.equal(putterLaunch.velocity.y, 0);
});

test('Kaan super_drive increases launch speed and Bora wind_shield nullifies crosswind', () => {
  const hole = getHole(2);
  const start = getHoleStartTee(hole);
  const cup = getHoleCupPos(hole);
  const yaw = getInitialAimYaw(start, cup);

  const normalKaan = simulateShotTrajectory({
    holeIndex: 2,
    startPos: start,
    clubId: 'driver',
    characterId: 'kaan',
    powerRatio: 0.65,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  const boostedKaan = simulateShotTrajectory({
    holeIndex: 2,
    startPos: start,
    clubId: 'driver',
    characterId: 'kaan',
    powerRatio: 0.65,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: true,
  });

  assert.ok(boostedKaan.launchSpeedMs > normalKaan.launchSpeedMs * 1.2);
  assert.ok(boostedKaan.totalDistanceM > normalKaan.totalDistanceM);

  const h1 = getHole(0);
  const start1 = getHoleStartTee(h1);
  const cup1 = getHoleCupPos(h1);
  const yaw1 = getInitialAimYaw(start1, cup1);

  const boraWindy = simulateShotTrajectory({
    holeIndex: 0,
    startPos: start1,
    clubId: 'iron',
    characterId: 'bora',
    powerRatio: 0.85,
    aimYaw: yaw1,
    wind: { x: 6.0, z: 0 },
    powerActive: false,
  });

  const boraShielded = simulateShotTrajectory({
    holeIndex: 0,
    startPos: start1,
    clubId: 'iron',
    characterId: 'bora',
    powerRatio: 0.85,
    aimYaw: yaw1,
    wind: { x: 6.0, z: 0 },
    powerActive: true,
  });

  // With wind_shield active, lateral drift along X is drastically reduced (only tiny terrain slope)
  assert.ok(Math.abs(boraShielded.finalPos.x) < Math.abs(boraWindy.finalPos.x) * 0.35);
  assert.ok(Math.abs(boraShielded.finalPos.x) < 2.5);
});

test('putt toward cup sinks ball and water hazard returns ball with penalty', () => {
  const hole1 = getHole(0);
  const cup = getHoleCupPos(hole1);
  const puttStart = {
    x: cup.x,
    y: getElevationAt(hole1, cup.x, cup.z + 3.5),
    z: cup.z + 3.5,
  };
  const yawToCup = getInitialAimYaw(puttStart, cup);

  const putt = simulateShotTrajectory({
    holeIndex: 0,
    startPos: puttStart,
    clubId: 'putter',
    characterId: 'ece',
    powerRatio: 0.25,
    aimYaw: yawToCup,
    wind: { x: 0, z: 0 },
    powerActive: true,
  });

  assert.equal(putt.sunk, true);
  assert.equal(putt.penaltyStrokes, 0);

  // Hit directly into Hole 2 lake
  const hole2 = getHole(1);
  const tee2 = getHoleStartTee(hole2);
  const lake = hole2.waterZones[0];
  const yawToLake = getInitialAimYaw(tee2, { x: lake.x, y: 0, z: lake.z });

  const splash = simulateShotTrajectory({
    holeIndex: 1,
    startPos: tee2,
    clubId: 'iron',
    characterId: 'defne',
    powerRatio: 0.62,
    aimYaw: yawToLake,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  assert.equal(splash.hitWater, true);
  assert.equal(splash.penaltyStrokes, 1);
  assert.equal(Math.round(splash.finalPos.x), Math.round(tee2.x));
  assert.equal(Math.round(splash.finalPos.z), Math.round(tee2.z));
});

test('all clubs and characters have valid metadata', () => {
  assert.equal(Object.keys(GOLF_CLUBS).length, 4);
  assert.equal(Object.keys(CHARACTERS).length, 4);
});

test('estimateOptimalPowerRatio chooses a power level that gets close to the cup', () => {
  const hole = getHole(0);
  const start = getHoleStartTee(hole);
  const cup = getHoleCupPos(hole);
  const yaw = getInitialAimYaw(start, cup);

  const optPower = estimateOptimalPowerRatio({
    holeIndex: 0,
    startPos: start,
    clubId: 'driver',
    characterId: 'defne',
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  assert.ok(optPower >= 0.1 && optPower <= 1);
  const shot = simulateShotTrajectory({
    holeIndex: 0,
    startPos: start,
    clubId: 'driver',
    characterId: 'defne',
    powerRatio: optPower,
    aimYaw: yaw,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });
  const distRemaining = Math.hypot(cup.x - shot.finalPos.x, cup.z - shot.finalPos.z);
  assert.ok(distRemaining < 18);
});

test('golf ball collides with and deflects off solid trees and rocks', () => {
  const hole = getHole(0);
  const rock = hole.rockAnchors[0];
  const rockStart = { x: rock.x, y: getElevationAt(hole, rock.x, rock.z + 2.8), z: rock.z + 2.8 };
  const yawToRock = getInitialAimYaw(rockStart, { x: rock.x, y: 0, z: rock.z });

  const rockHit = simulateShotTrajectory({
    holeIndex: 0,
    startPos: rockStart,
    clubId: 'putter',
    characterId: 'defne',
    powerRatio: 1.0,
    aimYaw: yawToRock,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  assert.ok(rockHit.obstacleHits && rockHit.obstacleHits.length > 0);
  assert.equal(rockHit.obstacleHits[0].kind, 'rock');
  assert.ok(rockHit.finalPos.z > rock.z);

  const tree = hole.treeAnchors[0];
  const treeStart = { x: tree.x, y: getElevationAt(hole, tree.x, tree.z + 10), z: tree.z + 10 };
  const yawToTree = getInitialAimYaw(treeStart, { x: tree.x, y: 0, z: tree.z });

  const treeHit = simulateShotTrajectory({
    holeIndex: 0,
    startPos: treeStart,
    clubId: 'driver',
    characterId: 'kaan',
    powerRatio: 0.75,
    aimYaw: yawToTree,
    wind: { x: 0, z: 0 },
    powerActive: false,
  });

  assert.ok(treeHit.obstacleHits && treeHit.obstacleHits.length > 0);
  assert.ok(treeHit.finalPos.z > tree.z - 25);
});

