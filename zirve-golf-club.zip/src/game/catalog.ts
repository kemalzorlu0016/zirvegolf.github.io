import type { CharacterId, CharacterSpec, ClubId, GolfClubSpec, SurfaceType } from './types.ts';

export const GOLF_CLUBS: Record<ClubId, GolfClubSpec> = {
  driver: {
    id: 'driver',
    keyHint: '1',
    name: 'Driver (1W)',
    shortName: 'Driver',
    roleLabel: 'Maksimum Mesafe · Düşük Kavis',
    maxSpeed: 41.5,
    minSpeed: 14,
    loftDeg: 17,
    rollFactor: 0.74,
    spinDrag: 0.009,
    sandPenalty: 0.42,
    roughPenalty: 0.68,
    approxMaxMeters: 175,
    accentColor: '#f59e0b',
  },
  iron: {
    id: 'iron',
    keyHint: '2',
    name: 'Demir Sopa (7I)',
    shortName: '7-Iron',
    roleLabel: 'Dengeli · Kontrollü İniş',
    maxSpeed: 31.5,
    minSpeed: 10,
    loftDeg: 29,
    rollFactor: 0.48,
    spinDrag: 0.014,
    sandPenalty: 0.65,
    roughPenalty: 0.82,
    approxMaxMeters: 115,
    accentColor: '#38bdf8',
  },
  wedge: {
    id: 'wedge',
    keyHint: '3',
    name: 'Wedge (PW)',
    shortName: 'Wedge',
    roleLabel: 'Yüksek Kavis · Kum Kurtarma',
    maxSpeed: 21.5,
    minSpeed: 6,
    loftDeg: 47,
    rollFactor: 0.22,
    spinDrag: 0.018,
    sandPenalty: 0.92,
    roughPenalty: 0.94,
    approxMaxMeters: 56,
    accentColor: '#a78bfa',
  },
  putter: {
    id: 'putter',
    keyHint: '4',
    name: 'Putter (PT)',
    shortName: 'Putter',
    roleLabel: 'Green Üstü · Sıfır Kavis',
    maxSpeed: 13.5,
    minSpeed: 2.2,
    loftDeg: 0,
    rollFactor: 0.96,
    spinDrag: 0.008,
    sandPenalty: 0.3,
    roughPenalty: 0.45,
    approxMaxMeters: 30,
    accentColor: '#34d399',
  },
};

export const CLUB_ORDER: ClubId[] = ['driver', 'iron', 'wedge', 'putter'];

export const CHARACTERS: Record<CharacterId, CharacterSpec> = {
  kaan: {
    id: 'kaan',
    name: 'Kaan Yılmaz',
    title: 'Güç Şampiyonu',
    bio: 'Uzun par deliklerinde agresif vuruşlarıyla mesafe rekorları kırar.',
    powerStat: 10,
    controlStat: 7,
    spinStat: 6,
    powerMultiplier: 1.07,
    windResistance: 0.12,
    greenTouch: 0.98,
    specialPowerId: 'super_drive',
    specialPowerName: 'Süper Vuruş',
    specialPowerDesc: 'Atış hızını +%28 artırır ve rüzgar sapmasını yarıya indirir.',
    maxChargesPerMatch: 3,
    primaryColor: '#c83e37',
    secondaryColor: '#1f2937',
    accentColor: '#fbbf24',
    hatStyle: 'visor',
  },
  defne: {
    id: 'defne',
    name: 'Defne Aksoy',
    title: 'Hassas Nişancı',
    bio: 'Klinikleri kıskandıran isabetiyle bayrağı milimetrik hedefler.',
    powerStat: 7,
    controlStat: 10,
    spinStat: 8,
    powerMultiplier: 1.0,
    windResistance: 0.18,
    greenTouch: 1.05,
    specialPowerId: 'laser_aim',
    specialPowerName: 'Lazer Rehber',
    specialPowerDesc: 'Tam iniş noktasını ve green eğim çizgisini eksiksiz gösterir.',
    maxChargesPerMatch: 3,
    primaryColor: '#16a34a',
    secondaryColor: '#18181b',
    accentColor: '#4ade80',
    hatStyle: 'sunhat',
  },
  bora: {
    id: 'bora',
    name: 'Bora Demir',
    title: 'Rüzgar Ustası',
    bio: 'Zorlu kanyon rüzgarlarını okur ve topu havada süzerek taşır.',
    powerStat: 8,
    controlStat: 8,
    spinStat: 9,
    powerMultiplier: 1.02,
    windResistance: 0.35,
    greenTouch: 1.0,
    specialPowerId: 'wind_shield',
    specialPowerName: 'Rüzgar Kalkanı',
    specialPowerDesc: 'Vuruş boyunca rüzgar etkisini tamamen sıfırlar ve havada süzülmeyi uzatır.',
    maxChargesPerMatch: 3,
    primaryColor: '#1d4ed8',
    secondaryColor: '#e2e8f0',
    accentColor: '#38bdf8',
    hatStyle: 'cap',
  },
  ece: {
    id: 'ece',
    name: 'Ece Yıldız',
    title: 'Green Maestrosu',
    bio: 'Kum tuzaklarından tek dokunuşla çıkar, green üstünde hata yapmaz.',
    powerStat: 7,
    controlStat: 9,
    spinStat: 10,
    powerMultiplier: 0.99,
    windResistance: 0.15,
    greenTouch: 1.15,
    specialPowerId: 'cup_magnet',
    specialPowerName: 'Mıknatıs Green',
    specialPowerDesc: 'Deliğe 4m yaklaşınca topu deliğe çeker ve green frenlemesini yumuşatır.',
    maxChargesPerMatch: 3,
    primaryColor: '#d97706',
    secondaryColor: '#1e293b',
    accentColor: '#fcd34d',
    hatStyle: 'beret',
  },
};

export const CHARACTER_ORDER: CharacterId[] = ['kaan', 'defne', 'bora', 'ece'];

export const PLAYER_COLORS = ['#f59e0b', '#38bdf8', '#f43f5e', '#34d399'];

export function recommendClubForSituation(distanceMeters: number, surface: SurfaceType): ClubId {
  if (surface === 'green' || distanceMeters <= 24) {
    return 'putter';
  }
  if (surface === 'bunker' || distanceMeters <= 68) {
    return 'wedge';
  }
  if (surface === 'tee' && distanceMeters >= 130) {
    return 'driver';
  }
  if (distanceMeters <= 145) {
    return 'iron';
  }
  return 'driver';
}
