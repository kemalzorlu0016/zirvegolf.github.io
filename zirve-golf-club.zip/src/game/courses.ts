import type { CourseCircleZone, CourseSegment, HoleDefinition, SurfaceType, Vec3 } from './types.ts';

function distToSegmentSq(px: number, pz: number, seg: CourseSegment): number {
  const dx = seg.x2 - seg.x1;
  const dz = seg.z2 - seg.z1;
  const lenSq = dx * dx + dz * dz;
  if (lenSq < 1e-6) return (px - seg.x1) ** 2 + (pz - seg.z1) ** 2;
  const t = Math.max(0, Math.min(1, ((px - seg.x1) * dx + (pz - seg.z1) * dz) / lenSq));
  const projX = seg.x1 + t * dx;
  const projZ = seg.z1 + t * dz;
  return (px - projX) ** 2 + (pz - projZ) ** 2;
}

function isInsideEllipse(px: number, pz: number, zone: CourseCircleZone): boolean {
  const dx = px - zone.x;
  const dz = pz - zone.z;
  const rot = zone.rotation ?? 0;
  const cos = Math.cos(-rot);
  const sin = Math.sin(-rot);
  const lx = dx * cos - dz * sin;
  const lz = dx * sin + dz * cos;
  return (lx * lx) / (zone.rx * zone.rx) + (lz * lz) / (zone.rz * zone.rz) <= 1;
}

export const HOLES: HoleDefinition[] = [
  {
    index: 0,
    name: 'Körfez Başlangıcı',
    subtitle: 'Yüksek tee platformu, gölet geçidi ve çift kum korumasında green',
    par: 4,
    tee: { x: 0, y: 0, z: 66 },
    cup: { x: 0, y: 0, z: -72 },
    defaultWind: { x: 1.6, z: -0.6 },
    fairways: [
      { x1: 0, z1: 42, x2: 0, z2: 24, width: 17 },
      { x1: 0, z1: -18, x2: 0, z2: -62, width: 17 },
    ],
    green: { x: 0, z: -72, rx: 14, rz: 13 },
    bunkers: [
      { x: -13, z: -60, rx: 6.5, rz: 4.5, rotation: 0.3 },
      { x: 13.5, z: -62, rx: 6.0, rz: 5.0, rotation: -0.25 },
    ],
    waterZones: [
      { x: 3, z: 0, rx: 22, rz: 14, rotation: 0.14 },
    ],
    bounds: { minX: -62, maxX: 62, minZ: -120, maxZ: 98 },
    treeAnchors: [
      { x: -16, z: 54, scale: 1.28 },
      { x: -24, z: 36, scale: 1.18 },
      { x: -28, z: 12, scale: 1.08 },
      { x: -25, z: -18, scale: 1.22 },
      { x: -28, z: -46, scale: 1.05 },
      { x: -24, z: -78, scale: 1.15 },
      { x: 18, z: 50, scale: 1.15 },
      { x: 26, z: 28, scale: 1.2 },
      { x: 28, z: -4, scale: 1.1 },
      { x: 25, z: -32, scale: 1.05 },
      { x: 27, z: -56, scale: 1.15 },
      { x: 23, z: -80, scale: 1.2 },
      { x: -9, z: -88, scale: 1.05 },
      { x: 9, z: -89, scale: 1.15 },
    ],
    rockAnchors: [
      { x: -24, z: 4, scale: 1.25 },
      { x: 28, z: 2, scale: 1.3 },
      { x: -19, z: -82, scale: 1.0 },
    ],
  },
  {
    index: 1,
    name: 'Göl Kıyısı',
    subtitle: 'Sağa kıvrılan fairway ve parıldayan alp gölü engeli',
    par: 4,
    tee: { x: -22, y: 0, z: 85 },
    cup: { x: 28, y: 0, z: -78 },
    defaultWind: { x: -2.4, z: 1.1 },
    fairways: [
      { x1: -22, z1: 85, x2: -18, z2: 12, width: 15 },
      { x1: -18, z1: 12, x2: 24, z2: -62, width: 16 },
    ],
    green: { x: 28, z: -78, rx: 14, rz: 13 },
    bunkers: [
      { x: 12, z: -68, rx: 6.5, rz: 4.5, rotation: 0.45 },
      { x: 42, z: -72, rx: 5.5, rz: 5.5, rotation: -0.2 },
    ],
    waterZones: [
      { x: 18, z: 26, rx: 21, rz: 36, rotation: 0.2 },
      { x: -8, z: -44, rx: 14, rz: 20, rotation: -0.15 },
    ],
    bounds: { minX: -65, maxX: 68, minZ: -135, maxZ: 115 },
    treeAnchors: [
      { x: -40, z: 68, scale: 1.1 },
      { x: -42, z: 32, scale: 1.2 },
      { x: -38, z: -8, scale: 1.0 },
      { x: -32, z: -42, scale: 1.15 },
      { x: 46, z: 54, scale: 1.05 },
      { x: 48, z: 10, scale: 1.2 },
      { x: 48, z: -38, scale: 0.95 },
      { x: 48, z: -92, scale: 1.1 },
      { x: 10, z: -96, scale: 1.25 },
      { x: 30, z: -99, scale: 1.0 },
    ],
    rockAnchors: [
      { x: 38, z: 26, scale: 1.3 },
      { x: -22, z: -58, scale: 1.1 },
      { x: 46, z: -54, scale: 0.9 },
    ],
  },
  {
    index: 2,
    name: 'Zirve Kanyonu',
    subtitle: 'Dalgalı yamaçlar, çapraz rüzgar ve korumalı şampiyona greeni',
    par: 4,
    tee: { x: 12, y: 0, z: 98 },
    cup: { x: -16, y: 0, z: -92 },
    defaultWind: { x: 3.1, z: -1.4 },
    fairways: [
      { x1: 12, z1: 98, x2: 14, z2: 24, width: 15 },
      { x1: 14, z1: 24, x2: -14, z2: -76, width: 15 },
    ],
    green: { x: -16, z: -92, rx: 13.5, rz: 13.5 },
    bunkers: [
      { x: 0, z: 10, rx: 6, rz: 5, rotation: 0.1 },
      { x: -30, z: -82, rx: 6.5, rz: 4.8, rotation: -0.4 },
      { x: -3, z: -80, rx: 5.5, rz: 4.5, rotation: 0.35 },
    ],
    waterZones: [
      { x: -22, z: 38, rx: 16, rz: 24, rotation: -0.1 },
      { x: 22, z: -48, rx: 16, rz: 26, rotation: 0.2 },
    ],
    bounds: { minX: -70, maxX: 70, minZ: -165, maxZ: 130 },
    treeAnchors: [
      { x: 36, z: 82, scale: 1.15 },
      { x: 38, z: 40, scale: 1.0 },
      { x: 40, z: -12, scale: 1.2 },
      { x: -42, z: 76, scale: 1.1 },
      { x: -44, z: 12, scale: 1.25 },
      { x: -42, z: -38, scale: 0.95 },
      { x: -40, z: -104, scale: 1.1 },
      { x: -12, z: -112, scale: 1.2 },
      { x: 14, z: -104, scale: 1.05 },
    ],
    rockAnchors: [
      { x: -35, z: 36, scale: 1.35 },
      { x: 34, z: -48, scale: 1.25 },
      { x: -28, z: -102, scale: 1.1 },
    ],
  },
];

export function getHole(index: number): HoleDefinition {
  const safeIdx = ((index % HOLES.length) + HOLES.length) % HOLES.length;
  return HOLES[safeIdx];
}

export function getSurfaceAt(hole: HoleDefinition, x: number, z: number): SurfaceType {
  if (
    x < hole.bounds.minX ||
    x > hole.bounds.maxX ||
    z < hole.bounds.minZ ||
    z > hole.bounds.maxZ
  ) {
    return 'oob';
  }

  for (const water of hole.waterZones) {
    if (isInsideEllipse(x, z, water)) {
      return 'water';
    }
  }

  for (const bunker of hole.bunkers) {
    if (isInsideEllipse(x, z, bunker)) {
      return 'bunker';
    }
  }

  if (isInsideEllipse(x, z, hole.green)) {
    return 'green';
  }

  // Crisp rectangular elevated tee platform
  if (Math.abs(x - hole.tee.x) <= 5.8 && Math.abs(z - hole.tee.z) <= 4.8) {
    return 'tee';
  }

  for (const seg of hole.fairways) {
    const dSq = distToSegmentSq(x, z, seg);
    if (dSq <= seg.width * seg.width) {
      return 'fairway';
    }
  }

  return 'rough';
}

export function getElevationAt(hole: HoleDefinition, x: number, z: number): number {
  // Subtle natural rolling valley hills + crisp raised rectangular tee box + sunken pond basins
  const baseRoll =
    Math.sin(x * 0.045 + hole.index * 1.1) * Math.cos(z * 0.032) * 1.15 +
    Math.sin(z * 0.02 + x * 0.015) * 0.55;

  let h = baseRoll;

  // Raised crisp rectangular Tee Box plateau overlooking the valley
  const tdx = Math.max(0, Math.abs(x - hole.tee.x) - 5.6);
  const tdz = Math.max(0, Math.abs(z - hole.tee.z) - 4.6);
  const teeEdgeDist = Math.hypot(tdx, tdz);
  if (teeEdgeDist < 4.5) {
    const t = Math.max(0, 1 - teeEdgeDist / 4.5);
    const smoothT = t * t * (3 - 2 * t);
    const teeBase = 3.25 + hole.index * 0.25;
    h = h * (1 - smoothT) + teeBase * smoothT;
  }

  // Smooth green plateau with subtle readable break
  const gx = (x - hole.green.x) / hole.green.rx;
  const gz = (z - hole.green.z) / hole.green.rz;
  const gDist = Math.hypot(gx, gz);
  if (gDist < 1.35) {
    const blend = Math.max(0, Math.min(1, (1.35 - gDist) / 0.45));
    const greenTarget = 1.05 + (x - hole.green.x) * 0.024 + (z - hole.green.z) * 0.018;
    h = h * (1 - blend) + greenTarget * blend;
  }

  // Depress bunkers softly
  for (const bunker of hole.bunkers) {
    const bx = (x - bunker.x) / bunker.rx;
    const bz = (z - bunker.z) / bunker.rz;
    const bDist = Math.hypot(bx, bz);
    if (bDist < 1.2) {
      const depth = Math.max(0, 1 - bDist / 1.2);
      h -= depth * depth * 0.75;
    }
  }

  // Depress water basins cleanly below water level (y = -0.45) with carved earthen banks
  for (const water of hole.waterZones) {
    const wx = (x - water.x) / water.rx;
    const wz = (z - water.z) / water.rz;
    const wDist = Math.hypot(wx, wz);
    if (wDist < 1.18) {
      const depth = Math.max(0, 1 - wDist / 1.18);
      const bankLip = wDist > 0.88 && wDist < 1.14 ? Math.sin(((wDist - 0.88) / 0.26) * Math.PI) * 0.48 : 0;
      h = h * (1 - depth) + -1.25 * depth + bankLip;
    }
  }

  return h;
}

export function getGroundNormalAt(hole: HoleDefinition, x: number, z: number): Vec3 {
  const eps = 0.35;
  const hL = getElevationAt(hole, x - eps, z);
  const hR = getElevationAt(hole, x + eps, z);
  const hD = getElevationAt(hole, x, z - eps);
  const hU = getElevationAt(hole, x, z + eps);
  const nx = hL - hR;
  const ny = 2 * eps;
  const nz = hD - hU;
  const len = Math.hypot(nx, ny, nz) || 1;
  return { x: nx / len, y: ny / len, z: nz / len };
}

export function getHoleStartTee(hole: HoleDefinition): Vec3 {
  return {
    x: hole.tee.x,
    y: getElevationAt(hole, hole.tee.x, hole.tee.z),
    z: hole.tee.z,
  };
}

export function getHoleCupPos(hole: HoleDefinition): Vec3 {
  return {
    x: hole.cup.x,
    y: getElevationAt(hole, hole.cup.x, hole.cup.z),
    z: hole.cup.z,
  };
}

export function getInitialAimYaw(from: Vec3, to: Vec3): number {
  return Math.atan2(to.x - from.x, to.z - from.z);
}

export interface CourseObstacle {
  shape: 'cylinder' | 'cone' | 'sphere' | 'box';
  kind: 'wood' | 'foliage' | 'rock' | 'structure';
  x: number;
  z: number;
  yMin: number;
  yMax: number;
  radius: number;
  topRadius?: number;
  halfX?: number;
  halfZ?: number;
  restitution: number;
}

export function getBroadleafTreeCoords(
  hole: HoleDefinition,
): Array<{ x: number; z: number; s: number }> {
  return [
    { x: hole.green.x - hole.green.rx - 12, z: hole.green.z - 14, s: 1.25 },
    { x: hole.green.x + hole.green.rx + 12, z: hole.green.z - 16, s: 1.15 },
    { x: hole.green.x - 4, z: hole.green.z - hole.green.rz - 16, s: 1.4 },
    { x: hole.tee.x - 21, z: hole.tee.z - 14, s: 1.1 },
    { x: hole.tee.x + 21, z: hole.tee.z - 18, s: 1.2 },
    { x: hole.tee.x - 16, z: hole.tee.z - 28, s: 1.15 },
    { x: hole.tee.x + 17, z: hole.tee.z - 34, s: 1.05 },
    ...(hole.waterZones.length > 0
      ? [
          {
            x: hole.waterZones[0].x - hole.waterZones[0].rx - 5,
            z: hole.waterZones[0].z - 4,
            s: 1.3,
          },
          {
            x: hole.waterZones[0].x + hole.waterZones[0].rx + 5,
            z: hole.waterZones[0].z - 12,
            s: 1.25,
          },
        ]
      : []),
  ];
}

export function getResortTentCoords(
  hole: HoleDefinition,
): Array<{ x: number; z: number; color: number; rot: number }> {
  return [
    { x: hole.tee.x - 19, z: hole.tee.z - 22, color: 0xf59e0b, rot: 0.35 },
    { x: hole.green.x + hole.green.rx + 14, z: hole.green.z + 4, color: 0xf59e0b, rot: -0.4 },
    {
      x: hole.green.x - 16,
      z: hole.green.z - hole.green.rz - 12,
      color: 0xef4444,
      rot: 0.15,
    },
  ];
}

const obstacleCache = new Map<number, CourseObstacle[]>();

export function getCourseObstacles(hole: HoleDefinition): CourseObstacle[] {
  const cached = obstacleCache.get(hole.index);
  if (cached) return cached;

  const list: CourseObstacle[] = [];

  // 1. Alpine Pine Trees (anchor + outer perimeter)
  const pinePositions: Array<{ x: number; z: number; scale: number }> = [...hole.treeAnchors];
  for (let i = 0; i < 42; i++) {
    const angle = (i / 42) * Math.PI * 2;
    const radiusX = 64 + (i % 3) * 12;
    const radiusZ = 104 + ((i + 1) % 3) * 14;
    pinePositions.push({
      x: Math.cos(angle) * radiusX,
      z: Math.sin(angle) * radiusZ,
      scale: 1.0 + ((i % 5) - 2) * 0.14,
    });
  }

  for (const tp of pinePositions) {
    let ty = getElevationAt(hole, tp.x, tp.z);
    const edgeDistX = Math.max(0, Math.abs(tp.x) - 56);
    const edgeDistZ = Math.max(0, Math.abs(tp.z) - 108);
    const rim = Math.hypot(edgeDistX, edgeDistZ);
    if (rim > 0) {
      ty += Math.min(32, rim * 0.34 + Math.sin(tp.x * 0.07) * Math.cos(tp.z * 0.06) * 3.2);
    }
    const baseY = ty - 0.2;
    list.push({
      shape: 'cylinder',
      kind: 'wood',
      x: tp.x,
      z: tp.z,
      yMin: baseY,
      yMax: baseY + 3.0 * tp.scale,
      radius: 0.45 * tp.scale,
      restitution: 0.65,
    });
    list.push({
      shape: 'cone',
      kind: 'foliage',
      x: tp.x,
      z: tp.z,
      yMin: baseY + 1.8 * tp.scale,
      yMax: baseY + 8.8 * tp.scale,
      radius: 2.35 * tp.scale,
      topRadius: 0.45 * tp.scale,
      restitution: 0.28,
    });
  }

  // 2. Broadleaf Canopy Trees
  for (const bc of getBroadleafTreeCoords(hole)) {
    const by = getElevationAt(hole, bc.x, bc.z) - 0.15;
    list.push({
      shape: 'cylinder',
      kind: 'wood',
      x: bc.x,
      z: bc.z,
      yMin: by,
      yMax: by + 4.1 * bc.s,
      radius: 0.52 * bc.s,
      restitution: 0.65,
    });
    const puffs = [
      { x: 0, y: 5.2, z: 0, r: 1.15 },
      { x: -1.3, y: 4.5, z: 0.8, r: 0.85 },
      { x: 1.35, y: 4.6, z: -0.6, r: 0.88 },
      { x: 0.2, y: 6.1, z: 0.4, r: 0.82 },
    ];
    for (const pf of puffs) {
      list.push({
        shape: 'sphere',
        kind: 'foliage',
        x: bc.x + pf.x * bc.s,
        z: bc.z + pf.z * bc.s,
        yMin: by + (pf.y - 2.25 * pf.r) * bc.s,
        yMax: by + (pf.y + 2.25 * pf.r) * bc.s,
        radius: 2.25 * pf.r * bc.s,
        restitution: 0.3,
      });
    }
  }

  // 3. Granite Rock Outcrops
  for (const rk of hole.rockAnchors) {
    const ry = getElevationAt(hole, rk.x, rk.z) - 0.15;
    list.push({
      shape: 'sphere',
      kind: 'rock',
      x: rk.x,
      z: rk.z,
      yMin: ry - 0.4,
      yMax: ry + rk.scale * 1.45,
      radius: rk.scale * 1.48,
      restitution: 0.74,
    });
    list.push({
      shape: 'sphere',
      kind: 'rock',
      x: rk.x + rk.scale * 1.15,
      z: rk.z + 0.35,
      yMin: ry - 0.3,
      yMax: ry + rk.scale * 0.9,
      radius: rk.scale * 0.85,
      restitution: 0.74,
    });
  }

  // 4. Resort Pavilions / Tents
  for (const ts of getResortTentCoords(hole)) {
    const ty = getElevationAt(hole, ts.x, ts.z);
    list.push({
      shape: 'box',
      kind: 'structure',
      x: ts.x,
      z: ts.z,
      yMin: ty,
      yMax: ty + 4.7,
      radius: 2.6,
      halfX: 2.15,
      halfZ: 2.15,
      restitution: 0.56,
    });
  }

  // 5. Tee Box Fence Rails
  for (const offsetX of [-6.2, 6.2]) {
    const fx = hole.tee.x + offsetX;
    const my = getElevationAt(hole, fx, hole.tee.z);
    list.push({
      shape: 'box',
      kind: 'structure',
      x: fx,
      z: hole.tee.z,
      yMin: my,
      yMax: my + 0.9,
      radius: 1.4,
      halfX: 0.24,
      halfZ: 1.35,
      restitution: 0.58,
    });
  }

  obstacleCache.set(hole.index, list);
  return list;
}

