import type { ClubId } from './types.ts';

class GolfAudioEngine {
  private ctx: AudioContext | null = null;
  private muted = false;

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    return this.muted;
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playSwing(clubId: ClubId, powerRatio: number): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const pitchJitter = 0.94 + Math.random() * 0.12;

    // 1. Whoosh (filtered noise) for driver/iron/wedge
    if (clubId !== 'putter') {
      const bufferSize = Math.floor(ctx.sampleRate * 0.18);
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(340, now);
      filter.frequency.exponentialRampToValueAtTime(1400 * (0.7 + powerRatio * 0.6), now + 0.12);
      filter.Q.value = 1.8;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.16 * powerRatio, now + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start(now);
    }

    // 2. Club face impact strike
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();

    if (clubId === 'driver') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(620 * pitchJitter, now + 0.05);
      osc.frequency.exponentialRampToValueAtTime(190, now + 0.22);
      oscGain.gain.setValueAtTime(0.001, now + 0.045);
      oscGain.gain.linearRampToValueAtTime(0.32 * (0.6 + powerRatio * 0.4), now + 0.055);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    } else if (clubId === 'iron') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(480 * pitchJitter, now + 0.05);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.18);
      oscGain.gain.setValueAtTime(0.001, now + 0.045);
      oscGain.gain.linearRampToValueAtTime(0.28 * (0.6 + powerRatio * 0.4), now + 0.055);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
    } else if (clubId === 'wedge') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(540 * pitchJitter, now + 0.05);
      osc.frequency.exponentialRampToValueAtTime(170, now + 0.14);
      oscGain.gain.setValueAtTime(0.001, now + 0.045);
      oscGain.gain.linearRampToValueAtTime(0.22, now + 0.055);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    } else {
      // Putter crisp soft tock
      osc.type = 'sine';
      osc.frequency.setValueAtTime(340 * pitchJitter, now + 0.03);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.1);
      oscGain.gain.setValueAtTime(0.001, now + 0.025);
      oscGain.gain.linearRampToValueAtTime(0.18 * (0.5 + powerRatio * 0.5), now + 0.035);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
    }

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);
    osc.start(now + 0.02);
    osc.stop(now + 0.28);
  }

  public playBounce(isBunker: boolean): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(isBunker ? 110 : 185, now);
    osc.frequency.exponentialRampToValueAtTime(60, now + 0.08);
    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  public playSplash(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const bufferSize = Math.floor(ctx.sampleRate * 0.35);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.35));
    }
    const src = ctx.createBufferSource();
    src.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(950, now);
    filter.frequency.exponentialRampToValueAtTime(280, now + 0.34);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(now);
  }

  public playPowerActivate(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.045);
      gain.gain.setValueAtTime(0.001, now + i * 0.045);
      gain.gain.linearRampToValueAtTime(0.12, now + i * 0.045 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.045 + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.045);
      osc.stop(now + i * 0.045 + 0.24);
    });
  }

  public playCupSink(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    // Cup rattle + cheerful chord
    const freqs = [440, 554.37, 659.25, 880];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = idx === 0 ? 'square' : 'triangle';
      const t = now + idx * 0.06;
      osc.frequency.setValueAtTime(f, t);
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(idx === 0 ? 0.08 : 0.14, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.38);
    });
  }

  public playUiClick(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(640, now);
    osc.frequency.exponentialRampToValueAtTime(420, now + 0.05);
    gain.gain.setValueAtTime(0.07, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.06);
  }
}

export const golfAudio = new GolfAudioEngine();
