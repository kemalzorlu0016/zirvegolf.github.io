export type GameScreenState = 'title' | 'playing' | 'paused' | 'gameover';

export type ClubId = 'driver' | 'iron' | 'wedge' | 'putter';

export type CharacterId = 'kaan' | 'defne' | 'bora' | 'ece';

export type PowerId = 'super_drive' | 'laser_aim' | 'wind_shield' | 'cup_magnet';

export type SurfaceType = 'tee' | 'fairway' | 'rough' | 'bunker' | 'green' | 'water' | 'oob';

export type CameraMode = 'follow' | 'overhead' | 'aim';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface GolfClubSpec {
  id: ClubId;
  keyHint: string;
  name: string;
  shortName: string;
  roleLabel: string;
  maxSpeed: number; // m/s
  minSpeed: number; // m/s
  loftDeg: number; // degrees
  rollFactor: number; // bounce/roll retention
  spinDrag: number;
  sandPenalty: number; // 0..1 retention when hitting from bunker
  roughPenalty: number; // 0..1 retention when hitting from rough
  approxMaxMeters: number;
  accentColor: string;
}

export interface CharacterSpec {
  id: CharacterId;
  name: string;
  title: string;
  bio: string;
  powerStat: number; // 1..10
  controlStat: number; // 1..10
  spinStat: number; // 1..10
  powerMultiplier: number; // 0.94..1.08
  windResistance: number; // 0..0.4
  greenTouch: number; // 0.9..1.15
  specialPowerId: PowerId;
  specialPowerName: string;
  specialPowerDesc: string;
  maxChargesPerMatch: number;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  hatStyle: 'visor' | 'sunhat' | 'cap' | 'beret';
}

export interface CourseCircleZone {
  x: number;
  z: number;
  rx: number;
  rz: number;
  rotation?: number;
}

export interface CourseSegment {
  x1: number;
  z1: number;
  x2: number;
  z2: number;
  width: number;
}

export interface HoleDefinition {
  index: number;
  name: string;
  subtitle: string;
  par: number;
  tee: Vec3;
  cup: Vec3;
  defaultWind: { x: number; z: number };
  fairways: CourseSegment[];
  green: CourseCircleZone;
  bunkers: CourseCircleZone[];
  waterZones: CourseCircleZone[];
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  treeAnchors: Array<{ x: number; z: number; scale: number }>;
  rockAnchors: Array<{ x: number; z: number; scale: number }>;
}

export interface ShotInput {
  holeIndex: number;
  startPos: Vec3;
  clubId: ClubId;
  characterId: CharacterId;
  powerRatio: number; // 0.08..1.0
  aimYaw: number; // radians, 0 = +Z, Math.PI = -Z
  wind: { x: number; z: number };
  powerActive: boolean;
}

export type ObstacleKind = 'wood' | 'foliage' | 'rock' | 'structure';

export interface ObstacleHitInfo {
  timeSec: number;
  x: number;
  y: number;
  z: number;
  kind: ObstacleKind;
}

export interface ShotSimulationResult {
  points: Vec3[]; // sampled path at ~30Hz for smooth deterministic playback
  finalPos: Vec3;
  launchSpeedMs: number;
  launchSpeedKmh: number;
  carryDistanceM: number;
  totalDistanceM: number;
  sunk: boolean;
  hitWater: boolean;
  hitBunker: boolean;
  penaltyStrokes: number;
  endSurface: SurfaceType;
  durationSec: number;
  bounces: number[]; // timestamps in sec where ground bounces happened
  obstacleHits?: ObstacleHitInfo[];
}

export interface PlayerMatchState {
  id: string;
  name: string;
  characterId: CharacterId;
  color: string;
  connected: boolean;
  isBot?: boolean;
  ballPos: Vec3;
  currentHoleStrokes: number;
  holeScores: Array<number | null>;
  totalStrokes: number;
  holedOut: boolean;
  powerCharges: number;
  activePower: boolean;
  selectedClub: ClubId;
  aimYaw: number;
}

export interface PublicRoomSummary {
  code: string;
  hostName: string;
  playerCount: number;
  botCount: number;
  maxPlayers: number;
  status: 'waiting' | 'playing' | 'finished';
  currentHoleIndex: number;
}

export interface RoomState {
  code: string;
  hostId: string;
  isPrivate?: boolean;
  status: 'waiting' | 'playing' | 'finished';
  currentHoleIndex: number;
  wind: { x: number; z: number };
  currentTurnPlayerId: string | null;
  players: PlayerMatchState[];
  lastEventText: string;
}

export type ClientWsMessage =
  | { type: 'rooms:list' }
  | {
      type: 'room:create';
      playerName: string;
      characterId: CharacterId;
      customCode?: string;
      isPrivate?: boolean;
    }
  | { type: 'room:join'; code: string; playerName: string; characterId: CharacterId }
  | { type: 'room:leave' }
  | { type: 'room:character'; characterId: CharacterId }
  | { type: 'room:add_bot' }
  | { type: 'room:remove_bot'; botId: string }
  | { type: 'room:start' }
  | { type: 'room:rematch' }
  | { type: 'player:aim'; aimYaw: number; clubId: ClubId; activePower: boolean }
  | { type: 'player:shot'; clubId: ClubId; powerRatio: number; aimYaw: number; usePower: boolean };

export type ServerWsMessage =
  | { type: 'welcome'; clientId: string }
  | { type: 'rooms:listed'; rooms: PublicRoomSummary[] }
  | { type: 'room:joined'; room: RoomState; youId: string }
  | { type: 'room:state'; room: RoomState }
  | {
      type: 'shot:executed';
      playerId: string;
      clubId: ClubId;
      characterId: CharacterId;
      powerActive: boolean;
      simulation: ShotSimulationResult;
      room: RoomState;
    }
  | {
      type: 'player:aimed';
      playerId: string;
      aimYaw: number;
      clubId: ClubId;
      activePower: boolean;
    }
  | { type: 'room:left' }
  | { type: 'error'; message: string };
