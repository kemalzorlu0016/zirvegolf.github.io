import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { CHARACTERS, PLAYER_COLORS, recommendClubForSituation } from './src/game/catalog.ts';
import { getHole, getHoleCupPos, getHoleStartTee, getInitialAimYaw, getSurfaceAt, HOLES } from './src/game/courses.ts';
import { estimateOptimalPowerRatio, simulateShotTrajectory } from './src/game/physics.ts';
import type {
  CharacterId,
  ClientWsMessage,
  ClubId,
  PlayerMatchState,
  PublicRoomSummary,
  RoomState,
  ServerWsMessage,
} from './src/game/types.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ClientSession {
  id: string;
  ws: WebSocket;
  roomCode: string | null;
}

interface InternalRoom {
  state: RoomState;
  clientIds: Set<string>;
  botTimer?: ReturnType<typeof setTimeout>;
}

const clients = new Map<string, ClientSession>();
const rooms = new Map<string, InternalRoom>();

const BOT_PROFILES: Array<{ name: string; characterId: CharacterId }> = [
  { name: 'CPU Arda', characterId: 'bora' },
  { name: 'CPU Zeynep', characterId: 'defne' },
  { name: 'CPU Mert', characterId: 'kaan' },
  { name: 'CPU Selin', characterId: 'ece' },
];

function generateId(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return rooms.has(code) ? generateRoomCode() : code;
}

function sendToClient(ws: WebSocket, msg: ServerWsMessage): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(msg));
  }
}

function broadcastToRoom(room: InternalRoom, msg: ServerWsMessage, excludeClientId?: string): void {
  const payload = JSON.stringify(msg);
  for (const cid of room.clientIds) {
    if (cid === excludeClientId) continue;
    const client = clients.get(cid);
    if (client && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(payload);
    }
  }
}

function getPublicRooms(): PublicRoomSummary[] {
  const list: PublicRoomSummary[] = [];
  for (const room of rooms.values()) {
    if (room.state.isPrivate) continue;
    const host = room.state.players.find((p) => p.id === room.state.hostId) ?? room.state.players[0];
    if (!host) continue;
    list.push({
      code: room.state.code,
      hostName: host.name,
      playerCount: room.state.players.length,
      botCount: room.state.players.filter((p) => p.isBot).length,
      maxPlayers: 4,
      status: room.state.status,
      currentHoleIndex: room.state.currentHoleIndex,
    });
  }
  return list;
}

function createPlayerState(
  id: string,
  name: string,
  characterId: CharacterId,
  slotIndex: number,
  isBot = false,
): PlayerMatchState {
  const hole = getHole(0);
  const tee = getHoleStartTee(hole);
  const cup = getHoleCupPos(hole);
  const char = CHARACTERS[characterId] ?? CHARACTERS.kaan;
  const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);

  return {
    id,
    name: name.trim().slice(0, 18) || `Oyuncu ${slotIndex + 1}`,
    characterId: char.id,
    color: PLAYER_COLORS[slotIndex % PLAYER_COLORS.length],
    connected: true,
    isBot,
    ballPos: { ...tee },
    currentHoleStrokes: 0,
    holeScores: HOLES.map(() => null),
    totalStrokes: 0,
    holedOut: false,
    powerCharges: char.maxChargesPerMatch,
    activePower: false,
    selectedClub: recommendClubForSituation(dist, 'tee'),
    aimYaw: getInitialAimYaw(tee, cup),
  };
}

function resetPlayersForHole(room: RoomState, holeIndex: number): void {
  const hole = getHole(holeIndex);
  const tee = getHoleStartTee(hole);
  const cup = getHoleCupPos(hole);
  const dist = Math.hypot(cup.x - tee.x, cup.z - tee.z);
  const defaultYaw = getInitialAimYaw(tee, cup);

  room.currentHoleIndex = holeIndex;
  // Slightly vary wind around default hole wind for live variety
  room.wind = {
    x: Number((hole.defaultWind.x + (Math.random() - 0.5) * 1.2).toFixed(1)),
    z: Number((hole.defaultWind.z + (Math.random() - 0.5) * 1.0).toFixed(1)),
  };

  for (const player of room.players) {
    player.ballPos = { ...tee };
    player.currentHoleStrokes = 0;
    player.holedOut = false;
    player.activePower = false;
    player.selectedClub = recommendClubForSituation(dist, 'tee');
    player.aimYaw = defaultYaw;
  }

  room.currentTurnPlayerId = room.players[0]?.id ?? null;
}

function advanceTurn(room: RoomState): { holeFinished: boolean; matchFinished: boolean } {
  const activePlayers = room.players.filter((p) => !p.holedOut);
  if (activePlayers.length === 0) {
    // Everyone holed out!
    const nextHole = room.currentHoleIndex + 1;
    if (nextHole >= HOLES.length) {
      room.status = 'finished';
      room.currentTurnPlayerId = null;
      return { holeFinished: true, matchFinished: true };
    }
    resetPlayersForHole(room, nextHole);
    return { holeFinished: true, matchFinished: false };
  }

  // Pick player furthest from cup or next in rotation who isn't holed out
  const currentIdx = room.players.findIndex((p) => p.id === room.currentTurnPlayerId);
  for (let offset = 1; offset <= room.players.length; offset++) {
    const candidate = room.players[(currentIdx + offset) % room.players.length];
    if (!candidate.holedOut) {
      room.currentTurnPlayerId = candidate.id;
      return { holeFinished: false, matchFinished: false };
    }
  }

  room.currentTurnPlayerId = activePlayers[0].id;
  return { holeFinished: false, matchFinished: false };
}

function clearBotTimer(room: InternalRoom): void {
  if (room.botTimer) {
    clearTimeout(room.botTimer);
    room.botTimer = undefined;
  }
}

function executeRoomShot(
  room: InternalRoom,
  player: PlayerMatchState,
  clubId: ClubId,
  powerRatio: number,
  aimYaw: number,
  usePower: boolean,
): void {
  const powerActive = usePower && player.powerCharges > 0;
  if (powerActive) {
    player.powerCharges = Math.max(0, player.powerCharges - 1);
  }
  player.activePower = false;
  player.selectedClub = clubId;
  player.aimYaw = aimYaw;

  const clampedRatio = Math.max(0.1, Math.min(1, powerRatio));
  const holeIndex = room.state.currentHoleIndex;
  const sim = simulateShotTrajectory({
    holeIndex,
    startPos: player.ballPos,
    clubId,
    characterId: player.characterId,
    powerRatio: clampedRatio,
    aimYaw,
    wind: room.state.wind,
    powerActive,
  });

  player.currentHoleStrokes += 1 + sim.penaltyStrokes;
  player.ballPos = { ...sim.finalPos };

  const hole = getHole(holeIndex);
  const cup = getHoleCupPos(hole);

  if (sim.sunk) {
    player.holedOut = true;
    player.holeScores[holeIndex] = player.currentHoleStrokes;
    player.totalStrokes = player.holeScores.reduce<number>((sum, v) => sum + (v ?? 0), 0);
    room.state.lastEventText = `${player.name} ${player.currentHoleStrokes} vuruşta deliğe soktu!`;
  } else {
    const dist = Math.hypot(cup.x - player.ballPos.x, cup.z - player.ballPos.z);
    const surface = getSurfaceAt(hole, player.ballPos.x, player.ballPos.z);
    player.selectedClub = recommendClubForSituation(dist, surface);
    player.aimYaw = getInitialAimYaw(player.ballPos, cup);
    if (sim.hitWater) {
      room.state.lastEventText = `${player.name} suya düştü (+1 ceza vuruşu).`;
    } else {
      room.state.lastEventText = `${player.name} ${sim.totalDistanceM}m vurdu (${sim.launchSpeedKmh} km/s).`;
    }
  }

  const { holeFinished, matchFinished } = advanceTurn(room.state);
  if (matchFinished) {
    clearBotTimer(room);
    room.state.lastEventText = 'Turnuva tamamlandı! Kazanan belirlendi.';
  } else if (holeFinished) {
    room.state.lastEventText = `Delik ${room.state.currentHoleIndex + 1} başladı!`;
  }

  broadcastToRoom(room, {
    type: 'shot:executed',
    playerId: player.id,
    clubId,
    characterId: player.characterId,
    powerActive,
    simulation: sim,
    room: room.state,
  });

  scheduleBotTurnIfNeeded(room);
}

function scheduleBotTurnIfNeeded(room: InternalRoom): void {
  clearBotTimer(room);
  if (room.state.status !== 'playing' || !room.state.currentTurnPlayerId) return;

  const bot = room.state.players.find((p) => p.id === room.state.currentTurnPlayerId);
  if (!bot || !bot.isBot || bot.holedOut) return;

  room.botTimer = setTimeout(() => {
    if (!rooms.has(room.state.code) || room.state.status !== 'playing') return;
    if (room.state.currentTurnPlayerId !== bot.id || bot.holedOut) return;

    const holeIndex = room.state.currentHoleIndex;
    const hole = getHole(holeIndex);
    const cup = getHoleCupPos(hole);
    const dist = Math.hypot(cup.x - bot.ballPos.x, cup.z - bot.ballPos.z);
    const surf = getSurfaceAt(hole, bot.ballPos.x, bot.ballPos.z);
    const clubId = recommendClubForSituation(dist, surf);

    // Subtle human-like dispersion + smart power calculation
    const dispersion =
      clubId === 'putter' ? 0.022 : clubId === 'wedge' ? 0.036 : clubId === 'iron' ? 0.045 : 0.055;
    const yawNoise = (Math.random() - 0.5) * dispersion;
    const botYaw = getInitialAimYaw(bot.ballPos, cup) + yawNoise;

    const char = CHARACTERS[bot.characterId];
    const usePower =
      bot.powerCharges > 0 &&
      ((char.specialPowerId === 'cup_magnet' && surf === 'green' && dist < 14) ||
        (char.specialPowerId !== 'cup_magnet' && dist > 62 && Math.random() < 0.45));

    const optPower = estimateOptimalPowerRatio({
      holeIndex,
      startPos: bot.ballPos,
      clubId,
      characterId: bot.characterId,
      aimYaw: botYaw,
      wind: room.state.wind,
      powerActive: usePower,
    });
    const powerNoise = (Math.random() - 0.5) * (clubId === 'putter' ? 0.04 : 0.06);
    const finalPower = Math.max(0.12, Math.min(1, optPower + powerNoise));

    executeRoomShot(room, bot, clubId, finalPower, botYaw, usePower);
  }, 2400);
}

function removeClientFromRoom(session: ClientSession): void {
  if (!session.roomCode) return;
  const room = rooms.get(session.roomCode);
  session.roomCode = null;
  if (!room) return;

  room.clientIds.delete(session.id);
  const removedPlayer = room.state.players.find((p) => p.id === session.id);
  room.state.players = room.state.players.filter((p) => p.id !== session.id);

  // If no human players remain in the room, destroy it cleanly
  const humanPlayers = room.state.players.filter((p) => !p.isBot);
  if (humanPlayers.length === 0) {
    clearBotTimer(room);
    rooms.delete(room.state.code);
    return;
  }

  if (room.state.hostId === session.id) {
    room.state.hostId = humanPlayers[0].id;
  }

  if (room.state.status === 'playing' && room.state.currentTurnPlayerId === session.id) {
    advanceTurn(room.state);
    scheduleBotTurnIfNeeded(room);
  }

  room.state.lastEventText = `${removedPlayer?.name ?? 'Bir oyuncu'} odadan ayrıldı.`;
  broadcastToRoom(room, { type: 'room:state', room: room.state });
}

function handleWsMessage(session: ClientSession, rawData: string): void {
  let msg: ClientWsMessage;
  try {
    msg = JSON.parse(rawData) as ClientWsMessage;
  } catch {
    sendToClient(session.ws, { type: 'error', message: 'Geçersiz mesaj biçimi.' });
    return;
  }

  if (msg.type === 'rooms:list') {
    sendToClient(session.ws, { type: 'rooms:listed', rooms: getPublicRooms() });
    return;
  }

  if (msg.type === 'room:create') {
    let chosenCode = '';
    if (msg.customCode && msg.customCode.trim().length > 0) {
      const cleaned = msg.customCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
      if (cleaned.length < 3) {
        sendToClient(session.ws, {
          type: 'error',
          message: 'Özel lobi kodu en az 3 karakter (harf/rakam) olmalıdır.',
        });
        return;
      }
      if (rooms.has(cleaned)) {
        sendToClient(session.ws, {
          type: 'error',
          message: `"${cleaned}" kodu şu anda başka bir odada kullanılıyor.`,
        });
        return;
      }
      chosenCode = cleaned;
    } else {
      chosenCode = generateRoomCode();
    }

    removeClientFromRoom(session);
    const hostPlayer = createPlayerState(session.id, msg.playerName, msg.characterId, 0, false);
    const hole = getHole(0);
    const roomState: RoomState = {
      code: chosenCode,
      hostId: session.id,
      isPrivate: Boolean(msg.isPrivate),
      status: 'waiting',
      currentHoleIndex: 0,
      wind: { ...hole.defaultWind },
      currentTurnPlayerId: null,
      players: [hostPlayer],
      lastEventText: `${hostPlayer.name} odayı kurdu.`,
    };
    const internal: InternalRoom = {
      state: roomState,
      clientIds: new Set([session.id]),
    };
    rooms.set(chosenCode, internal);
    session.roomCode = chosenCode;
    sendToClient(session.ws, { type: 'room:joined', room: roomState, youId: session.id });
    return;
  }

  if (msg.type === 'room:join') {
    const cleanCode = msg.code.trim().toUpperCase();
    const room = rooms.get(cleanCode);
    if (!room) {
      sendToClient(session.ws, { type: 'error', message: `"${cleanCode}" kodlu oda bulunamadı.` });
      return;
    }
    if (room.state.players.length >= 4) {
      sendToClient(session.ws, { type: 'error', message: 'Oda dolu (en fazla 4 oyuncu).' });
      return;
    }
    if (room.state.status !== 'waiting') {
      sendToClient(session.ws, { type: 'error', message: 'Bu maç zaten başladı.' });
      return;
    }

    removeClientFromRoom(session);
    const player = createPlayerState(
      session.id,
      msg.playerName,
      msg.characterId,
      room.state.players.length,
    );
    room.state.players.push(player);
    room.clientIds.add(session.id);
    session.roomCode = cleanCode;
    room.state.lastEventText = `${player.name} odaya katıldı.`;

    sendToClient(session.ws, { type: 'room:joined', room: room.state, youId: session.id });
    broadcastToRoom(room, { type: 'room:state', room: room.state }, session.id);
    return;
  }

  if (msg.type === 'room:leave') {
    removeClientFromRoom(session);
    sendToClient(session.ws, { type: 'room:left' });
    return;
  }

  if (!session.roomCode) {
    sendToClient(session.ws, { type: 'error', message: 'Aktif bir odada değilsiniz.' });
    return;
  }

  const room = rooms.get(session.roomCode);
  if (!room) {
    session.roomCode = null;
    sendToClient(session.ws, { type: 'error', message: 'Oda artık mevcut değil.' });
    return;
  }

  const player = room.state.players.find((p) => p.id === session.id);
  if (!player) return;

  if (msg.type === 'room:character') {
    if (room.state.status !== 'waiting') {
      sendToClient(session.ws, {
        type: 'error',
        message: 'Maç başladıktan sonra karakter değiştirilemez.',
      });
      return;
    }
    const char = CHARACTERS[msg.characterId];
    if (!char) return;
    player.characterId = char.id;
    player.powerCharges = char.maxChargesPerMatch;
    room.state.lastEventText = `${player.name} karakterini ${char.name} olarak değiştirdi.`;
    broadcastToRoom(room, { type: 'room:state', room: room.state });
    return;
  }

  if (msg.type === 'room:add_bot') {
    if (room.state.hostId !== session.id) {
      sendToClient(session.ws, { type: 'error', message: 'Sadece oda kurucusu CPU ekleyebilir.' });
      return;
    }
    if (room.state.status !== 'waiting') return;
    if (room.state.players.length >= 4) {
      sendToClient(session.ws, { type: 'error', message: 'Oda dolu (en fazla 4 oyuncu).' });
      return;
    }
    const usedNames = new Set(room.state.players.map((p) => p.name));
    const profile =
      BOT_PROFILES.find((bp) => !usedNames.has(bp.name)) ??
      BOT_PROFILES[room.state.players.length % BOT_PROFILES.length];
    const botId = generateId('bot');
    const botPlayer = createPlayerState(
      botId,
      profile.name,
      profile.characterId,
      room.state.players.length,
      true,
    );
    room.state.players.push(botPlayer);
    room.state.lastEventText = `${botPlayer.name} lobiye eklendi.`;
    broadcastToRoom(room, { type: 'room:state', room: room.state });
    return;
  }

  if (msg.type === 'room:remove_bot') {
    if (room.state.hostId !== session.id || room.state.status !== 'waiting') return;
    const target = room.state.players.find((p) => p.id === msg.botId && p.isBot);
    if (!target) return;
    room.state.players = room.state.players.filter((p) => p.id !== msg.botId);
    // Reassign clean player colors for active slots
    room.state.players.forEach((p, idx) => {
      p.color = PLAYER_COLORS[idx % PLAYER_COLORS.length];
    });
    room.state.lastEventText = `${target.name} odadan çıkarıldı.`;
    broadcastToRoom(room, { type: 'room:state', room: room.state });
    return;
  }

  if (msg.type === 'room:start') {
    if (room.state.hostId !== session.id) {
      sendToClient(session.ws, { type: 'error', message: 'Maçı sadece oda kurucusu başlatabilir.' });
      return;
    }
    clearBotTimer(room);
    room.state.status = 'playing';
    for (const p of room.state.players) {
      p.holeScores = HOLES.map(() => null);
      p.totalStrokes = 0;
      p.powerCharges = CHARACTERS[p.characterId].maxChargesPerMatch;
    }
    resetPlayersForHole(room.state, 0);
    room.state.lastEventText = 'Maç başladı! İlk vuruş sırası hazır.';
    broadcastToRoom(room, { type: 'room:state', room: room.state });
    scheduleBotTurnIfNeeded(room);
    return;
  }

  if (msg.type === 'room:rematch') {
    if (room.state.hostId !== session.id) return;
    clearBotTimer(room);
    room.state.status = 'playing';
    for (const p of room.state.players) {
      p.holeScores = HOLES.map(() => null);
      p.totalStrokes = 0;
      p.powerCharges = CHARACTERS[p.characterId].maxChargesPerMatch;
    }
    resetPlayersForHole(room.state, 0);
    room.state.lastEventText = 'Yeni tur başladı!';
    broadcastToRoom(room, { type: 'room:state', room: room.state });
    scheduleBotTurnIfNeeded(room);
    return;
  }

  if (msg.type === 'player:aim') {
    if (room.state.status !== 'playing') return;
    player.aimYaw = msg.aimYaw;
    player.selectedClub = msg.clubId;
    player.activePower = msg.activePower && player.powerCharges > 0;
    broadcastToRoom(
      room,
      {
        type: 'player:aimed',
        playerId: player.id,
        aimYaw: msg.aimYaw,
        clubId: msg.clubId,
        activePower: player.activePower,
      },
      session.id,
    );
    return;
  }

  if (msg.type === 'player:shot') {
    if (room.state.status !== 'playing') return;
    if (room.state.currentTurnPlayerId !== session.id) {
      sendToClient(session.ws, { type: 'error', message: 'Şu anda sizin sıranız değil.' });
      return;
    }
    if (player.holedOut) return;

    executeRoomShot(room, player, msg.clubId, msg.powerRatio, msg.aimYaw, msg.usePower);
  }
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activeRooms: rooms.size, connectedClients: clients.size });
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req, socket, head) => {
    const reqPath = req.url?.split('?')[0];
    if (reqPath === '/ws') {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    } else {
      socket.destroy();
    }
  });

  wss.on('connection', (ws) => {
    const clientId = generateId('p');
    const session: ClientSession = { id: clientId, ws, roomCode: null };
    clients.set(clientId, session);

    sendToClient(ws, { type: 'welcome', clientId });

    ws.on('message', (data) => {
      handleWsMessage(session, data.toString());
    });

    ws.on('close', () => {
      removeClientFromRoom(session);
      clients.delete(clientId);
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, ws: false },
      appType: 'spa',
    });

    // When HMR is disabled, prevent @vite/client from opening a failing :24678 WebSocket
    app.get('/@vite/client', async (_req, res, next) => {
      try {
        const result = await vite.transformRequest('/@vite/client');
        if (!result) return next();
        const patched = result.code.replace(
          /transport\.connect\(createHMRHandler\(handleMessage\)\);?/g,
          '/* HMR WebSocket disabled */',
        );
        res.setHeader('Content-Type', 'application/javascript');
        res.setHeader('Cache-Control', 'no-cache');
        res.send(patched);
      } catch (err) {
        next(err);
      }
    });

    app.use(vite.middlewares);
  }

  const port = Number(process.env.PORT ?? 3000);
  server.listen(port, '0.0.0.0', () => {
    console.log(`Zirve Golf Club server listening on http://localhost:${port}`);
  });
}

startServer();
